// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashUtils
{
    public static String getHashMd5(final String data) {
        return getHash(data, "MD5");
    }
    
    public static String getHashSha1(final String data) {
        return getHash(data, "SHA-1");
    }
    
    public static String getHashSha256(final String data) {
        return getHash(data, "SHA-256");
    }
    
    public static String getHash(final String data, final String digest) {
        try {
            final byte[] array = getHash(data.getBytes("UTF-8"), digest);
            return toHexString(array);
        }
        catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
    
    public static String toHexString(final byte[] data) {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < data.length; ++i) {
            sb.append(Integer.toHexString((data[i] & 0xFF) | 0x100).substring(1, 3));
        }
        return sb.toString();
    }
    
    public static byte[] getHashMd5(final byte[] data) throws NoSuchAlgorithmException {
        return getHash(data, "MD5");
    }
    
    public static byte[] getHashSha1(final byte[] data) throws NoSuchAlgorithmException {
        return getHash(data, "SHA-1");
    }
    
    public static byte[] getHashSha256(final byte[] data) throws NoSuchAlgorithmException {
        return getHash(data, "SHA-256");
    }
    
    public static byte[] getHash(final byte[] data, final String digest) throws NoSuchAlgorithmException {
        final MessageDigest md = MessageDigest.getInstance(digest);
        final byte[] array = md.digest(data);
        return array;
    }
}
