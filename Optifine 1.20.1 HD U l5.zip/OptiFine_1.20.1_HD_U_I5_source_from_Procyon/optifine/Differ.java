// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import optifine.xdelta.DiffWriter;
import optifine.xdelta.Delta;
import optifine.xdelta.GDiffWriter;
import java.io.DataOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import java.security.NoSuchAlgorithmException;
import optifine.xdelta.DeltaException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.Map;
import java.util.HashMap;
import java.io.OutputStream;
import java.util.zip.ZipOutputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipFile;
import java.io.IOException;
import java.io.File;

public class Differ
{
    public static void main(final String[] args) {
        if (args.length < 3) {
            Utils.dbg("Usage: Differ <base.jar> <mod.jar> <diff.jar>");
            return;
        }
        File baseFile = new File(args[0]);
        final File modFile = new File(args[1]);
        final File diffFile = new File(args[2]);
        try {
            if (baseFile.getName().equals("AUTO")) {
                baseFile = detectBaseFile(modFile);
            }
            if (!baseFile.exists() || !baseFile.isFile()) {
                throw new IOException("Base file not found: " + baseFile);
            }
            if (!modFile.exists() || !modFile.isFile()) {
                throw new IOException("Mod file not found: " + modFile);
            }
            process(baseFile, modFile, diffFile);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private static void process(final File baseFile, final File modFile, final File diffFile) throws IOException, DeltaException, NoSuchAlgorithmException {
        final ZipFile modZip = new ZipFile(modFile);
        final Map<String, String> cfgMap = Patcher.getConfigurationMap(modZip);
        final Pattern[] patterns = Patcher.getConfigurationPatterns(cfgMap);
        final ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(diffFile));
        final ZipFile baseZip = new ZipFile(baseFile);
        final Enumeration modZipEntries = modZip.entries();
        final Map<String, Map<String, Integer>> mapStats = new HashMap<String, Map<String, Integer>>();
        while (modZipEntries.hasMoreElements()) {
            final ZipEntry modZipEntry = modZipEntries.nextElement();
            if (modZipEntry.isDirectory()) {
                continue;
            }
            final InputStream in = modZip.getInputStream(modZipEntry);
            final byte[] bytes = Utils.readAll(in);
            final String name = modZipEntry.getName();
            final byte[] bytesDiff = makeDiff(name, bytes, patterns, cfgMap, baseZip);
            if (bytesDiff != bytes) {
                final ZipEntry zipEntryDiff = new ZipEntry("patch/" + name + ".xdelta");
                zipOut.putNextEntry(zipEntryDiff);
                zipOut.write(bytesDiff);
                zipOut.closeEntry();
                addStat(mapStats, name, "delta");
                final byte[] md5 = HashUtils.getHashMd5(bytes);
                final String md5Str = HashUtils.toHexString(md5);
                final byte[] bytesMd5Str = md5Str.getBytes("ASCII");
                final ZipEntry zipEntryMd5 = new ZipEntry("patch/" + name + ".md5");
                zipOut.putNextEntry(zipEntryMd5);
                zipOut.write(bytesMd5Str);
                zipOut.closeEntry();
            }
            else {
                final ZipEntry zipEntrySame = new ZipEntry(name);
                zipOut.putNextEntry(zipEntrySame);
                zipOut.write(bytes);
                zipOut.closeEntry();
                addStat(mapStats, name, "same");
            }
        }
        zipOut.close();
        printStats(mapStats);
    }
    
    private static void printStats(final Map<String, Map<String, Integer>> mapStats) {
        final List<String> folders = new ArrayList<String>(mapStats.keySet());
        Collections.sort(folders);
        for (final String folder : folders) {
            final Map<String, Integer> map = mapStats.get(folder);
            final List<String> types = new ArrayList<String>(map.keySet());
            Collections.sort(types);
            String dbg = "";
            for (final String type : types) {
                final Integer val = map.get(type);
                if (dbg.length() > 0) {
                    dbg = String.valueOf(dbg) + ", ";
                }
                dbg = String.valueOf(dbg) + type + " " + val;
            }
            Utils.dbg(folder + " = " + dbg);
        }
    }
    
    private static void addStat(final Map<String, Map<String, Integer>> mapStats, final String name, final String type) {
        final int pos = name.lastIndexOf(47);
        String folder = "";
        if (pos >= 0) {
            folder = name.substring(0, pos);
        }
        Map<String, Integer> map = mapStats.get(folder);
        if (map == null) {
            map = new HashMap<String, Integer>();
            mapStats.put(folder, map);
        }
        Integer val = map.get(type);
        if (val == null) {
            val = new Integer(0);
        }
        val = new Integer(val + 1);
        map.put(type, val);
    }
    
    public static byte[] makeDiff(final String name, final byte[] bytesMod, final Pattern[] patterns, final Map<String, String> cfgMap, final ZipFile zipBase) throws IOException, DeltaException {
        final String baseName = Patcher.getPatchBase(name, patterns, cfgMap);
        if (baseName == null) {
            return bytesMod;
        }
        final ZipEntry baseEntry = zipBase.getEntry(baseName);
        if (baseEntry == null) {
            throw new IOException("Base entry not found: " + baseName + " in: " + zipBase.getName());
        }
        final InputStream baseIn = zipBase.getInputStream(baseEntry);
        final byte[] baseBytes = Utils.readAll(baseIn);
        final ByteArrayInputStream baisTarget = new ByteArrayInputStream(bytesMod);
        final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        final DiffWriter diffWriter = new GDiffWriter(new DataOutputStream(outputStream));
        Delta.computeDelta(baseBytes, baisTarget, bytesMod.length, diffWriter);
        diffWriter.close();
        return outputStream.toByteArray();
    }
    
    public static File detectBaseFile(final File modFile) throws IOException {
        final ZipFile modZip = new ZipFile(modFile);
        final String ofVer = Installer.getOptiFineVersion(modZip);
        if (ofVer == null) {
            throw new IOException("Version not found");
        }
        modZip.close();
        final String mcVer = Installer.getMinecraftVersionFromOfVersion(ofVer);
        if (mcVer == null) {
            throw new IOException("Version not found");
        }
        final File dirMc = Utils.getWorkingDirectory();
        final File baseFile = new File(dirMc, "versions/" + mcVer + "/" + mcVer + ".jar");
        Utils.dbg("BaseFile: " + baseFile);
        return baseFile;
    }
}
