// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import java.io.InputStream;

public interface IOptiFineResourceLocator
{
    InputStream getOptiFineResourceStream(final String p0);
}
