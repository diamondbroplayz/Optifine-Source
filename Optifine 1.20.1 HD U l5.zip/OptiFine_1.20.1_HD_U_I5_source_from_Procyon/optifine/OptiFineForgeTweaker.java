// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import net.minecraft.launchwrapper.LaunchClassLoader;
import java.io.File;
import java.util.List;
import net.minecraft.launchwrapper.ITweaker;

public class OptiFineForgeTweaker implements ITweaker
{
    public void acceptOptions(final List<String> args, final File gameDir, final File assetsDir, final String profile) {
        dbg("OptiFineForgeTweaker: acceptOptions");
    }
    
    public void injectIntoClassLoader(final LaunchClassLoader classLoader) {
        if (LaunchUtils.isForgeServer()) {
            dbg("OptiFineForgeTweaker: Forge server detected, skipping class transformer");
            return;
        }
        dbg("OptiFineForgeTweaker: injectIntoClassLoader");
        classLoader.registerTransformer("optifine.OptiFineClassTransformer");
    }
    
    public String getLaunchTarget() {
        dbg("OptiFineForgeTweaker: getLaunchTarget");
        return "net.minecraft.client.main.Main";
    }
    
    public String[] getLaunchArguments() {
        dbg("OptiFineForgeTweaker: getLaunchArguments");
        return new String[0];
    }
    
    private static void dbg(final String str) {
        System.out.println(str);
    }
}
