// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import cpw.mods.jarhandling.JarMetadata;
import cpw.mods.jarhandling.SecureJar;
import java.util.function.Function;
import cpw.mods.modlauncher.api.LamdbaExceptionUtils;
import java.net.URL;
import java.net.URI;
import java.util.Optional;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;
import java.util.List;
import java.util.ArrayList;
import cpw.mods.jarhandling.impl.SimpleJarMetadata;
import java.util.jar.Manifest;
import java.nio.file.Path;
import cpw.mods.jarhandling.impl.Jar;

public class OptiFineJar extends Jar
{
    public OptiFineJar(final Path... paths) {
        final SimpleJarMetadata simpleJarMetadata;
        super((Supplier)Manifest::new, jar -> {
            new SimpleJarMetadata("net.optifine", (String)null, jar.getPackages(), (List)new ArrayList());
            return simpleJarMetadata;
        }, (s1, s2) -> true, paths);
    }
    
    public Set<String> getPackages() {
        final Set<String> set = new HashSet<String>();
        final Enumeration<? extends ZipEntry> entries = OptiFineTransformationService.getOfZipFile().entries();
        while (entries.hasMoreElements()) {
            final ZipEntry zipEntry = (ZipEntry)entries.nextElement();
            final String name = zipEntry.getName();
            if (name.startsWith("srg/net/optifine/")) {
                if (!name.endsWith(".class")) {
                    continue;
                }
                set.add(name.substring(name.indexOf("/") + 1, name.lastIndexOf("/")).replace('/', '.'));
            }
        }
        return set;
    }
    
    public Optional<URI> findFile(final String name) {
        return OptiFineTransformationService.getResourceUrl(name).map((Function<? super URL, ? extends URI>)LamdbaExceptionUtils.rethrowFunction(URL::toURI));
    }
}
