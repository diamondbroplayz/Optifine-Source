// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import java.io.IOException;
import java.io.InputStream;

public interface IResourceProvider
{
    InputStream getResourceStream(final String p0) throws IOException;
}
