// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import net.minecraft.launchwrapper.LaunchClassLoader;
import java.util.Collection;
import java.util.ArrayList;
import java.io.File;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.List;
import net.minecraft.launchwrapper.ITweaker;

public class OptiFineTweaker implements ITweaker
{
    private List<String> args;
    private static final Logger LOGGER;
    
    static {
        LOGGER = LogManager.getLogger();
    }
    
    public void acceptOptions(final List<String> args, final File gameDir, final File assetsDir, final String profile) {
        dbg("OptiFineTweaker: acceptOptions");
        (this.args = new ArrayList<String>(args)).add("--gameDir");
        this.args.add(gameDir.getAbsolutePath());
        this.args.add("--assetsDir");
        this.args.add(assetsDir.getAbsolutePath());
        this.args.add("--version");
        this.args.add(profile);
    }
    
    public void injectIntoClassLoader(final LaunchClassLoader classLoader) {
        dbg("OptiFineTweaker: injectIntoClassLoader");
        classLoader.registerTransformer("optifine.OptiFineClassTransformer");
    }
    
    public String getLaunchTarget() {
        dbg("OptiFineTweaker: getLaunchTarget");
        return "net.minecraft.client.main.Main";
    }
    
    public String[] getLaunchArguments() {
        dbg("OptiFineTweaker: getLaunchArguments");
        return this.args.toArray(new String[this.args.size()]);
    }
    
    private static void dbg(final String str) {
        OptiFineTweaker.LOGGER.info("[OptiFine] " + str);
    }
}
