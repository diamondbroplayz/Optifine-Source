// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import java.lang.reflect.Field;
import java.util.Map;

public class LaunchUtils
{
    private static Boolean forgeServer;
    
    static {
        LaunchUtils.forgeServer = null;
    }
    
    public static boolean isForgeServer() {
        if (LaunchUtils.forgeServer == null) {
            try {
                final Class cls = Class.forName("net.minecraft.launchwrapper.Launch");
                final Field fieldBlackboard = cls.getField("blackboard");
                final Map<String, Object> blackboard = (Map<String, Object>)fieldBlackboard.get(null);
                final Map<String, String> launchArgs = blackboard.get("launchArgs");
                final String accessToken = launchArgs.get("--accessToken");
                final String version = launchArgs.get("--version");
                final boolean onServer = accessToken == null && Utils.equals(version, "UnknownFMLProfile");
                LaunchUtils.forgeServer = onServer;
            }
            catch (Throwable e) {
                System.out.println("Error checking Forge server: " + e.getClass().getName() + ": " + e.getMessage());
                LaunchUtils.forgeServer = Boolean.FALSE;
            }
        }
        return LaunchUtils.forgeServer;
    }
}
