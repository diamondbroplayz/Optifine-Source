// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.net.URI;
import java.net.URL;
import java.io.InputStream;
import javax.swing.JComponent;
import java.util.Locale;
import javax.swing.JFileChooser;
import java.text.SimpleDateFormat;
import optifine.json.JSONArray;
import java.io.Writer;
import optifine.json.JSONWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.util.Date;
import optifine.json.JSONObject;
import optifine.json.JSONParser;
import optifine.json.ParseException;
import java.io.IOException;
import java.io.File;
import javax.swing.JOptionPane;
import java.awt.Dimension;
import java.awt.Component;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.JTextArea;

public class Installer
{
    private static String DEFAULT_JVM_ARGS;
    
    static {
        Installer.DEFAULT_JVM_ARGS = "-Xmx2G -XX:+UnlockExperimentalVMOptions -XX:+UseG1GC -XX:G1NewSizePercent=20 -XX:G1ReservePercent=20 -XX:MaxGCPauseMillis=50 -XX:G1HeapRegionSize=32M";
    }
    
    public static void main(final String[] args) {
        try {
            final File dirMc = Utils.getWorkingDirectory();
            doInstall(dirMc);
        }
        catch (Exception e) {
            final String msg = e.getMessage();
            if (msg != null && msg.equals("QUIET")) {
                return;
            }
            e.printStackTrace();
            String str = Utils.getExceptionStackTrace(e);
            str = str.replace("\t", "  ");
            final JTextArea textArea = new JTextArea(str);
            textArea.setEditable(false);
            final Font f = textArea.getFont();
            final Font f2 = new Font("Monospaced", f.getStyle(), f.getSize());
            textArea.setFont(f2);
            final JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(600, 400));
            JOptionPane.showMessageDialog(null, scrollPane, "Error", 0);
        }
    }
    
    public static void doInstall(final File dirMc) throws Exception {
        Utils.dbg("Dir minecraft: " + dirMc);
        final File dirMcLib = new File(dirMc, "libraries");
        Utils.dbg("Dir libraries: " + dirMcLib);
        final File dirMcVers = new File(dirMc, "versions");
        Utils.dbg("Dir versions: " + dirMcVers);
        final String ofVer = getOptiFineVersion();
        Utils.dbg("OptiFine Version: " + ofVer);
        final String[] ofVers = Utils.tokenize(ofVer, "_");
        final String mcVer = ofVers[1];
        Utils.dbg("Minecraft Version: " + mcVer);
        final String ofEd = getOptiFineEdition(ofVers);
        Utils.dbg("OptiFine Edition: " + ofEd);
        final String mcVerOf = String.valueOf(mcVer) + "-OptiFine_" + ofEd;
        Utils.dbg("Minecraft_OptiFine Version: " + mcVerOf);
        copyMinecraftVersion(mcVer, mcVerOf, dirMcVers);
        installOptiFineLibrary(mcVer, ofEd, dirMcLib, false);
        installLaunchwrapperLibrary(mcVer, ofEd, dirMcLib);
        updateJson(dirMcVers, mcVerOf, dirMcLib, mcVer, ofEd);
        updateLauncherJson(dirMc, mcVerOf);
    }
    
    public static boolean doExtract(final File dirMc) throws Exception {
        Utils.dbg("Dir minecraft: " + dirMc);
        final File dirMcLib = new File(dirMc, "libraries");
        Utils.dbg("Dir libraries: " + dirMcLib);
        final File dirMcVers = new File(dirMc, "versions");
        Utils.dbg("Dir versions: " + dirMcVers);
        final String ofVer = getOptiFineVersion();
        Utils.dbg("OptiFine Version: " + ofVer);
        final String[] ofVers = Utils.tokenize(ofVer, "_");
        final String mcVer = ofVers[1];
        Utils.dbg("Minecraft Version: " + mcVer);
        final String ofEd = getOptiFineEdition(ofVers);
        Utils.dbg("OptiFine Edition: " + ofEd);
        final String mcVerOf = String.valueOf(mcVer) + "-OptiFine_" + ofEd;
        Utils.dbg("Minecraft_OptiFine Version: " + mcVerOf);
        return installOptiFineLibrary(mcVer, ofEd, dirMcLib, true);
    }
    
    private static void updateLauncherJson(final File dirMc, final String mcVerOf) throws IOException, ParseException {
        boolean jsonUpdated = false;
        final File fileJson = new File(dirMc, "launcher_profiles.json");
        if (fileJson.exists() && fileJson.isFile()) {
            updateLauncherJson(dirMc, mcVerOf, fileJson);
            jsonUpdated = true;
        }
        final File fileJsonMs = new File(dirMc, "launcher_profiles_microsoft_store.json");
        if (fileJsonMs.exists() && fileJsonMs.isFile()) {
            updateLauncherJson(dirMc, mcVerOf, fileJsonMs);
            jsonUpdated = true;
        }
        if (!jsonUpdated) {
            Utils.showErrorMessage("File not found: " + fileJson);
            Utils.showErrorMessage("File not found: " + fileJsonMs);
            throw new RuntimeException("QUIET");
        }
    }
    
    private static void updateLauncherJson(final File dirMc, final String mcVerOf, final File fileJson) throws IOException, ParseException {
        Utils.dbg("Update launcher JSON: " + fileJson);
        final String json = Utils.readFile(fileJson, "UTF-8");
        final JSONParser jp = new JSONParser();
        final JSONObject root = (JSONObject)jp.parse(json);
        final JSONObject profiles = root.get("profiles");
        JSONObject prof = profiles.get("OptiFine");
        if (prof == null) {
            prof = new JSONObject();
            prof.put("name", "OptiFine");
            prof.put("created", formatDateMs(new Date()));
            profiles.put("OptiFine", prof);
        }
        prof.put("type", "custom");
        prof.put("lastVersionId", mcVerOf);
        prof.put("lastUsed", formatDateMs(new Date()));
        prof.put("icon", ProfileIcon.DATA);
        Object jvmArgs = prof.get("javaArgs");
        if (jvmArgs == null) {
            jvmArgs = Installer.DEFAULT_JVM_ARGS;
        }
        if (jvmArgs instanceof String) {
            String jvmArgsStr = (String)jvmArgs;
            if (!jvmArgsStr.contains("net.minecraft.client.main.Main")) {
                jvmArgsStr = String.valueOf(jvmArgsStr) + " -Ddiscordfix=net.minecraft.client.main.Main";
                prof.put("javaArgs", jvmArgsStr);
            }
        }
        root.put("selectedProfile", "OptiFine");
        final FileOutputStream fosJson = new FileOutputStream(fileJson);
        final OutputStreamWriter oswJson = new OutputStreamWriter(fosJson, "UTF-8");
        final JSONWriter jw = new JSONWriter(oswJson);
        jw.writeObject(root);
        oswJson.flush();
        oswJson.close();
    }
    
    private static void updateJson(final File dirMcVers, final String mcVerOf, final File dirMcLib, final String mcVer, final String ofEd) throws IOException, ParseException {
        final File dirMcVersOf = new File(dirMcVers, mcVerOf);
        final File fileJson = new File(dirMcVersOf, String.valueOf(mcVerOf) + ".json");
        final String json = Utils.readFile(fileJson, "UTF-8");
        final JSONParser jp = new JSONParser();
        Utils.dbg("Update JSON: " + fileJson);
        final JSONObject root = (JSONObject)jp.parse(json);
        final JSONObject rootNew = new JSONObject();
        rootNew.put("id", mcVerOf);
        rootNew.put("inheritsFrom", mcVer);
        rootNew.put("time", formatDate(new Date()));
        rootNew.put("releaseTime", formatDate(new Date()));
        rootNew.put("type", "release");
        final JSONArray libs = new JSONArray();
        rootNew.put("libraries", libs);
        String mainClass = root.get("mainClass");
        if (!mainClass.startsWith("net.minecraft.launchwrapper.")) {
            mainClass = "net.minecraft.launchwrapper.Launch";
            rootNew.put("mainClass", mainClass);
            String mcArgs = root.get("minecraftArguments");
            if (mcArgs != null) {
                mcArgs = String.valueOf(mcArgs) + "  --tweakClass optifine.OptiFineTweaker";
                rootNew.put("minecraftArguments", mcArgs);
            }
            else {
                final JSONObject args = new JSONObject();
                final JSONArray argsGame = new JSONArray();
                argsGame.add("--tweakClass");
                argsGame.add("optifine.OptiFineTweaker");
                args.put("game", argsGame);
                rootNew.put("arguments", args);
            }
            final JSONObject libLw = new JSONObject();
            libLw.put("name", "optifine:launchwrapper-of:" + getLaunchwrapperVersion());
            libs.add(0, libLw);
        }
        final JSONObject libOf = new JSONObject();
        libOf.put("name", "optifine:OptiFine:" + mcVer + "_" + ofEd);
        libs.add(0, libOf);
        final FileOutputStream fosJson = new FileOutputStream(fileJson);
        final OutputStreamWriter oswJson = new OutputStreamWriter(fosJson, "UTF-8");
        final JSONWriter jw = new JSONWriter(oswJson);
        jw.writeObject(rootNew);
        oswJson.flush();
        oswJson.close();
    }
    
    private static Object formatDate(final Date date) {
        try {
            final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
            final String str = dateFormat.format(date);
            return str;
        }
        catch (Exception e) {
            final SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            final String str2 = dateFormat2.format(date);
            return str2;
        }
    }
    
    private static Object formatDateMs(final Date date) {
        final SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd'T'HH:mm:ss.SSS'Z'");
        final String str = dateFormat.format(date);
        return str;
    }
    
    public static String getOptiFineEdition(final String[] ofVers) {
        if (ofVers.length <= 2) {
            return "";
        }
        String ofEd = "";
        for (int i = 2; i < ofVers.length; ++i) {
            if (i > 2) {
                ofEd = String.valueOf(ofEd) + "_";
            }
            ofEd = String.valueOf(ofEd) + ofVers[i];
        }
        return ofEd;
    }
    
    private static boolean installOptiFineLibrary(final String mcVer, final String ofEd, final File dirMcLib, final boolean selectTarget) throws Exception {
        final File fileSrc = getOptiFineZipFile();
        final File dirDest = new File(dirMcLib, "optifine/OptiFine/" + mcVer + "_" + ofEd);
        File fileDest = new File(dirDest, "OptiFine-" + mcVer + "_" + ofEd + ".jar");
        if (selectTarget) {
            fileDest = new File(fileSrc.getParentFile(), "OptiFine_" + mcVer + "_" + ofEd + "_MOD.jar");
            final JFileChooser jfc = new JFileChooser(fileDest.getParentFile());
            jfc.setSelectedFile(fileDest);
            final int ret = jfc.showSaveDialog(null);
            if (ret != 0) {
                return false;
            }
            fileDest = jfc.getSelectedFile();
            if (fileDest.exists()) {
                JComponent.setDefaultLocale(Locale.ENGLISH);
                final int ret2 = JOptionPane.showConfirmDialog(null, "The file \"" + fileDest.getName() + "\" already exists.\nDo you want to overwrite it?", "Save", 1);
                if (ret2 != 0) {
                    return false;
                }
            }
        }
        if (fileDest.equals(fileSrc)) {
            JOptionPane.showMessageDialog(null, "Source and target file are the same.", "Save", 0);
            return false;
        }
        Utils.dbg("Source: " + fileSrc);
        Utils.dbg("Dest: " + fileDest);
        final File dirMc = dirMcLib.getParentFile();
        final File fileBase = new File(dirMc, "versions/" + mcVer + "/" + mcVer + ".jar");
        if (!fileBase.exists()) {
            showMessageVersionNotFound(mcVer);
            throw new RuntimeException("QUIET");
        }
        if (fileDest.getParentFile() != null) {
            fileDest.getParentFile().mkdirs();
        }
        Patcher.process(fileBase, fileSrc, fileDest);
        return true;
    }
    
    private static boolean installLaunchwrapperLibrary(final String mcVer, final String ofEd, final File dirMcLib) throws Exception {
        final String ver = getLaunchwrapperVersion();
        final String fileName = "launchwrapper-of-" + ver + ".jar";
        final File dirDest = new File(dirMcLib, "optifine/launchwrapper-of/" + ver);
        final File fileDest = new File(dirDest, fileName);
        Utils.dbg("Source: " + fileName);
        Utils.dbg("Dest: " + fileDest);
        final InputStream fin = Installer.class.getResourceAsStream("/" + fileName);
        if (fin == null) {
            throw new IOException("File not found: " + fileName);
        }
        if (fileDest.getParentFile() != null) {
            fileDest.getParentFile().mkdirs();
        }
        final FileOutputStream fout = new FileOutputStream(fileDest);
        Utils.copyAll(fin, fout);
        fout.flush();
        fin.close();
        fout.close();
        return true;
    }
    
    public static File getOptiFineZipFile() throws Exception {
        final URL url = Installer.class.getProtectionDomain().getCodeSource().getLocation();
        Utils.dbg("URL: " + url);
        final URI uri = url.toURI();
        final File fileZip = new File(uri);
        return fileZip;
    }
    
    public static boolean isPatchFile() throws Exception {
        final File fileZip = getOptiFineZipFile();
        final ZipFile zipFile = new ZipFile(fileZip);
        try {
            final Enumeration<ZipEntry> entries = (Enumeration<ZipEntry>)zipFile.entries();
            while (entries.hasMoreElements()) {
                final ZipEntry zipEntry = entries.nextElement();
                if (zipEntry.getName().startsWith("patch/")) {
                    return true;
                }
            }
            return false;
        }
        finally {
            zipFile.close();
        }
    }
    
    private static void copyMinecraftVersion(final String mcVer, final String mcVerOf, final File dirMcVer) throws IOException {
        final File dirVerMc = new File(dirMcVer, mcVer);
        if (!dirVerMc.exists()) {
            showMessageVersionNotFound(mcVer);
            throw new RuntimeException("QUIET");
        }
        final File dirVerMcOf = new File(dirMcVer, mcVerOf);
        dirVerMcOf.mkdirs();
        Utils.dbg("Dir version MC: " + dirVerMc);
        Utils.dbg("Dir version MC-OF: " + dirVerMcOf);
        final File fileJarMc = new File(dirVerMc, String.valueOf(mcVer) + ".jar");
        final File fileJarMcOf = new File(dirVerMcOf, String.valueOf(mcVerOf) + ".jar");
        if (!fileJarMc.exists()) {
            showMessageVersionNotFound(mcVer);
            throw new RuntimeException("QUIET");
        }
        Utils.copyFile(fileJarMc, fileJarMcOf);
        final File fileJsonMc = new File(dirVerMc, String.valueOf(mcVer) + ".json");
        final File fileJsonMcOf = new File(dirVerMcOf, String.valueOf(mcVerOf) + ".json");
        Utils.copyFile(fileJsonMc, fileJsonMcOf);
    }
    
    private static void showMessageVersionNotFound(final String mcVer) {
        Utils.showErrorMessage("Cannot find Minecraft " + mcVer + ".\nYou must download and start Minecraft " + mcVer + " once in the official launcher.");
    }
    
    public static String getOptiFineVersion() throws IOException {
        InputStream in = Installer.class.getResourceAsStream("/net/optifine/Config.class");
        if (in == null) {
            in = Installer.class.getResourceAsStream("/notch/net/optifine/Config.class");
        }
        if (in == null) {
            in = Installer.class.getResourceAsStream("/Config.class");
        }
        if (in == null) {
            in = Installer.class.getResourceAsStream("/VersionThread.class");
        }
        if (in == null) {
            throw new IOException("OptiFine version not found");
        }
        return getOptiFineVersion(in);
    }
    
    public static String getOptiFineVersion(final ZipFile zipFile) throws IOException {
        ZipEntry zipEntry = zipFile.getEntry("net/optifine/Config.class");
        if (zipEntry == null) {
            zipEntry = zipFile.getEntry("notch/net/optifine/Config.class");
        }
        if (zipEntry == null) {
            zipEntry = zipFile.getEntry("Config.class");
        }
        if (zipEntry == null) {
            zipEntry = zipFile.getEntry("VersionThread.class");
        }
        if (zipEntry == null) {
            throw new IOException("OptiFine version not found");
        }
        final InputStream in = zipFile.getInputStream(zipEntry);
        final String ofVer = getOptiFineVersion(in);
        in.close();
        return ofVer;
    }
    
    public static String getOptiFineVersion(final InputStream in) throws IOException {
        final byte[] bytes = Utils.readAll(in);
        final byte[] pattern = "OptiFine_".getBytes("ASCII");
        int pos = Utils.find(bytes, pattern);
        if (pos < 0) {
            return null;
        }
        int startPos;
        for (startPos = (pos = pos); pos < bytes.length; ++pos) {
            final byte b = bytes[pos];
            if (b < 32 || b > 122) {
                break;
            }
        }
        final int endPos = pos;
        final String ver = new String(bytes, startPos, endPos - startPos, "ASCII");
        return ver;
    }
    
    public static String getMinecraftVersionFromOfVersion(final String ofVer) {
        if (ofVer == null) {
            return null;
        }
        final String[] ofVers = Utils.tokenize(ofVer, "_");
        if (ofVers.length < 2) {
            return null;
        }
        final String mcVer = ofVers[1];
        return mcVer;
    }
    
    private static String getLaunchwrapperVersion() throws IOException {
        final String fileLibs = "/launchwrapper-of.txt";
        final InputStream fin = Installer.class.getResourceAsStream(fileLibs);
        if (fin == null) {
            throw new IOException("File not found: " + fileLibs);
        }
        String str = Utils.readText(fin, "ASCII");
        str = str.trim();
        if (!str.matches("[0-9\\.]+")) {
            throw new IOException("Invalid launchwrapper version: " + str);
        }
        return str;
    }
}
