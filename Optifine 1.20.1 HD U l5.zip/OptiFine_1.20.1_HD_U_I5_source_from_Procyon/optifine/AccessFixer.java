// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import org.objectweb.asm.tree.AbstractInsnNode;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.Map;
import java.util.List;
import org.objectweb.asm.tree.InnerClassNode;
import java.util.function.Function;
import java.util.stream.StreamSupport;
import java.util.Iterator;
import java.util.Spliterators;
import org.objectweb.asm.tree.MethodInsnNode;
import java.util.ArrayList;
import org.objectweb.asm.tree.MethodNode;
import java.util.HashSet;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.ClassNode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AccessFixer
{
    private static final Logger LOGGER;
    
    static {
        LOGGER = LogManager.getLogger();
    }
    
    public static void fixMemberAccess(final ClassNode classOld, final ClassNode classNew) {
        final List<FieldNode> fieldsOld = (List<FieldNode>)classOld.fields;
        final List<FieldNode> fieldsNew = (List<FieldNode>)classNew.fields;
        final Map<String, FieldNode> mapFieldsOld = getMapFields(fieldsOld);
        for (final FieldNode fieldNew : fieldsNew) {
            final String idNew = fieldNew.name;
            final FieldNode fieldOld = mapFieldsOld.get(idNew);
            if (fieldOld == null) {
                continue;
            }
            if (fieldNew.access == fieldOld.access) {
                continue;
            }
            fieldNew.access = combineAccess(fieldNew.access, fieldOld.access);
        }
        final List<MethodNode> methodsOld = (List<MethodNode>)classOld.methods;
        final List<MethodNode> methodsNew = (List<MethodNode>)classNew.methods;
        final Map<String, MethodNode> mapMethodsOld = getMapMethods(methodsOld);
        final Set<String> privateChanged = new HashSet<String>();
        for (final MethodNode methodNew : methodsNew) {
            final String idNew2 = String.valueOf(methodNew.name) + methodNew.desc;
            final MethodNode methodOld = mapMethodsOld.get(idNew2);
            if (methodOld == null) {
                continue;
            }
            if (methodNew.access == methodOld.access) {
                continue;
            }
            final int accessPrev = methodNew.access;
            methodNew.access = combineAccess(methodNew.access, methodOld.access);
            if (!isSet(accessPrev, 2) || isSet(methodNew.access, 2) || isSet(methodNew.access, 8) || methodNew.name.equals("<init>")) {
                continue;
            }
            privateChanged.add(String.valueOf(methodNew.name) + methodNew.desc);
        }
        if (!privateChanged.isEmpty()) {
            final List<MethodInsnNode> changed = new ArrayList<MethodInsnNode>();
            final List<MethodInsnNode> list;
            classNew.methods.forEach(mn -> StreamSupport.stream(Spliterators.spliteratorUnknownSize((Iterator<?>)mn.instructions.iterator(), 16), false).filter(i -> i.getOpcode() == 183).map((Function<? super Object, ?>)MethodInsnNode.class::cast).filter(m -> privateChanged.contains(String.valueOf(m.name) + m.desc)).forEach(m -> {
                m.setOpcode(182);
                list.add(m);
            }));
        }
        final List<InnerClassNode> innerClassesOld = (List<InnerClassNode>)classOld.innerClasses;
        final List<InnerClassNode> innerClassesNew = (List<InnerClassNode>)classNew.innerClasses;
        final Map<String, InnerClassNode> mapInnerClassesOld = getMapInnerClasses(innerClassesOld);
        for (final InnerClassNode innerClassNew : innerClassesNew) {
            final String idNew3 = innerClassNew.name;
            final InnerClassNode innerClassOld = mapInnerClassesOld.get(idNew3);
            if (innerClassOld == null) {
                continue;
            }
            if (innerClassNew.access == innerClassOld.access) {
                continue;
            }
            final int accessNew = combineAccess(innerClassNew.access, innerClassOld.access);
            innerClassNew.access = accessNew;
        }
        if (classNew.access != classOld.access) {
            final int accessClassNew = combineAccess(classNew.access, classOld.access);
            classNew.access = accessClassNew;
        }
    }
    
    private static int combineAccess(final int access, final int access2) {
        if (access == access2) {
            return access;
        }
        final int MASK_ACCESS = 7;
        int accessClean = access & ~MASK_ACCESS;
        if (!isSet(access, 16) || !isSet(access2, 16)) {
            accessClean &= 0xFFFFFFEF;
        }
        if (isSet(access, 1) || isSet(access2, 1)) {
            return accessClean | 0x1;
        }
        if (isSet(access, 4) || isSet(access2, 4)) {
            return accessClean | 0x4;
        }
        if (!isSet(access, MASK_ACCESS) || !isSet(access2, MASK_ACCESS)) {
            return accessClean;
        }
        if (isSet(access, 2) || isSet(access2, 2)) {
            return accessClean | 0x2;
        }
        return accessClean;
    }
    
    private static boolean isSet(final int access, final int flag) {
        return (access & flag) != 0x0;
    }
    
    public static Map<String, FieldNode> getMapFields(final List<FieldNode> fields) {
        final Map<String, FieldNode> map = new LinkedHashMap<String, FieldNode>();
        for (final FieldNode fieldNode : fields) {
            final String id = fieldNode.name;
            map.put(id, fieldNode);
        }
        return map;
    }
    
    public static Map<String, MethodNode> getMapMethods(final List<MethodNode> methods) {
        final Map<String, MethodNode> map = new LinkedHashMap<String, MethodNode>();
        for (final MethodNode methodNode : methods) {
            final String id = String.valueOf(methodNode.name) + methodNode.desc;
            map.put(id, methodNode);
        }
        return map;
    }
    
    public static Map<String, InnerClassNode> getMapInnerClasses(final List<InnerClassNode> innerClasses) {
        final Map<String, InnerClassNode> map = new LinkedHashMap<String, InnerClassNode>();
        for (final InnerClassNode innerClassNode : innerClasses) {
            final String id = innerClassNode.name;
            map.put(id, innerClassNode);
        }
        return map;
    }
    
    private static String toString(final int access) {
        final StringBuffer sb = new StringBuffer();
        if (isSet(access, 1)) {
            addToBuffer(sb, "public", " ");
        }
        if (isSet(access, 4)) {
            addToBuffer(sb, "protected", " ");
        }
        if (isSet(access, 2)) {
            addToBuffer(sb, "private", " ");
        }
        if (isSet(access, 16)) {
            addToBuffer(sb, "final", " ");
        }
        return sb.toString();
    }
    
    private static void addToBuffer(final StringBuffer sb, final String val, final String separator) {
        if (sb.length() > 0) {
            sb.append(separator);
        }
        sb.append(val);
    }
}
