// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.ArrayList;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassReader;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Optional;
import cpw.mods.modlauncher.api.TypesafeMap;
import java.util.HashSet;
import java.util.Set;
import cpw.mods.modlauncher.api.TransformerVoteResult;
import cpw.mods.modlauncher.api.ITransformerVotingContext;
import java.io.IOException;
import cpw.mods.modlauncher.api.IEnvironment;
import org.apache.logging.log4j.LogManager;
import java.util.regex.Pattern;
import java.util.Map;
import java.util.zip.ZipFile;
import org.apache.logging.log4j.Logger;
import org.objectweb.asm.tree.ClassNode;
import cpw.mods.modlauncher.api.ITransformer;

public class OptiFineTransformer implements ITransformer<ClassNode>, IResourceProvider, IOptiFineResourceLocator
{
    private static final Logger LOGGER;
    private ZipFile ofZipFile;
    private Map<String, String> patchMap;
    private Pattern[] patterns;
    public static final String PREFIX_SRG = "srg/";
    public static final String SUFFIX_CLASS = ".class";
    public static final String PREFIX_PATCH_SRG = "patch/srg/";
    public static final String SUFFIX_CLASS_XDELTA = ".class.xdelta";
    public static final String PREFIX_OPTIFINE = "optifine/";
    private final boolean hasTargetPreClass;
    
    static {
        LOGGER = LogManager.getLogger();
    }
    
    public OptiFineTransformer(final ZipFile ofZipFile, final IEnvironment env) {
        this.patchMap = null;
        this.patterns = null;
        this.ofZipFile = ofZipFile;
        this.hasTargetPreClass = hasTargetPreClass(env);
        if (this.hasTargetPreClass) {
            OptiFineTransformer.LOGGER.info("Target.PRE_CLASS is available");
        }
        else {
            OptiFineTransformer.LOGGER.info("Target.PRE_CLASS is not available");
        }
        try {
            this.patchMap = Patcher.getConfigurationMap(ofZipFile);
            this.patterns = Patcher.getConfigurationPatterns(this.patchMap);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public TransformerVoteResult castVote(final ITransformerVotingContext context) {
        return TransformerVoteResult.YES;
    }
    
    public Set<ITransformer.Target> targets() {
        final Set<ITransformer.Target> set = new HashSet<ITransformer.Target>();
        String[] names = this.getResourceNames("srg/", ".class");
        final String[] namesPatch = this.getResourceNames("patch/srg/", ".class.xdelta");
        names = (String[])Utils.addObjectsToArray(names, namesPatch);
        for (int i = 0; i < names.length; ++i) {
            String name = names[i];
            name = Utils.removePrefix(name, new String[] { "srg/", "patch/srg/" });
            name = Utils.removeSuffix(name, new String[] { ".class", ".class.xdelta" });
            if (!name.startsWith("net/optifine/")) {
                final ITransformer.Target itt = this.getTargetClass(name);
                set.add(itt);
            }
        }
        OptiFineTransformer.LOGGER.info("Targets: " + set.size());
        return set;
    }
    
    private ITransformer.Target getTargetClass(final String name) {
        if (this.hasTargetPreClass) {
            return this.getTargetPreClass(name);
        }
        return ITransformer.Target.targetClass(name);
    }
    
    private ITransformer.Target getTargetPreClass(final String name) {
        return ITransformer.Target.targetPreClass(name);
    }
    
    private static boolean hasTargetPreClass(final IEnvironment env) {
        final Optional<String> mlVer = (Optional<String>)env.getProperty((TypesafeMap.Key)IEnvironment.Keys.MLSPEC_VERSION.get());
        if (!mlVer.isPresent()) {
            return false;
        }
        final String[] parts = Utils.tokenize(mlVer.get(), ".");
        if (parts.length <= 0) {
            return false;
        }
        final String majorStr = parts[0];
        final int major = Utils.parseInt(majorStr, -1);
        return major >= 7;
    }
    
    public ClassNode transform(final ClassNode input, final ITransformerVotingContext context) {
        ClassNode classNode = input;
        final String className = context.getClassName();
        final String classNameZip = className.replace('.', '/');
        final byte[] bytes = this.getOptiFineResource("srg/" + classNameZip + ".class");
        if (bytes != null) {
            final InputStream in = new ByteArrayInputStream(bytes);
            final ClassNode classNodeNew = this.loadClass(in);
            if (classNodeNew != null) {
                this.debugClass(classNodeNew);
                AccessFixer.fixMemberAccess(classNode, classNodeNew);
                classNode = classNodeNew;
            }
        }
        return classNode;
    }
    
    private void debugClass(final ClassNode classNode) {
    }
    
    private ClassNode loadClass(final InputStream in) {
        try {
            final ClassReader cr = new ClassReader(in);
            final ClassNode cn = new ClassNode(393216);
            cr.accept((ClassVisitor)cn, 0);
            return cn;
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    private String[] getResourceNames(final String prefix, final String suffix) {
        final List<String> list = new ArrayList<String>();
        final Enumeration<? extends ZipEntry> entries = this.ofZipFile.entries();
        while (entries.hasMoreElements()) {
            final ZipEntry zipEntry = (ZipEntry)entries.nextElement();
            final String name = zipEntry.getName();
            if (!name.startsWith(prefix)) {
                continue;
            }
            if (!name.endsWith(suffix)) {
                continue;
            }
            list.add(name);
        }
        final String[] names = list.toArray(new String[list.size()]);
        return names;
    }
    
    private byte[] getOptiFineResource(final String name) {
        try {
            final InputStream in = this.getOptiFineResourceStream(name);
            if (in == null) {
                return null;
            }
            final byte[] bytes = Utils.readAll(in);
            in.close();
            return bytes;
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public synchronized InputStream getOptiFineResourceStream(String name) {
        name = Utils.removePrefix(name, "/");
        InputStream in = this.getOptiFineResourceStreamZip(name);
        if (in != null) {
            return in;
        }
        in = this.getOptiFineResourceStreamPatched(name);
        if (in != null) {
            return in;
        }
        return null;
    }
    
    public InputStream getResourceStream(String path) {
        path = Utils.removePrefix(path, "/");
        return ClassLoader.getSystemClassLoader().getResourceAsStream(path);
    }
    
    public synchronized InputStream getOptiFineResourceStreamZip(String name) {
        if (this.ofZipFile == null) {
            return null;
        }
        name = Utils.removePrefix(name, "/");
        final ZipEntry ze = this.ofZipFile.getEntry(name);
        if (ze == null) {
            return null;
        }
        try {
            final InputStream in = this.ofZipFile.getInputStream(ze);
            return in;
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public synchronized byte[] getOptiFineResourceZip(final String name) {
        final InputStream in = this.getOptiFineResourceStreamZip(name);
        if (in == null) {
            return null;
        }
        try {
            final byte[] bytes = Utils.readAll(in);
            return bytes;
        }
        catch (IOException e) {
            return null;
        }
    }
    
    public synchronized InputStream getOptiFineResourceStreamPatched(final String name) {
        final byte[] bytes = this.getOptiFineResourcePatched(name);
        if (bytes == null) {
            return null;
        }
        return new ByteArrayInputStream(bytes);
    }
    
    public synchronized byte[] getOptiFineResourcePatched(String name) {
        if (this.patterns == null || this.patchMap == null) {
            return null;
        }
        name = Utils.removePrefix(name, "/");
        final String patchName = "patch/" + name + ".xdelta";
        final byte[] bytes = this.getOptiFineResourceZip(patchName);
        if (bytes == null) {
            return null;
        }
        try {
            final byte[] bytesPatched = Patcher.applyPatch(name, bytes, this.patterns, this.patchMap, this);
            final String fullMd5Name = "patch/" + name + ".md5";
            final byte[] bytesMd5 = this.getOptiFineResourceZip(fullMd5Name);
            if (bytesMd5 != null) {
                final String md5Str = new String(bytesMd5, "ASCII");
                final byte[] md5Mod = HashUtils.getHashMd5(bytesPatched);
                final String md5ModStr = HashUtils.toHexString(md5Mod);
                if (!md5Str.equals(md5ModStr)) {
                    throw new IOException("MD5 not matching, name: " + name + ", saved: " + md5Str + ", patched: " + md5ModStr);
                }
            }
            return bytesPatched;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
