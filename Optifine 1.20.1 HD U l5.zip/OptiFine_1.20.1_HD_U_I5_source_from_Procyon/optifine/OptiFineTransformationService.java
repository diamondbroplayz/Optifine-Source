// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import cpw.mods.modlauncher.api.ITransformer;
import java.util.zip.ZipEntry;
import java.io.IOException;
import java.util.AbstractMap;
import java.util.HashSet;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.Map;
import java.nio.file.FileSystems;
import java.util.HashMap;
import java.io.File;
import java.net.URI;
import cpw.mods.modlauncher.api.IncompatibleEnvironmentException;
import java.util.Set;
import cpw.mods.jarhandling.SecureJar;
import java.util.ArrayList;
import cpw.mods.modlauncher.api.IModuleLayerManager;
import java.util.List;
import cpw.mods.modlauncher.api.IEnvironment;
import org.apache.logging.log4j.LogManager;
import java.nio.file.Path;
import java.util.zip.ZipFile;
import java.net.URL;
import org.apache.logging.log4j.Logger;
import cpw.mods.modlauncher.api.ITransformationService;

public class OptiFineTransformationService implements ITransformationService
{
    private static final Logger LOGGER;
    private static URL ofZipFileUrl;
    private static ZipFile ofZipFile;
    private static Path ofZipFilePath;
    private static OptiFineTransformer transformer;
    
    static {
        LOGGER = LogManager.getLogger();
    }
    
    public String name() {
        return "OptiFine";
    }
    
    public void initialize(final IEnvironment environment) {
        OptiFineTransformationService.LOGGER.info("OptiFineTransformationService.initialize");
    }
    
    public List<ITransformationService.Resource> beginScanning(final IEnvironment environment) {
        return List.of();
    }
    
    public List<ITransformationService.Resource> completeScan(final IModuleLayerManager layerManager) {
        final List<ITransformationService.Resource> list = new ArrayList<ITransformationService.Resource>();
        final List<SecureJar> jarList = new ArrayList<SecureJar>();
        jarList.add((SecureJar)new OptiFineJar(new Path[] { OptiFineTransformationService.ofZipFilePath }));
        list.add(new ITransformationService.Resource(IModuleLayerManager.Layer.GAME, (List)jarList));
        return list;
    }
    
    public void onLoad(final IEnvironment env, final Set<String> otherServices) throws IncompatibleEnvironmentException {
        OptiFineTransformationService.LOGGER.info("OptiFineTransformationService.onLoad");
        OptiFineTransformationService.ofZipFileUrl = OptiFineTransformer.class.getProtectionDomain().getCodeSource().getLocation();
        OptiFineTransformationService.LOGGER.info("OptiFine ZIP file URL: " + OptiFineTransformationService.ofZipFileUrl);
        try {
            final URI uri = OptiFineTransformationService.ofZipFileUrl.toURI();
            final File file = toFile(uri);
            OptiFineTransformationService.ofZipFile = new ZipFile(file);
            OptiFineTransformationService.LOGGER.info("OptiFine ZIP file: " + file);
            OptiFineTransformationService.ofZipFilePath = file.toPath();
            OptiFineResourceLocator.setResourceLocator(OptiFineTransformationService.transformer = new OptiFineTransformer(OptiFineTransformationService.ofZipFile, env));
        }
        catch (Exception e) {
            OptiFineTransformationService.LOGGER.error("Error loading OptiFine ZIP file: " + OptiFineTransformationService.ofZipFileUrl, (Throwable)e);
            throw new IncompatibleEnvironmentException("Error loading OptiFine ZIP file: " + OptiFineTransformationService.ofZipFileUrl);
        }
    }
    
    public static File toFile(final URI uri) {
        if (!"union".equals(uri.getScheme())) {
            return new File(uri);
        }
        try {
            String path = uri.getPath();
            if (path.contains("#")) {
                path = path.substring(0, path.lastIndexOf("#"));
            }
            final File file = new File(path);
            OptiFineTransformationService.ofZipFileUrl = file.toURI().toURL();
            final Map<String, String> map = new HashMap<String, String>();
            map.put("create", "true");
            FileSystems.newFileSystem(URI.create("jar:" + OptiFineTransformationService.ofZipFileUrl + "!/"), map);
            return file;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public Map.Entry<Set<String>, Supplier<Function<String, Optional<URL>>>> additionalResourcesLocator() {
        return (Map.Entry<Set<String>, Supplier<Function<String, Optional<URL>>>>)super.additionalResourcesLocator();
    }
    
    public Map.Entry<Set<String>, Supplier<Function<String, Optional<URL>>>> additionalClassesLocator() {
        final Set<String> key = new HashSet<String>();
        key.add("net.optifine.");
        key.add("optifine.");
        final Supplier<Function<String, Optional<URL>>> value = (Supplier<Function<String, Optional<URL>>>)(() -> OptiFineTransformationService::getResourceUrl);
        final Map.Entry<Set<String>, Supplier<Function<String, Optional<URL>>>> entry = new AbstractMap.SimpleEntry<Set<String>, Supplier<Function<String, Optional<URL>>>>(key, value);
        OptiFineTransformationService.LOGGER.info("additionalClassesLocator: " + key);
        return entry;
    }
    
    public static Optional<URL> getResourceUrl(String name) {
        if (name.endsWith(".class") && !name.startsWith("optifine/")) {
            name = "srg/" + name;
        }
        if (OptiFineTransformationService.transformer == null) {
            return Optional.empty();
        }
        final ZipEntry ze = OptiFineTransformationService.ofZipFile.getEntry(name);
        if (ze == null) {
            return Optional.empty();
        }
        try {
            final String ofZipUrlStr = OptiFineTransformationService.ofZipFileUrl.toExternalForm();
            final URL urlJar = new URL("jar:" + ofZipUrlStr + "!/" + name);
            return Optional.of(urlJar);
        }
        catch (IOException e) {
            OptiFineTransformationService.LOGGER.error((Object)e);
            return Optional.empty();
        }
    }
    
    public List<ITransformer> transformers() {
        OptiFineTransformationService.LOGGER.info("OptiFineTransformationService.transformers");
        final List<ITransformer> list = new ArrayList<ITransformer>();
        if (OptiFineTransformationService.transformer != null) {
            list.add((ITransformer)OptiFineTransformationService.transformer);
        }
        return list;
    }
    
    public static OptiFineTransformer getTransformer() {
        return OptiFineTransformationService.transformer;
    }
    
    public static ZipFile getOfZipFile() {
        return OptiFineTransformationService.ofZipFile;
    }
}
