// 
// Decompiled by Procyon v0.5.36
// 

package optifine.json;

import java.util.Iterator;
import java.util.Set;
import java.io.IOException;
import java.io.Writer;

public class JSONWriter
{
    private Writer writer;
    private int indentStep;
    private int indent;
    
    public JSONWriter(final Writer writer) {
        this.writer = null;
        this.indentStep = 2;
        this.indent = 0;
        this.writer = writer;
    }
    
    public JSONWriter(final Writer writer, final int indentStep) {
        this.writer = null;
        this.indentStep = 2;
        this.indent = 0;
        this.writer = writer;
        this.indentStep = indentStep;
    }
    
    public JSONWriter(final Writer writer, final int indentStep, final int indent) {
        this.writer = null;
        this.indentStep = 2;
        this.indent = 0;
        this.writer = writer;
        this.indentStep = indentStep;
        this.indent = indent;
    }
    
    public void writeObject(final Object obj) throws IOException {
        if (obj instanceof JSONObject) {
            final JSONObject jObj = (JSONObject)obj;
            this.writeJsonObject(jObj);
            return;
        }
        if (obj instanceof JSONArray) {
            final JSONArray jArr = (JSONArray)obj;
            this.writeJsonArray(jArr);
            return;
        }
        this.writer.write(JSONValue.toJSONString(obj));
    }
    
    private void writeJsonArray(final JSONArray jArr) throws IOException {
        this.writeLine("[");
        this.indentAdd();
        for (int num = jArr.size(), i = 0; i < num; ++i) {
            final Object val = jArr.get(i);
            this.writeIndent();
            this.writeObject(val);
            if (i < jArr.size() - 1) {
                this.write(",");
            }
            this.writeLine("");
        }
        this.indentRemove();
        this.writeIndent();
        this.writer.write("]");
    }
    
    private void writeJsonObject(final JSONObject jObj) throws IOException {
        this.writeLine("{");
        this.indentAdd();
        final Set keys = jObj.keySet();
        final int keyNum = keys.size();
        int count = 0;
        for (final String key : keys) {
            final Object val = jObj.get(key);
            this.writeIndent();
            this.writer.write(JSONValue.toJSONString(key));
            this.writer.write(": ");
            this.writeObject(val);
            if (++count < keyNum) {
                this.writeLine(",");
            }
            else {
                this.writeLine("");
            }
        }
        this.indentRemove();
        this.writeIndent();
        this.writer.write("}");
    }
    
    private void writeLine(final String str) throws IOException {
        this.writer.write(str);
        this.writer.write("\n");
    }
    
    private void write(final String str) throws IOException {
        this.writer.write(str);
    }
    
    private void writeIndent() throws IOException {
        for (int i = 0; i < this.indent; ++i) {
            this.writer.write(32);
        }
    }
    
    private void indentAdd() {
        this.indent += this.indentStep;
    }
    
    private void indentRemove() {
        this.indent -= this.indentStep;
    }
}
