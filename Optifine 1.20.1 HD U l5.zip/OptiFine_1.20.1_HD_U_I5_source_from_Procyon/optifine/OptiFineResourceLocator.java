// 
// Decompiled by Procyon v0.5.36
// 

package optifine;

import java.io.InputStream;

public class OptiFineResourceLocator
{
    private static IOptiFineResourceLocator resourceLocator;
    
    public static void setResourceLocator(final IOptiFineResourceLocator resourceLocator) {
        OptiFineResourceLocator.resourceLocator = resourceLocator;
        final Class cls = OptiFineResourceLocator.class;
        System.getProperties().put(String.valueOf(cls.getName()) + ".class", cls);
    }
    
    public static InputStream getOptiFineResourceStream(final String name) {
        if (OptiFineResourceLocator.resourceLocator == null) {
            return null;
        }
        return OptiFineResourceLocator.resourceLocator.getOptiFineResourceStream(name);
    }
}
