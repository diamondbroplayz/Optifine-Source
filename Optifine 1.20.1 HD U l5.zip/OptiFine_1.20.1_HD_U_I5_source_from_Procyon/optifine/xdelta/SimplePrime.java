// 
// Decompiled by Procyon v0.5.36
// 

package optifine.xdelta;

public class SimplePrime
{
    private SimplePrime() {
    }
    
    public static long belowOrEqual(long number) {
        if (number < 2L) {
            return 0L;
        }
        if (number == 2L) {
            return 2L;
        }
        if ((number & 0x1L) == 0x0L) {
            --number;
        }
        while (!testPrime(number)) {
            number -= 2L;
            if (number <= 2L) {
                return 2L;
            }
        }
        return number;
    }
    
    public static long aboveOrEqual(long number) {
        if (number <= 2L) {
            return 2L;
        }
        if ((number & 0x1L) == 0x0L) {
            ++number;
        }
        while (!testPrime(number)) {
            number += 2L;
            if (number < 0L) {
                return 0L;
            }
        }
        return number;
    }
    
    public static boolean testPrime(final long number) {
        if (number == 2L) {
            return true;
        }
        if (number < 2L) {
            return false;
        }
        if ((number & 0x1L) == 0x0L) {
            return false;
        }
        for (long sqrt = (long)Math.floor(Math.sqrt((double)number)), i = 3L; i <= sqrt; i += 2L) {
            if (number % i == 0L) {
                return false;
            }
        }
        return true;
    }
}
