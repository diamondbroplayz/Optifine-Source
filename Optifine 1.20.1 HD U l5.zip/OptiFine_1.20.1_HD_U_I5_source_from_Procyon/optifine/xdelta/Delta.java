// 
// Decompiled by Procyon v0.5.36
// 

package optifine.xdelta;

import java.io.DataOutputStream;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.RandomAccessFile;
import java.io.File;
import java.io.IOException;
import java.io.PushbackInputStream;
import java.io.BufferedInputStream;
import java.io.InputStream;

public class Delta
{
    public static final int S = 16;
    public static final boolean debug = false;
    public static final int buff_size = 1024;
    
    public static void computeDelta(final SeekableSource source, final InputStream targetIS, final int targetLength, final DiffWriter output) throws IOException, DeltaException {
        final int sourceLength = (int)source.length();
        final Checksum checksum = new Checksum();
        checksum.generateChecksums(new SeekableSourceInputStream(source), sourceLength);
        source.seek(0L);
        final PushbackInputStream target = new PushbackInputStream(new BufferedInputStream(targetIS), 1024);
        boolean done = false;
        final byte[] buf = new byte[16];
        long hashf = 0L;
        final byte[] b = { 0 };
        final byte[] sourcebyte = new byte[16];
        if (targetLength > 16) {
            if (sourceLength > 16) {
                int targetidx;
                final int bytesRead = targetidx = target.read(buf, 0, 16);
                long alternativehashf;
                hashf = (alternativehashf = Checksum.queryChecksum(buf, 16));
                boolean sourceOutofBytes = false;
                while (!done) {
                    final int index = checksum.findChecksumIndex(hashf);
                    if (index != -1) {
                        boolean match = true;
                        final int offset = index * 16;
                        int length = 15;
                        source.seek(offset);
                        if (!sourceOutofBytes && source.read(sourcebyte, 0, 16) != -1) {
                            for (int ix = 0; ix < 16; ++ix) {
                                if (sourcebyte[ix] != buf[ix]) {
                                    match = false;
                                }
                            }
                        }
                        else {
                            sourceOutofBytes = true;
                        }
                        if (match & !sourceOutofBytes) {
                            final long start = System.currentTimeMillis();
                            boolean ok = true;
                            final byte[] sourceBuff = new byte[1024];
                            final byte[] targetBuff = new byte[1024];
                            int source_idx = 0;
                            int target_idx = 0;
                            final int tCount = 0;
                            do {
                                source_idx = source.read(sourceBuff, 0, 1024);
                                if (source_idx == -1) {
                                    sourceOutofBytes = true;
                                    break;
                                }
                                target_idx = target.read(targetBuff, 0, source_idx);
                                if (target_idx == -1) {
                                    break;
                                }
                                final int read_idx = Math.min(source_idx, target_idx);
                                int i = 0;
                                do {
                                    ++targetidx;
                                    ++length;
                                    ok = (sourceBuff[i] == targetBuff[i]);
                                    ++i;
                                    if (!ok) {
                                        b[0] = targetBuff[i - 1];
                                        if (target_idx == -1) {
                                            continue;
                                        }
                                        target.unread(targetBuff, i, target_idx - i);
                                    }
                                } while (i < read_idx && ok);
                                b[0] = targetBuff[i - 1];
                            } while (ok && targetLength - targetidx > 0);
                            output.addCopy(offset, length);
                            if (targetLength - targetidx <= 15) {
                                buf[0] = b[0];
                                final int remaining = targetLength - targetidx;
                                final int readStatus = target.read(buf, 1, remaining);
                                targetidx += remaining;
                                for (int ix2 = 0; ix2 < remaining + 1; ++ix2) {
                                    output.addData(buf[ix2]);
                                }
                                done = true;
                                continue;
                            }
                            buf[0] = b[0];
                            target.read(buf, 1, 15);
                            targetidx += 15;
                            hashf = (alternativehashf = Checksum.queryChecksum(buf, 16));
                            continue;
                        }
                    }
                    if (targetLength - targetidx > 0) {
                        target.read(b, 0, 1);
                        ++targetidx;
                        output.addData(buf[0]);
                        alternativehashf = Checksum.incrementChecksum(alternativehashf, buf[0], b[0]);
                        for (int j = 0; j < 15; ++j) {
                            buf[j] = buf[j + 1];
                        }
                        buf[15] = b[0];
                        hashf = Checksum.queryChecksum(buf, 16);
                    }
                    else {
                        for (int ix3 = 0; ix3 < 16; ++ix3) {
                            output.addData(buf[ix3]);
                        }
                        done = true;
                    }
                }
                return;
            }
        }
        int readBytes;
        while ((readBytes = target.read(buf)) >= 0) {
            for (int k = 0; k < readBytes; ++k) {
                output.addData(buf[k]);
            }
        }
    }
    
    public static void computeDelta(final byte[] source, final InputStream targetIS, final int targetLength, final DiffWriter output) throws IOException, DeltaException {
        computeDelta(new ByteArraySeekableSource(source), targetIS, targetLength, output);
    }
    
    public static void computeDelta(final File sourceFile, final File targetFile, final DiffWriter output) throws IOException, DeltaException {
        final int targetLength = (int)targetFile.length();
        final SeekableSource source = new RandomAccessFileSeekableSource(new RandomAccessFile(sourceFile, "r"));
        final InputStream targetIS = new FileInputStream(targetFile);
        try {
            computeDelta(source, targetIS, targetLength, output);
        }
        catch (IOException e) {
            throw e;
        }
        catch (DeltaException e2) {
            throw e2;
        }
        finally {
            output.flush();
            source.close();
            targetIS.close();
            output.close();
        }
        output.flush();
        source.close();
        targetIS.close();
        output.close();
    }
    
    public static void main(final String[] argv) {
        final Delta delta = new Delta();
        if (argv.length != 3) {
            System.err.println("usage Delta [-d] source target [output]");
            System.err.println("either -d or an output filename must be specified.");
            System.err.println("aborting..");
            return;
        }
        try {
            DiffWriter output = null;
            File sourceFile = null;
            File targetFile = null;
            if (argv[0].equals("-d")) {
                sourceFile = new File(argv[1]);
                targetFile = new File(argv[2]);
                output = new DebugDiffWriter();
            }
            else {
                sourceFile = new File(argv[0]);
                targetFile = new File(argv[1]);
                output = new GDiffWriter(new DataOutputStream(new BufferedOutputStream(new FileOutputStream(new File(argv[2])))));
            }
            if (sourceFile.length() > 2147483647L || targetFile.length() > 2147483647L) {
                System.err.println("source or target is too large, max length is 2147483647");
                System.err.println("aborting..");
                return;
            }
            computeDelta(sourceFile, targetFile, output);
            output.flush();
            output.close();
        }
        catch (Exception e) {
            System.err.println("error while generating delta: " + e);
        }
    }
}
