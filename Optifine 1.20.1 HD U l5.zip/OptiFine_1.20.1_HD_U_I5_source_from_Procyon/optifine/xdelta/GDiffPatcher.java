// 
// Decompiled by Procyon v0.5.36
// 

package optifine.xdelta;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.RandomAccessFile;
import java.io.File;

public class GDiffPatcher
{
    public GDiffPatcher(final File sourceFile, final File patchFile, final File outputFile) throws IOException, PatchException {
        final RandomAccessFileSeekableSource source = new RandomAccessFileSeekableSource(new RandomAccessFile(sourceFile, "r"));
        final InputStream patch = new FileInputStream(patchFile);
        final OutputStream output = new FileOutputStream(outputFile);
        try {
            runPatch(source, patch, output);
        }
        catch (IOException e) {
            throw e;
        }
        catch (PatchException e2) {
            throw e2;
        }
        finally {
            source.close();
            patch.close();
            output.close();
        }
        source.close();
        patch.close();
        output.close();
    }
    
    public GDiffPatcher(final byte[] source, final InputStream patch, final OutputStream output) throws IOException, PatchException {
        this(new ByteArraySeekableSource(source), patch, output);
    }
    
    public GDiffPatcher(final SeekableSource source, final InputStream patch, final OutputStream out) throws IOException, PatchException {
        runPatch(source, patch, out);
    }
    
    private static void runPatch(final SeekableSource source, final InputStream patch, final OutputStream out) throws IOException, PatchException {
        final DataOutputStream outOS = new DataOutputStream(out);
        final DataInputStream patchIS = new DataInputStream(patch);
        try {
            final byte[] buf = new byte[256];
            int i = 0;
            if (patchIS.readUnsignedByte() != 209 || patchIS.readUnsignedByte() != 255 || patchIS.readUnsignedByte() != 209 || patchIS.readUnsignedByte() != 255 || patchIS.readUnsignedByte() != 4) {
                System.err.println("magic string not found, aborting!");
                return;
            }
            i += 5;
            while (patchIS.available() > 0) {
                final int command = patchIS.readUnsignedByte();
                int length = 0;
                int offset = 0;
                switch (command) {
                    case 0: {
                        continue;
                    }
                    case 1: {
                        append(1, patchIS, outOS);
                        i += 2;
                        continue;
                    }
                    case 2: {
                        append(2, patchIS, outOS);
                        i += 3;
                        continue;
                    }
                    case 246: {
                        append(246, patchIS, outOS);
                        i += 247;
                        continue;
                    }
                    case 247: {
                        length = patchIS.readUnsignedShort();
                        append(length, patchIS, outOS);
                        i += length + 3;
                        continue;
                    }
                    case 248: {
                        length = patchIS.readInt();
                        append(length, patchIS, outOS);
                        i += length + 5;
                        continue;
                    }
                    case 249: {
                        offset = patchIS.readUnsignedShort();
                        length = patchIS.readUnsignedByte();
                        copy(offset, length, source, outOS);
                        i += 4;
                        continue;
                    }
                    case 250: {
                        offset = patchIS.readUnsignedShort();
                        length = patchIS.readUnsignedShort();
                        copy(offset, length, source, outOS);
                        i += 5;
                        continue;
                    }
                    case 251: {
                        offset = patchIS.readUnsignedShort();
                        length = patchIS.readInt();
                        copy(offset, length, source, outOS);
                        i += 7;
                        continue;
                    }
                    case 252: {
                        offset = patchIS.readInt();
                        length = patchIS.readUnsignedByte();
                        copy(offset, length, source, outOS);
                        i += 8;
                        continue;
                    }
                    case 253: {
                        offset = patchIS.readInt();
                        length = patchIS.readUnsignedShort();
                        copy(offset, length, source, outOS);
                        i += 7;
                        continue;
                    }
                    case 254: {
                        offset = patchIS.readInt();
                        length = patchIS.readInt();
                        copy(offset, length, source, outOS);
                        i += 9;
                        continue;
                    }
                    case 255: {
                        final long loffset = patchIS.readLong();
                        length = patchIS.readInt();
                        copy(loffset, length, source, outOS);
                        i += 13;
                        continue;
                    }
                    default: {
                        append(command, patchIS, outOS);
                        i += command + 1;
                        continue;
                    }
                }
            }
        }
        catch (PatchException e) {
            throw e;
        }
        finally {
            outOS.flush();
        }
        outOS.flush();
    }
    
    protected static void copy(final long offset, int length, final SeekableSource source, final OutputStream output) throws IOException, PatchException {
        if (offset + length > source.length()) {
            throw new PatchException("truncated source file, aborting");
        }
        final byte[] buf = new byte[256];
        source.seek(offset);
        while (length > 0) {
            final int len = (length > 256) ? 256 : length;
            final int res = source.read(buf, 0, len);
            output.write(buf, 0, res);
            length -= res;
        }
    }
    
    protected static void append(int length, final InputStream patch, final OutputStream output) throws IOException {
        final byte[] buf = new byte[256];
        while (length > 0) {
            final int len = (length > 256) ? 256 : length;
            final int res = patch.read(buf, 0, len);
            output.write(buf, 0, res);
            length -= res;
        }
    }
    
    public static void main(final String[] argv) {
        if (argv.length != 3) {
            System.err.println("usage GDiffPatch source patch output");
            System.err.println("aborting..");
            return;
        }
        try {
            final File sourceFile = new File(argv[0]);
            final File patchFile = new File(argv[1]);
            final File outputFile = new File(argv[2]);
            if (sourceFile.length() > 2147483647L || patchFile.length() > 2147483647L) {
                System.err.println("source or patch is too large, max length is 2147483647");
                System.err.println("aborting..");
                return;
            }
            final GDiffPatcher patcher = new GDiffPatcher(sourceFile, patchFile, outputFile);
            System.out.println("finished patching file");
        }
        catch (Exception ioe) {
            System.err.println("error while patching: " + ioe);
        }
    }
}
