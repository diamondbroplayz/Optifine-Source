// 
// Decompiled by Procyon v0.5.36
// 

package optifine.xdelta;

public class EratosthenesPrimes
{
    static BitArray sieve;
    static int lastInit;
    
    static {
        EratosthenesPrimes.lastInit = -1;
    }
    
    public static synchronized void reset() {
        EratosthenesPrimes.sieve = null;
        EratosthenesPrimes.lastInit = -1;
    }
    
    public static synchronized void init(int maxNumber) {
        if (maxNumber <= EratosthenesPrimes.lastInit) {
            return;
        }
        int sqrt = (int)Math.ceil(Math.sqrt(maxNumber));
        EratosthenesPrimes.lastInit = maxNumber;
        maxNumber >>= 1;
        ++maxNumber;
        sqrt >>= 1;
        ++sqrt;
        (EratosthenesPrimes.sieve = new BitArray(maxNumber + 1)).set(0, true);
        for (int i = 1; i <= sqrt; ++i) {
            if (!EratosthenesPrimes.sieve.get(i)) {
                for (int currentPrime = (i << 1) + 1, j = i * ((i << 1) + 2); j <= maxNumber; j += currentPrime) {
                    EratosthenesPrimes.sieve.set(j, true);
                }
            }
        }
    }
    
    public static synchronized int[] getPrimes(final int maxNumber) {
        final int primesNo = primesCount(maxNumber);
        if (primesNo <= 0) {
            return new int[0];
        }
        if (maxNumber == 2) {
            return new int[] { 2 };
        }
        init(maxNumber);
        final int[] primes = new int[primesNo];
        final int maxNumber_2 = maxNumber - 1 >> 1;
        int prime = 0;
        primes[prime++] = 2;
        for (int i = 1; i <= maxNumber_2; ++i) {
            if (!EratosthenesPrimes.sieve.get(i)) {
                primes[prime++] = (i << 1) + 1;
            }
        }
        return primes;
    }
    
    public static synchronized int primesCount(final int number) {
        if (number < 2) {
            return 0;
        }
        init(number);
        final int maxNumber_2 = number - 1 >> 1;
        int primesNo = 1;
        for (int i = 1; i <= maxNumber_2; ++i) {
            if (!EratosthenesPrimes.sieve.get(i)) {
                ++primesNo;
            }
        }
        return primesNo;
    }
    
    public static synchronized int belowOrEqual(final int number) {
        if (number < 2) {
            return -1;
        }
        if (number == 2) {
            return 2;
        }
        init(number);
        int i;
        for (int maxNumber_2 = i = number - 1 >> 1; i > 0; --i) {
            if (!EratosthenesPrimes.sieve.get(i)) {
                return (i << 1) + 1;
            }
        }
        return -1;
    }
    
    public static int below(final int number) {
        return belowOrEqual(number - 1);
    }
}
