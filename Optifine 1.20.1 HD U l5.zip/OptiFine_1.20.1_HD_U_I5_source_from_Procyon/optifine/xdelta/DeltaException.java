// 
// Decompiled by Procyon v0.5.36
// 

package optifine.xdelta;

public class DeltaException extends Exception
{
    public DeltaException() {
    }
    
    public DeltaException(final String msg) {
        super(msg);
    }
}
