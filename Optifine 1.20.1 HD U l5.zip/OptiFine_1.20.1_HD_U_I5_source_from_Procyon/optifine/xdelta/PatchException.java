// 
// Decompiled by Procyon v0.5.36
// 

package optifine.xdelta;

public class PatchException extends Exception
{
    public PatchException() {
    }
    
    public PatchException(final String msg) {
        super(msg);
    }
}
