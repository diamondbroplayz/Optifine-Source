// 
// Decompiled by Procyon v0.5.36
// 

package optifine.xdelta;

public class BitArray
{
    int[] implArray;
    int size;
    static final int INT_SIZE = 32;
    
    public BitArray(final int size) {
        final int implSize = size / 32 + 1;
        this.implArray = new int[implSize];
    }
    
    public void set(final int pos, final boolean value) {
        final int implPos = pos / 32;
        final int bitMask = 1 << (pos & 0x1F);
        if (value) {
            final int[] implArray = this.implArray;
            final int n = implPos;
            implArray[n] |= bitMask;
        }
        else {
            final int[] implArray2 = this.implArray;
            final int n2 = implPos;
            implArray2[n2] &= ~bitMask;
        }
    }
    
    public boolean get(final int pos) {
        final int implPos = pos / 32;
        final int bitMask = 1 << (pos & 0x1F);
        return (this.implArray[implPos] & bitMask) != 0x0;
    }
}
