// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.http;

import java.util.Iterator;
import java.util.Collection;
import java.io.InterruptedIOException;
import java.util.HashMap;
import java.io.InputStream;
import net.optifine.Config;
import java.util.LinkedHashMap;
import java.net.URL;
import java.io.IOException;
import java.net.Proxy;
import java.util.Map;

public class HttpPipeline
{
    private static Map mapConnections;
    public static final String HEADER_USER_AGENT = "User-Agent";
    public static final String HEADER_HOST = "Host";
    public static final String HEADER_ACCEPT = "Accept";
    public static final String HEADER_LOCATION = "Location";
    public static final String HEADER_KEEP_ALIVE = "Keep-Alive";
    public static final String HEADER_CONNECTION = "Connection";
    public static final String HEADER_VALUE_KEEP_ALIVE = "keep-alive";
    public static final String HEADER_TRANSFER_ENCODING = "Transfer-Encoding";
    public static final String HEADER_VALUE_CHUNKED = "chunked";
    
    private HttpPipeline() {
    }
    
    public static void addRequest(final String urlStr, final HttpListener listener) throws IOException {
        addRequest(urlStr, listener, Proxy.NO_PROXY);
    }
    
    public static void addRequest(final String urlStr, final HttpListener listener, final Proxy proxy) throws IOException {
        final HttpRequest hr = makeRequest(urlStr, proxy);
        final HttpPipelineRequest hpr = new HttpPipelineRequest(hr, listener);
        addRequest(hpr);
    }
    
    public static HttpRequest makeRequest(final String urlStr, final Proxy proxy) throws IOException {
        final URL url = new URL(urlStr);
        if (!url.getProtocol().equals("http")) {
            throw new IOException(invokedynamic(makeConcatWithConstants:(Ljava/net/URL;)Ljava/lang/String;, url));
        }
        final String file = url.getFile();
        final String host = url.getHost();
        int port = url.getPort();
        if (port <= 0) {
            port = 80;
        }
        final String method = "GET";
        final String http = "HTTP/1.1";
        final Map<String, String> headers = new LinkedHashMap<String, String>();
        headers.put("User-Agent", invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, System.getProperty("java.version")));
        headers.put("Host", host);
        headers.put("Accept", "text/html, image/gif, image/png");
        headers.put("Connection", "keep-alive");
        final byte[] body = new byte[0];
        final HttpRequest req = new HttpRequest(host, port, proxy, method, file, http, headers, body);
        return req;
    }
    
    public static void addRequest(final HttpPipelineRequest pr) {
        final HttpRequest hr = pr.getHttpRequest();
        for (HttpPipelineConnection conn = getConnection(hr.getHost(), hr.getPort(), hr.getProxy()); !conn.addRequest(pr); conn = getConnection(hr.getHost(), hr.getPort(), hr.getProxy())) {
            removeConnection(hr.getHost(), hr.getPort(), hr.getProxy(), conn);
        }
    }
    
    private static synchronized HttpPipelineConnection getConnection(final String host, final int port, final Proxy proxy) {
        final String key = makeConnectionKey(host, port, proxy);
        HttpPipelineConnection conn = HttpPipeline.mapConnections.get(key);
        if (conn == null) {
            conn = new HttpPipelineConnection(host, port, proxy);
            HttpPipeline.mapConnections.put(key, conn);
        }
        return conn;
    }
    
    private static synchronized void removeConnection(final String host, final int port, final Proxy proxy, final HttpPipelineConnection hpc) {
        final String key = makeConnectionKey(host, port, proxy);
        final HttpPipelineConnection conn = HttpPipeline.mapConnections.get(key);
        if (conn == hpc) {
            HttpPipeline.mapConnections.remove(key);
        }
    }
    
    private static String makeConnectionKey(final String host, final int port, final Proxy proxy) {
        final String hostPort = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;ILjava/net/Proxy;)Ljava/lang/String;, host, port, proxy);
        return hostPort;
    }
    
    public static byte[] get(final String urlStr) throws IOException {
        return get(urlStr, Proxy.NO_PROXY);
    }
    
    public static byte[] get(final String urlStr, final Proxy proxy) throws IOException {
        if (urlStr.startsWith("file:")) {
            final URL urlFile = new URL(urlStr);
            final InputStream in = urlFile.openStream();
            final byte[] bytes = Config.readAll(in);
            return bytes;
        }
        final HttpRequest req = makeRequest(urlStr, proxy);
        final HttpResponse resp = executeRequest(req);
        if (resp.getStatus() / 100 != 2) {
            throw new IOException(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, resp.getStatus()));
        }
        return resp.getBody();
    }
    
    public static HttpResponse executeRequest(final HttpRequest req) throws IOException {
        final Map<String, Object> map = new HashMap<String, Object>();
        final String KEY_RESPONSE = "Response";
        final String KEY_EXCEPTION = "Exception";
        final HttpListener l = new HttpListener(map) {
            @Override
            public void finished(final HttpRequest req, final HttpResponse resp) {
                // 
                // This method could not be decompiled.
                // 
                // Could not show original bytecode, likely due to the same error.
                // 
                // The error that occurred was:
                // 
                // com.strobel.assembler.metadata.MethodBodyParseException: An error occurred while parsing the bytecode of method 'net/optifine/http/HttpPipeline$1.finished:(Lnet/optifine/http/HttpRequest;Lnet/optifine/http/HttpResponse;)V'.
                //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:66)
                //     at com.strobel.assembler.metadata.MethodDefinition.tryLoadBody(MethodDefinition.java:729)
                //     at com.strobel.assembler.metadata.MethodDefinition.getBody(MethodDefinition.java:83)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:202)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformCall(AstMethodBodyBuilder.java:1164)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:1009)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:294)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // Caused by: java.lang.IllegalArgumentException: Argument 'index' must be in the range [0, 65], but value was: 22862.
                //     at com.strobel.core.VerifyArgument.inRange(VerifyArgument.java:347)
                //     at com.strobel.assembler.ir.ConstantPool.get(ConstantPool.java:78)
                //     at com.strobel.assembler.metadata.ClassFileReader$Scope.lookupConstant(ClassFileReader.java:1313)
                //     at com.strobel.assembler.metadata.MethodReader.readBodyCore(MethodReader.java:293)
                //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:62)
                //     ... 31 more
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
            
            @Override
            public void failed(final HttpRequest req, final Exception e) {
                // 
                // This method could not be decompiled.
                // 
                // Could not show original bytecode, likely due to the same error.
                // 
                // The error that occurred was:
                // 
                // com.strobel.assembler.metadata.MethodBodyParseException: An error occurred while parsing the bytecode of method 'net/optifine/http/HttpPipeline$1.failed:(Lnet/optifine/http/HttpRequest;Ljava/lang/Exception;)V'.
                //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:66)
                //     at com.strobel.assembler.metadata.MethodDefinition.tryLoadBody(MethodDefinition.java:729)
                //     at com.strobel.assembler.metadata.MethodDefinition.getBody(MethodDefinition.java:83)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:202)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformCall(AstMethodBodyBuilder.java:1164)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:1009)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:294)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // Caused by: java.lang.IllegalArgumentException: Argument 'index' must be in the range [0, 65], but value was: 22862.
                //     at com.strobel.core.VerifyArgument.inRange(VerifyArgument.java:347)
                //     at com.strobel.assembler.ir.ConstantPool.get(ConstantPool.java:78)
                //     at com.strobel.assembler.metadata.ClassFileReader$Scope.lookupConstant(ClassFileReader.java:1313)
                //     at com.strobel.assembler.metadata.MethodReader.readBodyCore(MethodReader.java:293)
                //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:62)
                //     ... 31 more
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
        };
        synchronized (map) {
            final HttpPipelineRequest hpr = new HttpPipelineRequest(req, l);
            addRequest(hpr);
            try {
                map.wait();
            }
            catch (InterruptedException e2) {
                throw new InterruptedIOException("Interrupted");
            }
            final Exception e = map.get("Exception");
            if (e != null) {
                if (e instanceof IOException) {
                    throw (IOException)e;
                }
                if (e instanceof RuntimeException) {
                    throw (RuntimeException)e;
                }
                throw new RuntimeException(e.getMessage(), e);
            }
            else {
                final HttpResponse resp = map.get("Response");
                if (resp == null) {
                    throw new IOException("Response is null");
                }
                return resp;
            }
        }
    }
    
    public static boolean hasActiveRequests() {
        final Collection conns = HttpPipeline.mapConnections.values();
        for (final HttpPipelineConnection conn : conns) {
            if (conn.hasActiveRequests()) {
                return true;
            }
        }
        return false;
    }
    
    static {
        HttpPipeline.mapConnections = new HashMap();
    }
}
