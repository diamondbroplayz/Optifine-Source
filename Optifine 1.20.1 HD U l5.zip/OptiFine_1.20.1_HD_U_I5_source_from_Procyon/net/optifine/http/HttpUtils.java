// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.http;

import java.io.File;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Set;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Map;
import java.io.InputStream;
import java.io.IOException;
import net.optifine.Config;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpUtils
{
    private static String playerItemsUrl;
    public static final String SERVER_URL = "http://s.optifine.net";
    public static final String POST_URL = "http://optifine.net";
    
    public static byte[] get(final String urlStr) throws IOException {
        HttpURLConnection conn = null;
        try {
            final URL url = new URL(urlStr);
            conn = (HttpURLConnection)url.openConnection(enn.N().W());
            conn.setDoInput(true);
            conn.setDoOutput(false);
            conn.connect();
            if (conn.getResponseCode() / 100 != 2) {
                if (conn.getErrorStream() != null) {
                    Config.readAll(conn.getErrorStream());
                }
                throw new IOException(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, conn.getResponseCode()));
            }
            final InputStream in = conn.getInputStream();
            final byte[] bytes = new byte[conn.getContentLength()];
            int pos = 0;
            do {
                final int len = in.read(bytes, pos, bytes.length - pos);
                if (len < 0) {
                    throw new IOException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, urlStr));
                }
                pos += len;
            } while (pos < bytes.length);
            return bytes;
        }
        finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
    
    public static String post(final String urlStr, final Map headers, final byte[] content) throws IOException {
        HttpURLConnection conn = null;
        try {
            final URL url = new URL(urlStr);
            conn = (HttpURLConnection)url.openConnection(enn.N().W());
            conn.setRequestMethod("POST");
            if (headers != null) {
                final Set keys = headers.keySet();
                for (final String key : keys) {
                    final String val = invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;)Ljava/lang/String;, headers.get(key));
                    conn.setRequestProperty(key, val);
                }
            }
            conn.setRequestProperty("Content-Type", "text/plain");
            conn.setRequestProperty("Content-Length", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, content.length));
            conn.setRequestProperty("Content-Language", "en-US");
            conn.setUseCaches(false);
            conn.setDoInput(true);
            conn.setDoOutput(true);
            final OutputStream os = conn.getOutputStream();
            os.write(content);
            os.flush();
            os.close();
            final InputStream in = conn.getInputStream();
            final InputStreamReader isr = new InputStreamReader(in, "ASCII");
            final BufferedReader br = new BufferedReader(isr);
            final StringBuffer sb = new StringBuffer();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
                sb.append('\r');
            }
            br.close();
            return sb.toString();
        }
        finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
    
    public static synchronized String getPlayerItemsUrl() {
        if (HttpUtils.playerItemsUrl == null) {
            try {
                final boolean local = Config.parseBoolean(System.getProperty("player.models.local"), false);
                if (local) {
                    final File dirMc = enn.N().p;
                    final File dirModels = new File(dirMc, "playermodels");
                    HttpUtils.playerItemsUrl = dirModels.toURI().toURL().toExternalForm();
                }
            }
            catch (Exception e) {
                Config.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, e.getClass().getName(), e.getMessage()));
            }
            if (HttpUtils.playerItemsUrl == null) {
                HttpUtils.playerItemsUrl = "http://s.optifine.net";
            }
        }
        return HttpUtils.playerItemsUrl;
    }
    
    static {
        HttpUtils.playerItemsUrl = null;
    }
}
