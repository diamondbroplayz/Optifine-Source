// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.http;

import java.io.EOFException;
import java.io.ByteArrayOutputStream;
import java.util.Map;
import java.util.LinkedHashMap;
import java.io.IOException;
import net.optifine.Config;
import java.io.InputStream;
import java.nio.charset.Charset;

public class HttpPipelineReceiver extends Thread
{
    private HttpPipelineConnection httpPipelineConnection;
    private static final Charset ASCII;
    private static final String HEADER_CONTENT_LENGTH = "Content-Length";
    private static final char CR = '\r';
    private static final char LF = '\n';
    
    public HttpPipelineReceiver(final HttpPipelineConnection httpPipelineConnection) {
        super("HttpPipelineReceiver");
        this.httpPipelineConnection = null;
        this.httpPipelineConnection = httpPipelineConnection;
    }
    
    @Override
    public void run() {
        while (!Thread.interrupted()) {
            HttpPipelineRequest currentRequest = null;
            try {
                currentRequest = this.httpPipelineConnection.getNextRequestReceive();
                final InputStream in = this.httpPipelineConnection.getInputStream();
                final HttpResponse resp = this.readResponse(in);
                this.httpPipelineConnection.onResponseReceived(currentRequest, resp);
            }
            catch (InterruptedException e2) {}
            catch (Exception e) {
                this.httpPipelineConnection.onExceptionReceive(currentRequest, e);
            }
        }
    }
    
    private HttpResponse readResponse(final InputStream in) throws IOException {
        final String statusLine = this.readLine(in);
        final String[] parts = Config.tokenize(statusLine, " ");
        if (parts.length < 3) {
            throw new IOException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, statusLine));
        }
        final String http = parts[0];
        final int status = Config.parseInt(parts[1], 0);
        final String message = parts[2];
        final Map<String, String> headers = new LinkedHashMap<String, String>();
        while (true) {
            final String line = this.readLine(in);
            if (line.length() <= 0) {
                break;
            }
            final int pos = line.indexOf(":");
            if (pos <= 0) {
                continue;
            }
            final String key = line.substring(0, pos).trim();
            final String val = line.substring(pos + 1).trim();
            headers.put(key, val);
        }
        byte[] body = null;
        final String lenStr = headers.get("Content-Length");
        if (lenStr != null) {
            final int len = Config.parseInt(lenStr, -1);
            if (len > 0) {
                body = new byte[len];
                this.readFull(body, in);
            }
        }
        else {
            final String enc = headers.get("Transfer-Encoding");
            if (Config.equals(enc, "chunked")) {
                body = this.readContentChunked(in);
            }
        }
        return new HttpResponse(status, statusLine, headers, body);
    }
    
    private byte[] readContentChunked(final InputStream in) throws IOException {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int len;
        do {
            final String line = this.readLine(in);
            final String[] parts = Config.tokenize(line, "; ");
            len = Integer.parseInt(parts[0], 16);
            final byte[] buf = new byte[len];
            this.readFull(buf, in);
            baos.write(buf);
            this.readLine(in);
        } while (len != 0);
        return baos.toByteArray();
    }
    
    private void readFull(final byte[] buf, final InputStream in) throws IOException {
        int len;
        for (int pos = 0; pos < buf.length; pos += len) {
            len = in.read(buf, pos, buf.length - pos);
            if (len < 0) {
                throw new EOFException();
            }
        }
    }
    
    private String readLine(final InputStream in) throws IOException {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int prev = -1;
        boolean hasCRLF = false;
        while (true) {
            final int i = in.read();
            if (i < 0) {
                break;
            }
            baos.write(i);
            if (prev == 13 && i == 10) {
                hasCRLF = true;
                break;
            }
            prev = i;
        }
        final byte[] bytes = baos.toByteArray();
        String str = new String(bytes, HttpPipelineReceiver.ASCII);
        if (hasCRLF) {
            str = str.substring(0, str.length() - 2);
        }
        return str;
    }
    
    static {
        ASCII = Charset.forName("ASCII");
    }
}
