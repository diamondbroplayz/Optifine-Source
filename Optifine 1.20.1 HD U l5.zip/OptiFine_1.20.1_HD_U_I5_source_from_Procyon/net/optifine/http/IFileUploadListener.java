// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.http;

public interface IFileUploadListener
{
    void fileUploadFinished(final String p0, final byte[] p1, final Throwable p2);
}
