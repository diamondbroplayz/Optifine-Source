// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import java.util.Iterator;
import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.Deque;
import java.nio.ByteBuffer;
import java.util.Map;

public class RenderCache implements IBufferSourceListener
{
    private long cacheTimeMs;
    private long updateTimeMs;
    private Map<fkf, ByteBuffer> renderTypeBuffers;
    private Deque<ByteBuffer> freeBuffers;
    
    public RenderCache(final long cacheTimeMs) {
        this.renderTypeBuffers = new LinkedHashMap<fkf, ByteBuffer>();
        this.freeBuffers = new ArrayDeque<ByteBuffer>();
        this.cacheTimeMs = cacheTimeMs;
    }
    
    public boolean drawCached(final eox graphicsIn) {
        if (this.renderTypeBuffers.isEmpty() || System.currentTimeMillis() > this.updateTimeMs) {
            graphicsIn.e();
            for (final ByteBuffer bb : this.renderTypeBuffers.values()) {
                this.freeBuffers.add(bb);
            }
            this.renderTypeBuffers.clear();
            this.updateTimeMs = System.currentTimeMillis() + this.cacheTimeMs;
            return false;
        }
        for (final fkf rt : this.renderTypeBuffers.keySet()) {
            final ByteBuffer bb2 = this.renderTypeBuffers.get(rt);
            graphicsIn.putBulkData(rt, bb2);
            bb2.rewind();
        }
        graphicsIn.e();
        return true;
    }
    
    public void startRender(final eox graphicsIn) {
        graphicsIn.d().addListener((IBufferSourceListener)this);
    }
    
    public void stopRender(final eox graphicsIn) {
        graphicsIn.e();
        graphicsIn.d().removeListener((IBufferSourceListener)this);
    }
    
    @Override
    public void finish(final fkf renderTypeIn, final eie bufferIn) {
        ByteBuffer bb = this.renderTypeBuffers.get(renderTypeIn);
        if (bb == null) {
            bb = this.allocateByteBuffer(524288);
            this.renderTypeBuffers.put(renderTypeIn, bb);
        }
        bb.position(bb.limit());
        bb.limit(bb.capacity());
        bufferIn.getBulkData(bb);
        bb.flip();
    }
    
    private ByteBuffer allocateByteBuffer(final int size) {
        ByteBuffer bb = this.freeBuffers.pollLast();
        if (bb == null) {
            bb = ehh.a(size);
        }
        bb.position(0);
        bb.limit(0);
        return bb;
    }
}
