// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

public class GlCullState
{
    private boolean enabled;
    private int mode;
    
    public GlCullState() {
        this(false, 1029);
    }
    
    public GlCullState(final boolean enabled) {
        this(enabled, 1029);
    }
    
    public GlCullState(final boolean enabled, final int mode) {
        this.enabled = enabled;
        this.mode = mode;
    }
    
    public void setState(final boolean enabled, final int mode) {
        this.enabled = enabled;
        this.mode = mode;
    }
    
    public void setState(final GlCullState state) {
        this.enabled = state.enabled;
        this.mode = state.mode;
    }
    
    public void setMode(final int mode) {
        this.mode = mode;
    }
    
    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
    
    public void setEnabled() {
        this.enabled = true;
    }
    
    public void setDisabled() {
        this.enabled = false;
    }
    
    public boolean isEnabled() {
        return this.enabled;
    }
    
    public int getMode() {
        return this.mode;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(ZI)Ljava/lang/String;, this.enabled, this.mode);
    }
}
