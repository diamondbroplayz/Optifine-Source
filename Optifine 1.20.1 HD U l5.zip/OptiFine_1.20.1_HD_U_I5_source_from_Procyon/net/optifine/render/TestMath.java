// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import org.joml.Vector4f;
import org.joml.Vector3f;
import org.joml.Matrix3fc;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import org.joml.Matrix4fc;
import net.optifine.util.MathUtils;
import org.joml.Matrix4f;
import java.util.Random;

public class TestMath
{
    static Random random;
    
    public static void main(final String[] args) {
        final int count = 1;
        dbg(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, count));
        for (int i = 0; i < count; ++i) {
            testMatrix4f_mulTranslate();
            testMatrix4f_mulScale();
            testMatrix4f_mulQuaternion();
            testMatrix3f_mulQuaternion();
            testVector4f_transform();
            testVector3f_transform();
        }
        dbg("Done");
    }
    
    private static void testMatrix4f_mulTranslate() {
        final Matrix4f m = new Matrix4f();
        MathUtils.setRandom(m, TestMath.random);
        final Matrix4f m2 = MathUtils.copy(m);
        final float x = TestMath.random.nextFloat();
        final float y = TestMath.random.nextFloat();
        final float z = TestMath.random.nextFloat();
        m.mul((Matrix4fc)MathUtils.makeTranslate4f(x, y, z));
        MathUtils.mulTranslate(m2, x, y, z);
        if (!m2.equals((Object)m)) {
            dbg("*** DIFFERENT ***");
            dbg(m.toString());
            dbg(m2.toString());
        }
    }
    
    private static void testMatrix4f_mulScale() {
        final Matrix4f m = new Matrix4f();
        MathUtils.setRandom(m, TestMath.random);
        final Matrix4f m2 = MathUtils.copy(m);
        final float x = TestMath.random.nextFloat();
        final float y = TestMath.random.nextFloat();
        final float z = TestMath.random.nextFloat();
        m.mul((Matrix4fc)MathUtils.makeScale4f(x, y, z));
        MathUtils.mulScale(m2, x, y, z);
        if (!m2.equals((Object)m)) {
            dbg("*** DIFFERENT ***");
            dbg(m.toString());
            dbg(m2.toString());
        }
    }
    
    private static void testMatrix4f_mulQuaternion() {
        final Matrix4f m = new Matrix4f();
        MathUtils.setRandom(m, TestMath.random);
        final Matrix4f m2 = MathUtils.copy(m);
        final Quaternionf q = new Quaternionf(TestMath.random.nextFloat(), TestMath.random.nextFloat(), TestMath.random.nextFloat(), TestMath.random.nextFloat());
        m.mul((Matrix4fc)MathUtils.makeMatrix4f(q));
        MathUtils.mul(m2, q);
        if (!m2.equals((Object)m)) {
            dbg("*** DIFFERENT ***");
            dbg(m.toString());
            dbg(m2.toString());
        }
    }
    
    private static void testMatrix3f_mulQuaternion() {
        final Matrix3f m = new Matrix3f();
        MathUtils.setRandom(m, TestMath.random);
        final Matrix3f m2 = MathUtils.copy(m);
        final Quaternionf q = new Quaternionf(TestMath.random.nextFloat(), TestMath.random.nextFloat(), TestMath.random.nextFloat(), TestMath.random.nextFloat());
        m.mul((Matrix3fc)MathUtils.makeMatrix3f(q));
        MathUtils.mul(m2, q);
        if (!m2.equals((Object)m)) {
            dbg("*** DIFFERENT ***");
            dbg(m.toString());
            dbg(m2.toString());
        }
    }
    
    private static void testVector3f_transform() {
        final Vector3f v = new Vector3f(TestMath.random.nextFloat(), TestMath.random.nextFloat(), TestMath.random.nextFloat());
        Vector3f v2 = MathUtils.copy(v);
        final Matrix3f m = new Matrix3f();
        MathUtils.setRandom(m, TestMath.random);
        MathUtils.transform(v, m);
        final float x = MathUtils.getTransformX(m, v2.x(), v2.y(), v2.z());
        final float y = MathUtils.getTransformY(m, v2.x(), v2.y(), v2.z());
        final float z = MathUtils.getTransformZ(m, v2.x(), v2.y(), v2.z());
        v2 = new Vector3f(x, y, z);
        if (!v2.equals((Object)v)) {
            dbg("*** DIFFERENT ***");
            dbg(v.toString());
            dbg(v2.toString());
        }
    }
    
    private static void testVector4f_transform() {
        final Vector4f v = new Vector4f(TestMath.random.nextFloat(), TestMath.random.nextFloat(), TestMath.random.nextFloat(), TestMath.random.nextFloat());
        Vector4f v2 = MathUtils.copy(v);
        final Matrix4f m = new Matrix4f();
        MathUtils.setRandom(m, TestMath.random);
        MathUtils.transform(v, m);
        final float x = MathUtils.getTransformX(m, v2.x(), v2.y(), v2.z(), v2.w());
        final float y = MathUtils.getTransformY(m, v2.x(), v2.y(), v2.z(), v2.w());
        final float z = MathUtils.getTransformZ(m, v2.x(), v2.y(), v2.z(), v2.w());
        final float w = MathUtils.getTransformW(m, v2.x(), v2.y(), v2.z(), v2.w());
        v2 = new Vector4f(x, y, z, w);
        if (!v2.equals((Object)v)) {
            dbg("*** DIFFERENT ***");
            dbg(v.toString());
            dbg(v2.toString());
        }
    }
    
    private static void dbg(final String str) {
        System.out.println(str);
    }
    
    static {
        TestMath.random = new Random(1L);
    }
}
