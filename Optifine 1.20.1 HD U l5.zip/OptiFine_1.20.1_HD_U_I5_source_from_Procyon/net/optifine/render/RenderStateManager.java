// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import java.util.Arrays;
import java.util.List;

public class RenderStateManager
{
    private static boolean cacheEnabled;
    private static final fke[] PENDING_CLEAR_STATES;
    
    public static void setupRenderStates(final List<fke> renderStates) {
        if (RenderStateManager.cacheEnabled) {
            setupCached(renderStates);
            return;
        }
        for (int i = 0; i < renderStates.size(); ++i) {
            final fke renderState = renderStates.get(i);
            renderState.a();
        }
    }
    
    public static void clearRenderStates(final List<fke> renderStates) {
        if (RenderStateManager.cacheEnabled) {
            clearCached(renderStates);
            return;
        }
        for (int i = 0; i < renderStates.size(); ++i) {
            final fke renderState = renderStates.get(i);
            renderState.b();
        }
    }
    
    private static void setupCached(final List<fke> renderStates) {
        for (int i = 0; i < renderStates.size(); ++i) {
            final fke state = renderStates.get(i);
            setupCached(state, i);
        }
    }
    
    private static void clearCached(final List<fke> renderStates) {
        for (int i = 0; i < renderStates.size(); ++i) {
            final fke state = renderStates.get(i);
            clearCached(state, i);
        }
    }
    
    private static void setupCached(final fke state, final int index) {
        final fke pendingClearState = RenderStateManager.PENDING_CLEAR_STATES[index];
        if (pendingClearState != null) {
            if (state == pendingClearState) {
                RenderStateManager.PENDING_CLEAR_STATES[index] = null;
                return;
            }
            pendingClearState.b();
            RenderStateManager.PENDING_CLEAR_STATES[index] = null;
        }
        state.a();
    }
    
    private static void clearCached(final fke state, final int index) {
        final fke pendingClearState = RenderStateManager.PENDING_CLEAR_STATES[index];
        if (pendingClearState != null) {
            pendingClearState.b();
        }
        RenderStateManager.PENDING_CLEAR_STATES[index] = state;
    }
    
    public static void enableCache() {
        if (RenderStateManager.cacheEnabled) {
            return;
        }
        RenderStateManager.cacheEnabled = true;
        Arrays.fill(RenderStateManager.PENDING_CLEAR_STATES, null);
    }
    
    public static void flushCache() {
        if (!RenderStateManager.cacheEnabled) {
            return;
        }
        disableCache();
        enableCache();
    }
    
    public static void disableCache() {
        if (!RenderStateManager.cacheEnabled) {
            return;
        }
        RenderStateManager.cacheEnabled = false;
        for (int i = 0; i < RenderStateManager.PENDING_CLEAR_STATES.length; ++i) {
            final fke pendingClearState = RenderStateManager.PENDING_CLEAR_STATES[i];
            if (pendingClearState != null) {
                pendingClearState.b();
            }
        }
        Arrays.fill(RenderStateManager.PENDING_CLEAR_STATES, null);
    }
    
    static {
        PENDING_CLEAR_STATES = new fke[fkf.getCountRenderStates()];
    }
}
