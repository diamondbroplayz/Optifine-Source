// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import net.optifine.util.TextureUtils;
import java.util.Arrays;
import net.optifine.Config;
import java.util.ArrayList;
import net.optifine.util.IntArray;
import java.util.List;

public class MultiTextureBuilder
{
    private int vertexCount;
    private fkf blockLayer;
    private fuv[] quadSprites;
    private boolean reorderingAllowed;
    private boolean[] drawnIcons;
    private List<SpriteRenderData> spriteRenderDatas;
    private IntArray vertexPositions;
    private IntArray vertexCounts;
    
    public MultiTextureBuilder() {
        this.drawnIcons = new boolean[256];
        this.spriteRenderDatas = new ArrayList<SpriteRenderData>();
        this.vertexPositions = new IntArray(16);
        this.vertexCounts = new IntArray(16);
    }
    
    public MultiTextureData build(final int vertexCountIn, final fkf blockLayerIn, final fuv[] quadSpritesIn, final int[] quadOrderingIn) {
        if (quadSpritesIn == null) {
            return null;
        }
        this.vertexCount = vertexCountIn;
        this.blockLayer = blockLayerIn;
        this.quadSprites = quadSpritesIn;
        this.reorderingAllowed = !this.blockLayer.isNeedsSorting();
        final int maxTextureIndex = Config.getTextureMap().getCountRegisteredSprites();
        if (this.drawnIcons.length <= maxTextureIndex) {
            this.drawnIcons = new boolean[maxTextureIndex + 1];
        }
        Arrays.fill(this.drawnIcons, false);
        this.spriteRenderDatas.clear();
        int texSwitch = 0;
        int grassOverlayIndex = -1;
        for (int countQuads = this.vertexCount / 4, i = 0; i < countQuads; ++i) {
            final int is = (quadOrderingIn != null) ? quadOrderingIn[i] : i;
            final fuv icon = this.quadSprites[is];
            if (icon != null) {
                final int iconIndex = icon.getIndexInMap();
                if (iconIndex >= this.drawnIcons.length) {
                    this.drawnIcons = Arrays.copyOf(this.drawnIcons, iconIndex + 1);
                }
                if (!this.drawnIcons[iconIndex]) {
                    if (icon == TextureUtils.iconGrassSideOverlay) {
                        if (grassOverlayIndex < 0) {
                            grassOverlayIndex = i;
                        }
                    }
                    else {
                        i = this.drawForIcon(icon, i, quadOrderingIn) - 1;
                        ++texSwitch;
                        if (this.reorderingAllowed) {
                            this.drawnIcons[iconIndex] = true;
                        }
                    }
                }
            }
        }
        if (grassOverlayIndex >= 0) {
            this.drawForIcon(TextureUtils.iconGrassSideOverlay, grassOverlayIndex, quadOrderingIn);
            ++texSwitch;
        }
        final SpriteRenderData[] srds = this.spriteRenderDatas.toArray(new SpriteRenderData[this.spriteRenderDatas.size()]);
        return new MultiTextureData(srds);
    }
    
    private int drawForIcon(final fuv sprite, final int startQuadPos, final int[] quadOrderingIn) {
        this.vertexPositions.clear();
        this.vertexCounts.clear();
        int firstRegionEnd = -1;
        int lastPos = -1;
        final int countQuads = this.vertexCount / 4;
        for (int i = startQuadPos; i < countQuads; ++i) {
            final int is = (quadOrderingIn != null) ? quadOrderingIn[i] : i;
            final fuv ts = this.quadSprites[is];
            if (ts == sprite) {
                if (lastPos < 0) {
                    lastPos = i;
                }
            }
            else if (lastPos >= 0) {
                this.draw(lastPos, i);
                if (!this.reorderingAllowed) {
                    this.spriteRenderDatas.add(new SpriteRenderData(sprite, this.vertexPositions.toIntArray(), this.vertexCounts.toIntArray()));
                    return i;
                }
                lastPos = -1;
                if (firstRegionEnd < 0) {
                    firstRegionEnd = i;
                }
            }
        }
        if (lastPos >= 0) {
            this.draw(lastPos, countQuads);
        }
        if (firstRegionEnd < 0) {
            firstRegionEnd = countQuads;
        }
        this.spriteRenderDatas.add(new SpriteRenderData(sprite, this.vertexPositions.toIntArray(), this.vertexCounts.toIntArray()));
        return firstRegionEnd;
    }
    
    private void draw(final int startQuadVertex, final int endQuadVertex) {
        final int vxQuadCount = endQuadVertex - startQuadVertex;
        if (vxQuadCount <= 0) {
            return;
        }
        final int startVertex = startQuadVertex * 4;
        final int vxCount = vxQuadCount * 4;
        this.vertexPositions.put(startVertex);
        this.vertexCounts.put(vxCount);
    }
}
