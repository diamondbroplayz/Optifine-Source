// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import org.joml.Vector3f;

public abstract class VertexBuilderWrapper implements ein
{
    private ein vertexBuilder;
    
    public VertexBuilderWrapper(final ein vertexBuilder) {
        this.vertexBuilder = vertexBuilder;
    }
    
    public ein getVertexBuilder() {
        return this.vertexBuilder;
    }
    
    public void putSprite(final fuv sprite) {
        this.vertexBuilder.putSprite(sprite);
    }
    
    public void setSprite(final fuv sprite) {
        this.vertexBuilder.setSprite(sprite);
    }
    
    public boolean isMultiTexture() {
        return this.vertexBuilder.isMultiTexture();
    }
    
    public void setRenderType(final fkf renderType) {
        this.vertexBuilder.setRenderType(renderType);
    }
    
    public fkf getRenderType() {
        return this.vertexBuilder.getRenderType();
    }
    
    public void setRenderBlocks(final boolean renderBlocks) {
        this.vertexBuilder.setRenderBlocks(renderBlocks);
    }
    
    public Vector3f getTempVec3f(final Vector3f vec) {
        return this.vertexBuilder.getTempVec3f(vec);
    }
    
    public Vector3f getTempVec3f(final float x, final float y, final float z) {
        return this.vertexBuilder.getTempVec3f(x, y, z);
    }
    
    public float[] getTempFloat4(final float f1, final float f2, final float f3, final float f4) {
        return this.vertexBuilder.getTempFloat4(f1, f2, f3, f4);
    }
    
    public int[] getTempInt4(final int i1, final int i2, final int i3, final int i4) {
        return this.vertexBuilder.getTempInt4(i1, i2, i3, i4);
    }
    
    public fjx.a getRenderTypeBuffer() {
        return this.vertexBuilder.getRenderTypeBuffer();
    }
    
    public void setQuadVertexPositions(final VertexPosition[] vps) {
        this.vertexBuilder.setQuadVertexPositions(vps);
    }
    
    public void setMidBlock(final float mbx, final float mby, final float mbz) {
        this.vertexBuilder.setMidBlock(mbx, mby, mbz);
    }
    
    public int getVertexCount() {
        return this.vertexBuilder.getVertexCount();
    }
}
