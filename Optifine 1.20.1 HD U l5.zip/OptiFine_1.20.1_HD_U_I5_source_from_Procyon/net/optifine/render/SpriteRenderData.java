// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

public class SpriteRenderData
{
    private fuv sprite;
    private int[] positions;
    private int[] counts;
    
    public SpriteRenderData(final fuv sprite, final int[] positions, final int[] counts) {
        this.sprite = sprite;
        this.positions = positions;
        this.counts = counts;
        if (positions.length != counts.length) {
            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, positions.length, counts.length));
        }
    }
    
    public fuv getSprite() {
        return this.sprite;
    }
    
    public int[] getPositions() {
        return this.positions;
    }
    
    public int[] getCounts() {
        return this.counts;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Lacq;I)Ljava/lang/String;, this.sprite.getName(), this.positions.length);
    }
}
