// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import net.optifine.util.RandomUtils;
import net.optifine.util.IntExpiringCache;

public class BoxVertexPositions extends IntExpiringCache<VertexPosition[][]>
{
    public BoxVertexPositions() {
        super(60000 + RandomUtils.getRandomInt(10000));
    }
    
    @Override
    protected VertexPosition[][] make() {
        final VertexPosition[][] boxPositions = new VertexPosition[6][4];
        for (int i = 0; i < boxPositions.length; ++i) {
            final VertexPosition[] quadPositions = boxPositions[i];
            for (int p = 0; p < quadPositions.length; ++p) {
                quadPositions[p] = new VertexPosition();
            }
        }
        return boxPositions;
    }
}
