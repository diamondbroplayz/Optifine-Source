// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import net.optifine.util.RandomUtils;
import net.optifine.util.IntExpiringCache;

public class QuadVertexPositions extends IntExpiringCache<VertexPosition[]>
{
    public QuadVertexPositions() {
        super(60000 + RandomUtils.getRandomInt(10000));
    }
    
    @Override
    protected VertexPosition[] make() {
        return new VertexPosition[] { new VertexPosition(), new VertexPosition(), new VertexPosition(), new VertexPosition() };
    }
}
