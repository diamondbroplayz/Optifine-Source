// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

public class VertexBuilderDummy implements ein
{
    private fjx.a renderTypeBuffer;
    
    public VertexBuilderDummy(final fjx.a renderTypeBuffer) {
        this.renderTypeBuffer = null;
        this.renderTypeBuffer = renderTypeBuffer;
    }
    
    public fjx.a getRenderTypeBuffer() {
        return this.renderTypeBuffer;
    }
    
    public ein a(final double x, final double y, final double z) {
        return (ein)this;
    }
    
    public ein a(final int red, final int green, final int blue, final int alpha) {
        return (ein)this;
    }
    
    public ein a(final float u, final float v) {
        return (ein)this;
    }
    
    public ein a(final int u, final int v) {
        return (ein)this;
    }
    
    public ein b(final int u, final int v) {
        return (ein)this;
    }
    
    public ein a(final float x, final float y, final float z) {
        return (ein)this;
    }
    
    public void e() {
    }
    
    public void b(final int red, final int green, final int blue, final int alpha) {
    }
    
    public void k() {
    }
}
