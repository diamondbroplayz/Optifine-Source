// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import net.optifine.override.ChunkCacheOF;

public class LightCacheOF
{
    public static final float getBrightness(final dcb blockStateIn, final clp worldIn, final gu blockPosIn) {
        float aoLight = blockStateIn.f((cls)worldIn, blockPosIn);
        aoLight = fkq.fixAoLightValue(aoLight);
        return aoLight;
    }
    
    public static final int getPackedLight(final dcb blockStateIn, final clp worldIn, final gu blockPosIn) {
        if (!(worldIn instanceof ChunkCacheOF)) {
            return fjv.a(worldIn, blockStateIn, blockPosIn);
        }
        final ChunkCacheOF cc = (ChunkCacheOF)worldIn;
        final int[] lights = cc.getCombinedLights();
        final int index = cc.getPositionIndex(blockPosIn);
        if (index < 0 || index >= lights.length || lights == null) {
            return fjv.a(worldIn, blockStateIn, blockPosIn);
        }
        int light = lights[index];
        if (light == -1) {
            light = fjv.a(worldIn, blockStateIn, blockPosIn);
            lights[index] = light;
        }
        return light;
    }
}
