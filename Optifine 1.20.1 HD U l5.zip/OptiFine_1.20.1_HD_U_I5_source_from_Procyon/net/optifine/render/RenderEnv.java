// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import net.optifine.Config;
import net.optifine.model.BakedQuadRetextured;
import java.util.ArrayList;
import it.unimi.dsi.fastutil.longs.Long2ByteLinkedOpenHashMap;
import net.optifine.model.ListQuadsOverlay;
import java.util.List;
import net.optifine.BlockPosM;
import java.util.BitSet;

public class RenderEnv
{
    private dcb blockState;
    private gu blockPos;
    private int blockId;
    private int metadata;
    private int breakingAnimation;
    private int smartLeaves;
    private float[] quadBounds;
    private BitSet boundsFlags;
    private fkq.b aoFace;
    private BlockPosM colorizerBlockPosM;
    private gu.a renderMutableBlockPos;
    private boolean[] borderFlags;
    private boolean[] borderFlags2;
    private boolean[] borderFlags3;
    private ha[] borderDirections;
    private List<fkr> listQuadsCustomizer;
    private List<fkr> listQuadsCtmMultipass;
    private fkr[] arrayQuadsCtm1;
    private fkr[] arrayQuadsCtm2;
    private fkr[] arrayQuadsCtm3;
    private fkr[] arrayQuadsCtm4;
    private fjk regionRenderCacheBuilder;
    private ListQuadsOverlay[] listsQuadsOverlay;
    private boolean overlaysRendered;
    private Long2ByteLinkedOpenHashMap renderSideMap;
    private static final int UNKNOWN = -1;
    private static final int FALSE = 0;
    private static final int TRUE = 1;
    
    public RenderEnv(final dcb blockState, final gu blockPos) {
        this.blockId = -1;
        this.metadata = -1;
        this.breakingAnimation = -1;
        this.smartLeaves = -1;
        this.quadBounds = new float[ha.p.length * 2];
        this.boundsFlags = new BitSet(3);
        this.aoFace = new fkq.b();
        this.colorizerBlockPosM = null;
        this.renderMutableBlockPos = null;
        this.borderFlags = null;
        this.borderFlags2 = null;
        this.borderFlags3 = null;
        this.borderDirections = null;
        this.listQuadsCustomizer = new ArrayList<fkr>();
        this.listQuadsCtmMultipass = new ArrayList<fkr>();
        this.arrayQuadsCtm1 = new fkr[1];
        this.arrayQuadsCtm2 = new fkr[2];
        this.arrayQuadsCtm3 = new fkr[3];
        this.arrayQuadsCtm4 = new fkr[4];
        this.regionRenderCacheBuilder = null;
        this.listsQuadsOverlay = new ListQuadsOverlay[fkf.CHUNK_RENDER_TYPES.length];
        this.overlaysRendered = false;
        this.renderSideMap = new Long2ByteLinkedOpenHashMap();
        this.blockState = blockState;
        this.blockPos = blockPos;
    }
    
    public void reset(final dcb blockStateIn, final gu blockPosIn) {
        if (this.blockState == blockStateIn && this.blockPos == blockPosIn) {
            return;
        }
        this.blockState = blockStateIn;
        this.blockPos = blockPosIn;
        this.blockId = -1;
        this.metadata = -1;
        this.breakingAnimation = -1;
        this.smartLeaves = -1;
        this.boundsFlags.clear();
    }
    
    public int getBlockId() {
        if (this.blockId < 0) {
            this.blockId = this.blockState.getBlockId();
        }
        return this.blockId;
    }
    
    public int getMetadata() {
        if (this.metadata < 0) {
            this.metadata = this.blockState.getMetadata();
        }
        return this.metadata;
    }
    
    public float[] getQuadBounds() {
        return this.quadBounds;
    }
    
    public BitSet getBoundsFlags() {
        return this.boundsFlags;
    }
    
    public fkq.b getAoFace() {
        return this.aoFace;
    }
    
    public boolean isBreakingAnimation(final List listQuads) {
        if (this.breakingAnimation == -1 && listQuads.size() > 0) {
            if (listQuads.get(0) instanceof BakedQuadRetextured) {
                this.breakingAnimation = 1;
            }
            else {
                this.breakingAnimation = 0;
            }
        }
        return this.breakingAnimation == 1;
    }
    
    public boolean isBreakingAnimation(final fkr quad) {
        if (this.breakingAnimation < 0) {
            if (quad instanceof BakedQuadRetextured) {
                this.breakingAnimation = 1;
            }
            else {
                this.breakingAnimation = 0;
            }
        }
        return this.breakingAnimation == 1;
    }
    
    public boolean isBreakingAnimation() {
        return this.breakingAnimation == 1;
    }
    
    public dcb getBlockState() {
        return this.blockState;
    }
    
    public BlockPosM getColorizerBlockPosM() {
        if (this.colorizerBlockPosM == null) {
            this.colorizerBlockPosM = new BlockPosM(0, 0, 0);
        }
        return this.colorizerBlockPosM;
    }
    
    public gu.a getRenderMutableBlockPos() {
        if (this.renderMutableBlockPos == null) {
            this.renderMutableBlockPos = new gu.a(0, 0, 0);
        }
        return this.renderMutableBlockPos;
    }
    
    public boolean[] getBorderFlags() {
        if (this.borderFlags == null) {
            this.borderFlags = new boolean[4];
        }
        return this.borderFlags;
    }
    
    public boolean[] getBorderFlags2() {
        if (this.borderFlags2 == null) {
            this.borderFlags2 = new boolean[4];
        }
        return this.borderFlags2;
    }
    
    public boolean[] getBorderFlags3() {
        if (this.borderFlags3 == null) {
            this.borderFlags3 = new boolean[4];
        }
        return this.borderFlags3;
    }
    
    public ha[] getBorderDirections() {
        if (this.borderDirections == null) {
            this.borderDirections = new ha[4];
        }
        return this.borderDirections;
    }
    
    public ha[] getBorderDirections(final ha dir0, final ha dir1, final ha dir2, final ha dir3) {
        final ha[] dirs = this.getBorderDirections();
        dirs[0] = dir0;
        dirs[1] = dir1;
        dirs[2] = dir2;
        dirs[3] = dir3;
        return dirs;
    }
    
    public boolean isSmartLeaves() {
        if (this.smartLeaves == -1) {
            if (Config.isTreesSmart() && this.blockState.b() instanceof ctu) {
                this.smartLeaves = 1;
            }
            else {
                this.smartLeaves = 0;
            }
        }
        return this.smartLeaves == 1;
    }
    
    public List<fkr> getListQuadsCustomizer() {
        return this.listQuadsCustomizer;
    }
    
    public fkr[] getArrayQuadsCtm(final fkr quad) {
        this.arrayQuadsCtm1[0] = quad;
        return this.arrayQuadsCtm1;
    }
    
    public fkr[] getArrayQuadsCtm(final fkr quad0, final fkr quad1) {
        this.arrayQuadsCtm2[0] = quad0;
        this.arrayQuadsCtm2[1] = quad1;
        return this.arrayQuadsCtm2;
    }
    
    public fkr[] getArrayQuadsCtm(final fkr quad0, final fkr quad1, final fkr quad2) {
        this.arrayQuadsCtm3[0] = quad0;
        this.arrayQuadsCtm3[1] = quad1;
        this.arrayQuadsCtm3[2] = quad2;
        return this.arrayQuadsCtm3;
    }
    
    public fkr[] getArrayQuadsCtm(final fkr quad0, final fkr quad1, final fkr quad2, final fkr quad3) {
        this.arrayQuadsCtm4[0] = quad0;
        this.arrayQuadsCtm4[1] = quad1;
        this.arrayQuadsCtm4[2] = quad2;
        this.arrayQuadsCtm4[3] = quad3;
        return this.arrayQuadsCtm4;
    }
    
    public List<fkr> getListQuadsCtmMultipass(final fkr[] quads) {
        this.listQuadsCtmMultipass.clear();
        if (quads != null) {
            for (int i = 0; i < quads.length; ++i) {
                final fkr quad = quads[i];
                this.listQuadsCtmMultipass.add(quad);
            }
        }
        return this.listQuadsCtmMultipass;
    }
    
    public fjk getRegionRenderCacheBuilder() {
        return this.regionRenderCacheBuilder;
    }
    
    public void setRegionRenderCacheBuilder(final fjk regionRenderCacheBuilder) {
        this.regionRenderCacheBuilder = regionRenderCacheBuilder;
    }
    
    public ListQuadsOverlay getListQuadsOverlay(final fkf layer) {
        ListQuadsOverlay list = this.listsQuadsOverlay[layer.ordinal()];
        if (list == null) {
            list = new ListQuadsOverlay();
            this.listsQuadsOverlay[layer.ordinal()] = list;
        }
        return list;
    }
    
    public boolean isOverlaysRendered() {
        return this.overlaysRendered;
    }
    
    public void setOverlaysRendered(final boolean overlaysRendered) {
        this.overlaysRendered = overlaysRendered;
    }
    
    public Long2ByteLinkedOpenHashMap getRenderSideMap() {
        return this.renderSideMap;
    }
}
