// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import net.optifine.util.ArrayUtils;

public class MultiTextureData
{
    private SpriteRenderData[] spriteRenderDatas;
    
    public MultiTextureData(final SpriteRenderData[] spriteRenderDatas) {
        this.spriteRenderDatas = spriteRenderDatas;
    }
    
    public SpriteRenderData[] getSpriteRenderDatas() {
        return this.spriteRenderDatas;
    }
    
    @Override
    public String toString() {
        return ArrayUtils.arrayToString(this.spriteRenderDatas);
    }
}
