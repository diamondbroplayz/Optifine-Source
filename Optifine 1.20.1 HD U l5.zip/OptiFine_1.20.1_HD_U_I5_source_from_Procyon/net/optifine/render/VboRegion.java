// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.optifine.shaders.ShadersRender;
import java.nio.ByteBuffer;
import net.optifine.Config;
import com.mojang.blaze3d.platform.GlStateManager;
import java.nio.IntBuffer;
import org.lwjgl.PointerBuffer;
import net.optifine.util.LinkedList;

public class VboRegion
{
    private fkf layer;
    private int glArrayObjectId;
    private int glBufferId;
    private int capacity;
    private int positionTop;
    private int sizeUsed;
    private LinkedList<VboRange> rangeList;
    private VboRange compactRangeLast;
    private PointerBuffer bufferIndexVertex;
    private IntBuffer bufferCountVertex;
    private final int vertexBytes;
    private eio.b drawMode;
    private boolean isShaders;
    
    public VboRegion(final fkf layer) {
        this.layer = null;
        this.glArrayObjectId = GlStateManager._glGenVertexArrays();
        this.glBufferId = GlStateManager._glGenBuffers();
        this.capacity = 4096;
        this.positionTop = 0;
        this.rangeList = new LinkedList<VboRange>();
        this.compactRangeLast = null;
        this.bufferIndexVertex = Config.createDirectPointerBuffer(this.capacity);
        this.bufferCountVertex = Config.createDirectIntBuffer(this.capacity);
        this.vertexBytes = eih.j.b();
        this.drawMode = eio.b.h;
        this.isShaders = Config.isShaders();
        this.layer = layer;
        this.bindBuffer();
        final long capacityBytes = this.toBytes(this.capacity);
        GlStateManager._glBufferData(GlStateManager.GL_ARRAY_BUFFER, capacityBytes, GlStateManager.GL_STATIC_DRAW);
        this.unbindBuffer();
    }
    
    public void bufferData(final ByteBuffer data, final VboRange range) {
        if (this.glBufferId < 0) {
            return;
        }
        final int posOld = range.getPosition();
        final int sizeOld = range.getSize();
        final int sizeNew = this.toVertex(data.limit());
        if (sizeNew <= 0) {
            if (posOld >= 0) {
                range.setPosition(-1);
                range.setSize(0);
                this.rangeList.remove(range.getNode());
                this.sizeUsed -= sizeOld;
            }
            return;
        }
        if (sizeNew > sizeOld) {
            range.setPosition(this.positionTop);
            range.setSize(sizeNew);
            this.positionTop += sizeNew;
            if (posOld >= 0) {
                this.rangeList.remove(range.getNode());
            }
            this.rangeList.addLast(range.getNode());
        }
        range.setSize(sizeNew);
        this.sizeUsed += sizeNew - sizeOld;
        this.checkVboSize(range.getPositionNext());
        final long positionBytes = this.toBytes(range.getPosition());
        this.bindVertexArray();
        this.bindBuffer();
        GlStateManager.bufferSubData(GlStateManager.GL_ARRAY_BUFFER, positionBytes, data);
        this.unbindBuffer();
        unbindVertexArray();
        if (this.positionTop > this.sizeUsed * 11 / 10) {
            this.compactRanges(1);
        }
    }
    
    private void compactRanges(final int countMax) {
        if (this.rangeList.isEmpty()) {
            return;
        }
        VboRange range = this.compactRangeLast;
        if (range == null || !this.rangeList.contains(range.getNode())) {
            range = this.rangeList.getFirst().getItem();
        }
        int posCompact = range.getPosition();
        final VboRange rangePrev = range.getPrev();
        if (rangePrev == null) {
            posCompact = 0;
        }
        else {
            posCompact = rangePrev.getPositionNext();
        }
        int count = 0;
        while (range != null && count < countMax) {
            ++count;
            if (range.getPosition() == posCompact) {
                posCompact += range.getSize();
                range = range.getNext();
            }
            else {
                final int sizeFree = range.getPosition() - posCompact;
                if (range.getSize() <= sizeFree) {
                    this.copyVboData(range.getPosition(), posCompact, range.getSize());
                    range.setPosition(posCompact);
                    posCompact += range.getSize();
                    range = range.getNext();
                }
                else {
                    this.checkVboSize(this.positionTop + range.getSize());
                    this.copyVboData(range.getPosition(), this.positionTop, range.getSize());
                    range.setPosition(this.positionTop);
                    this.positionTop += range.getSize();
                    final VboRange rangeNext = range.getNext();
                    this.rangeList.remove(range.getNode());
                    this.rangeList.addLast(range.getNode());
                    range = rangeNext;
                }
            }
        }
        if (range == null) {
            this.positionTop = this.rangeList.getLast().getItem().getPositionNext();
        }
        this.compactRangeLast = range;
    }
    
    private void checkRanges() {
        int count = 0;
        int size = 0;
        for (VboRange range = this.rangeList.getFirst().getItem(); range != null; range = range.getNext()) {
            ++count;
            size += range.getSize();
            if (range.getPosition() < 0 || range.getSize() <= 0 || range.getPositionNext() > this.positionTop) {
                throw new RuntimeException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/render/VboRange;)Ljava/lang/String;, range));
            }
            final VboRange rangePrev = range.getPrev();
            if (rangePrev != null && range.getPosition() < rangePrev.getPositionNext()) {
                throw new RuntimeException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/render/VboRange;)Ljava/lang/String;, range));
            }
            final VboRange rangeNext = range.getNext();
            if (rangeNext != null && range.getPositionNext() > rangeNext.getPosition()) {
                throw new RuntimeException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/render/VboRange;)Ljava/lang/String;, range));
            }
        }
        if (count != this.rangeList.getSize()) {
            throw new RuntimeException(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, count, this.rangeList.getSize()));
        }
        if (size != this.sizeUsed) {
            throw new RuntimeException(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, size, this.sizeUsed));
        }
    }
    
    private void checkVboSize(final int sizeMin) {
        if (this.capacity < sizeMin) {
            this.expandVbo(sizeMin);
        }
    }
    
    private void copyVboData(final int posFrom, final int posTo, final int size) {
        final long posFromBytes = this.toBytes(posFrom);
        final long posToBytes = this.toBytes(posTo);
        final long sizeBytes = this.toBytes(size);
        GlStateManager._glBindBuffer(GlStateManager.GL_COPY_READ_BUFFER, this.glBufferId);
        GlStateManager._glBindBuffer(GlStateManager.GL_COPY_WRITE_BUFFER, this.glBufferId);
        GlStateManager.copyBufferSubData(GlStateManager.GL_COPY_READ_BUFFER, GlStateManager.GL_COPY_WRITE_BUFFER, posFromBytes, posToBytes, sizeBytes);
        Config.checkGlError("Copy VBO range");
        GlStateManager._glBindBuffer(GlStateManager.GL_COPY_READ_BUFFER, 0);
        GlStateManager._glBindBuffer(GlStateManager.GL_COPY_WRITE_BUFFER, 0);
    }
    
    private void expandVbo(final int sizeMin) {
        int capacityNew;
        for (capacityNew = this.capacity * 6 / 4; capacityNew < sizeMin; capacityNew = capacityNew * 6 / 4) {}
        final long capacityBytes = this.toBytes(this.capacity);
        final long capacityNewBytes = this.toBytes(capacityNew);
        final int glBufferIdNew = GlStateManager._glGenBuffers();
        GlStateManager._glBindBuffer(GlStateManager.GL_ARRAY_BUFFER, glBufferIdNew);
        GlStateManager._glBufferData(GlStateManager.GL_ARRAY_BUFFER, capacityNewBytes, GlStateManager.GL_STATIC_DRAW);
        Config.checkGlError("Expand VBO");
        GlStateManager._glBindBuffer(GlStateManager.GL_ARRAY_BUFFER, 0);
        GlStateManager._glBindBuffer(GlStateManager.GL_COPY_READ_BUFFER, this.glBufferId);
        GlStateManager._glBindBuffer(GlStateManager.GL_COPY_WRITE_BUFFER, glBufferIdNew);
        GlStateManager.copyBufferSubData(GlStateManager.GL_COPY_READ_BUFFER, GlStateManager.GL_COPY_WRITE_BUFFER, 0L, 0L, capacityBytes);
        Config.checkGlError(invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, capacityNewBytes));
        GlStateManager._glBindBuffer(GlStateManager.GL_COPY_READ_BUFFER, 0);
        GlStateManager._glBindBuffer(GlStateManager.GL_COPY_WRITE_BUFFER, 0);
        GlStateManager._glDeleteBuffers(this.glBufferId);
        this.bufferIndexVertex = Config.createDirectPointerBuffer(capacityNew);
        this.bufferCountVertex = Config.createDirectIntBuffer(capacityNew);
        this.glBufferId = glBufferIdNew;
        this.capacity = capacityNew;
    }
    
    public void bindVertexArray() {
        GlStateManager._glBindVertexArray(this.glArrayObjectId);
    }
    
    public void bindBuffer() {
        GlStateManager._glBindBuffer(GlStateManager.GL_ARRAY_BUFFER, this.glBufferId);
    }
    
    public void drawArrays(final eio.b drawMode, final VboRange range) {
        if (this.drawMode != drawMode) {
            if (this.bufferIndexVertex.position() > 0) {
                throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Leio$b;Leio$b;)Ljava/lang/String;, this.drawMode, drawMode));
            }
            this.drawMode = drawMode;
        }
        final int indexSize = 4;
        final int pos = drawMode.a(range.getPosition()) * indexSize;
        this.bufferIndexVertex.put((long)pos);
        final int count = drawMode.a(range.getSize());
        this.bufferCountVertex.put(count);
    }
    
    public void finishDraw() {
        this.bindVertexArray();
        this.bindBuffer();
        this.layer.I().e();
        if (this.isShaders) {
            ShadersRender.setupArrayPointersVbo();
        }
        final int indexCount = this.drawMode.a(this.positionTop);
        final RenderSystem.a rendersystem$autostorageindexbuffer = RenderSystem.getSequentialBuffer(this.drawMode);
        final eio.a indexType = rendersystem$autostorageindexbuffer.a();
        rendersystem$autostorageindexbuffer.b(indexCount);
        this.bufferIndexVertex.flip();
        this.bufferCountVertex.flip();
        GlStateManager.glMultiDrawElements(this.drawMode.i, this.bufferCountVertex, indexType.c, this.bufferIndexVertex);
        this.bufferIndexVertex.limit(this.bufferIndexVertex.capacity());
        this.bufferCountVertex.limit(this.bufferCountVertex.capacity());
        if (this.positionTop > this.sizeUsed * 11 / 10) {
            this.compactRanges(1);
        }
    }
    
    public void unbindBuffer() {
        GlStateManager._glBindBuffer(GlStateManager.GL_ARRAY_BUFFER, 0);
    }
    
    public static void unbindVertexArray() {
        GlStateManager._glBindVertexArray(0);
    }
    
    public void deleteGlBuffers() {
        if (this.glArrayObjectId >= 0) {
            GlStateManager._glDeleteVertexArrays(this.glArrayObjectId);
            this.glArrayObjectId = -1;
        }
        if (this.glBufferId >= 0) {
            GlStateManager._glDeleteBuffers(this.glBufferId);
            this.glBufferId = -1;
        }
    }
    
    private long toBytes(final int vertex) {
        return vertex * (long)this.vertexBytes;
    }
    
    private int toVertex(final long bytes) {
        return (int)(bytes / this.vertexBytes);
    }
    
    public int getPositionTop() {
        return this.positionTop;
    }
}
