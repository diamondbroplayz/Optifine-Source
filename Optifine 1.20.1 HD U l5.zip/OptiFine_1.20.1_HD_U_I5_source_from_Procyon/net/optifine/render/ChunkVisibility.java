// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import java.util.List;
import java.util.ArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Map;
import java.util.ConcurrentModificationException;
import net.optifine.Config;

public class ChunkVisibility
{
    public static final int MASK_FACINGS = 63;
    public static final ha[][] enumFacingArrays;
    public static final ha[][] enumFacingOppositeArrays;
    private static int counter;
    private static int iMaxStatic;
    private static int iMaxStaticFinal;
    private static few worldLast;
    private static int pcxLast;
    private static int pczLast;
    
    public static int getMaxChunkY(final few world, final bfj viewEntity, final int renderDistanceChunks, final fkl viewFrustum) {
        final int minHeight = world.C_();
        final int maxHeight = world.D_();
        final int minChunkHeight = minHeight >> 4;
        final int pcx = apa.a(viewEntity.dn()) >> 4;
        int pcy = apa.a(viewEntity.dp() - minHeight) >> 4;
        final int pcz = apa.a(viewEntity.dt()) >> 4;
        final int pcyMax = maxHeight - minHeight >> 4;
        pcy = Config.limit(pcy, 0, pcyMax - 1);
        final long playerSectionKey = hx.c(viewEntity.di());
        final dfw playerSection = world.getSectionStorage().d(playerSectionKey);
        final boolean multiplayer = !Config.isIntegratedServerRunning();
        int cxStart = pcx - renderDistanceChunks;
        int cxEnd = pcx + renderDistanceChunks;
        int czStart = pcz - renderDistanceChunks;
        int czEnd = pcz + renderDistanceChunks;
        if (world != ChunkVisibility.worldLast || pcx != ChunkVisibility.pcxLast || pcz != ChunkVisibility.pczLast) {
            ChunkVisibility.counter = 0;
            ChunkVisibility.iMaxStaticFinal = 16;
            ChunkVisibility.worldLast = world;
            ChunkVisibility.pcxLast = pcx;
            ChunkVisibility.pczLast = pcz;
        }
        if (ChunkVisibility.counter == 0) {
            ChunkVisibility.iMaxStatic = -1;
        }
        int iMax = ChunkVisibility.iMaxStatic;
        switch (ChunkVisibility.counter) {
            case 0: {
                cxEnd = pcx;
                czEnd = pcz;
                break;
            }
            case 1: {
                cxStart = pcx;
                czEnd = pcz;
                break;
            }
            case 2: {
                cxEnd = pcx;
                czStart = pcz;
                break;
            }
            case 3: {
                cxStart = pcx;
                czStart = pcz;
                break;
            }
        }
        for (int cx = cxStart; cx < cxEnd; ++cx) {
            for (int cz = czStart; cz < czEnd; ++cz) {
                final dei chunk = world.d(cx, cz);
                if (chunk.C()) {
                    if (multiplayer) {
                        final int i = viewFrustum.getHighestUsedChunkIndex(cx, iMax, cz);
                        if (i > iMax) {
                            iMax = i;
                        }
                    }
                }
                else {
                    final dej[] ebss = chunk.d();
                    int j = ebss.length - 1;
                    while (j > iMax) {
                        final dej ebs = ebss[j];
                        if (ebs != null && !ebs.c()) {
                            if (j > iMax) {
                                iMax = j;
                                break;
                            }
                            break;
                        }
                        else {
                            --j;
                        }
                    }
                    try {
                        final Map<gu, czn> mapTileEntities = (Map<gu, czn>)chunk.G();
                        if (!mapTileEntities.isEmpty()) {
                            final Set<gu> keys = mapTileEntities.keySet();
                            for (final gu pos : keys) {
                                final int k = pos.v() - minHeight >> 4;
                                if (k > iMax) {
                                    iMax = k;
                                }
                            }
                        }
                    }
                    catch (ConcurrentModificationException ex) {}
                }
            }
        }
        if (ChunkVisibility.counter == 0) {
            final LongSet sectionKeys = world.getSectionStorage().getSectionKeys();
            final LongIterator it2 = sectionKeys.iterator();
            while (it2.hasNext()) {
                final long sectionKey = it2.nextLong();
                final int sectionY = hx.c(sectionKey);
                final int l = sectionY - minChunkHeight;
                if (sectionKey == playerSectionKey && l == pcy && playerSection != null && playerSection.getEntityList().size() == 1) {
                    continue;
                }
                if (l <= iMax) {
                    continue;
                }
                iMax = l;
            }
        }
        if (ChunkVisibility.counter < 3) {
            ChunkVisibility.iMaxStatic = iMax;
            iMax = ChunkVisibility.iMaxStaticFinal;
        }
        else {
            ChunkVisibility.iMaxStaticFinal = iMax;
            ChunkVisibility.iMaxStatic = -1;
        }
        ChunkVisibility.counter = (ChunkVisibility.counter + 1) % 4;
        return (iMax << 4) + minHeight;
    }
    
    public static boolean isFinished() {
        return ChunkVisibility.counter == 0;
    }
    
    private static ha[][] makeEnumFacingArrays(final boolean opposite) {
        final int count = 64;
        final ha[][] arrs = new ha[count][];
        for (int i = 0; i < count; ++i) {
            final List<ha> list = new ArrayList<ha>();
            for (int ix = 0; ix < ha.p.length; ++ix) {
                final ha facing = ha.p[ix];
                final ha facingMask = opposite ? facing.g() : facing;
                final int mask = 1 << facingMask.ordinal();
                if ((i & mask) != 0x0) {
                    list.add(facing);
                }
            }
            final ha[] fs = list.toArray(new ha[list.size()]);
            arrs[i] = fs;
        }
        return arrs;
    }
    
    public static ha[] getFacingsNotOpposite(final int setDisabled) {
        final int index = ~setDisabled & 0x3F;
        return ChunkVisibility.enumFacingOppositeArrays[index];
    }
    
    public static ha[] getFacings(final int setDirections) {
        final int index = setDirections & 0x3F;
        return ChunkVisibility.enumFacingArrays[index];
    }
    
    public static void reset() {
        ChunkVisibility.worldLast = null;
    }
    
    static {
        enumFacingArrays = makeEnumFacingArrays(false);
        enumFacingOppositeArrays = makeEnumFacingArrays(true);
        ChunkVisibility.counter = 0;
        ChunkVisibility.iMaxStatic = -1;
        ChunkVisibility.iMaxStaticFinal = 16;
        ChunkVisibility.worldLast = null;
        ChunkVisibility.pcxLast = Integer.MIN_VALUE;
        ChunkVisibility.pczLast = Integer.MIN_VALUE;
    }
}
