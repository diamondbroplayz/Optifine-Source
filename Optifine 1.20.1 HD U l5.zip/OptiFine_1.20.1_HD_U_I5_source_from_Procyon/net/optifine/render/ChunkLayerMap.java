// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import java.util.Arrays;
import java.util.Collection;
import java.util.function.Function;
import java.util.function.Supplier;

public class ChunkLayerMap<T>
{
    private T[] values;
    private Supplier<T> defaultValue;
    
    public ChunkLayerMap(final Function<fkf, T> initialValue) {
        this.values = (T[])new Object[fkf.CHUNK_RENDER_TYPES.length];
        final fkf[] renderTypes = fkf.CHUNK_RENDER_TYPES;
        this.values = (T[])new Object[renderTypes.length];
        for (int i = 0; i < renderTypes.length; ++i) {
            final fkf renderType = renderTypes[i];
            final T t = initialValue.apply(renderType);
            this.values[renderType.ordinal()] = t;
        }
        for (int i = 0; i < this.values.length; ++i) {
            if (this.values[i] == null) {
                throw new RuntimeException(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i));
            }
        }
    }
    
    public T get(final fkf layer) {
        return this.values[layer.ordinal()];
    }
    
    public Collection<T> values() {
        return Arrays.asList(this.values);
    }
}
