// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

public interface ICamera
{
    void setCameraPosition(final double p0, final double p1, final double p2);
    
    boolean isBoundingBoxInFrustum(final eed p0);
    
    boolean isBoxInFrustumFully(final double p0, final double p1, final double p2, final double p3, final double p4, final double p5);
}
