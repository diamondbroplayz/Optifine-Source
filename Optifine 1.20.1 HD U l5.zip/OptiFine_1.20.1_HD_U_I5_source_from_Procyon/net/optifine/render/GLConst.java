// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

public class GLConst
{
    public static final int GL_TEXTURE_2D = 3553;
    public static final int GL_TEXTURE_MIN_FILTER = 10241;
    public static final int GL_TEXTURE_MAG_FILTER = 10240;
    public static final int GL_NEAREST = 9728;
    public static final int GL_LINEAR = 9729;
    public static final int GL_NEAREST_MIPMAP_NEAREST = 9984;
    public static final int GL_LINEAR_MIPMAP_NEAREST = 9985;
    public static final int GL_NEAREST_MIPMAP_LINEAR = 9986;
    public static final int GL_LINEAR_MIPMAP_LINEAR = 9987;
    public static final int GL_TEXTURE_MAX_ANISOTROPY_EXT = 34046;
    public static int GL_FRAMEBUFFER;
    public static int GL_RENDERBUFFER;
    public static int GL_COLOR_ATTACHMENT0;
    public static int GL_DEPTH_ATTACHMENT;
    public static int GL_FRAMEBUFFER_COMPLETE;
    public static int GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT;
    public static int GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT;
    public static int GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER;
    public static int GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER;
    public static int GL_EXP;
    public static int GL_EXP2;
    
    static {
        GLConst.GL_FRAMEBUFFER = 36160;
        GLConst.GL_RENDERBUFFER = 36161;
        GLConst.GL_COLOR_ATTACHMENT0 = 36064;
        GLConst.GL_DEPTH_ATTACHMENT = 36096;
        GLConst.GL_FRAMEBUFFER_COMPLETE = 36053;
        GLConst.GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT = 36054;
        GLConst.GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT = 36055;
        GLConst.GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER = 36059;
        GLConst.GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER = 36060;
        GLConst.GL_EXP = 2048;
        GLConst.GL_EXP2 = 2049;
    }
}
