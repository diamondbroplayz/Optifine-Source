// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

public interface IBufferSourceListener
{
    void finish(final fkf p0, final eie p1);
}
