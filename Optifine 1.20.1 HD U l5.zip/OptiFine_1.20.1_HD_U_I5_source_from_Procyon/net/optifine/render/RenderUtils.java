// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

public class RenderUtils
{
    private static boolean flushRenderBuffers;
    private static enn mc;
    
    public static boolean setFlushRenderBuffers(final boolean flushRenderBuffers) {
        final boolean prev = RenderUtils.flushRenderBuffers;
        RenderUtils.flushRenderBuffers = flushRenderBuffers;
        return prev;
    }
    
    public static boolean isFlushRenderBuffers() {
        return RenderUtils.flushRenderBuffers;
    }
    
    public static void flushRenderBuffers() {
        if (!RenderUtils.flushRenderBuffers) {
            return;
        }
        final fkd rtb = RenderUtils.mc.aN();
        rtb.b().flushRenderBuffers();
        rtb.c().flushRenderBuffers();
    }
    
    public static void finishRenderBuffers() {
        final fkd rtb = RenderUtils.mc.aN();
        rtb.b().b();
        rtb.c().b();
    }
    
    static {
        RenderUtils.flushRenderBuffers = true;
        RenderUtils.mc = enn.N();
    }
}
