// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

public class RenderTypes
{
    public static final fkf SOLID;
    public static final fkf CUTOUT_MIPPED;
    public static final fkf CUTOUT;
    public static final fkf TRANSLUCENT;
    public static final fkf TRANSLUCENT_NO_CRUMBLING;
    public static final fkf LEASH;
    public static final fkf WATER_MASK;
    public static final fkf GLINT;
    public static final fkf ENTITY_GLINT;
    public static final fkf LIGHTNING;
    public static final fkf LINES;
    
    static {
        SOLID = fkf.c();
        CUTOUT_MIPPED = fkf.d();
        CUTOUT = fkf.e();
        TRANSLUCENT = fkf.f();
        TRANSLUCENT_NO_CRUMBLING = fkf.h();
        LEASH = fkf.i();
        WATER_MASK = fkf.j();
        GLINT = fkf.n();
        ENTITY_GLINT = fkf.p();
        LIGHTNING = fkf.t();
        LINES = fkf.x();
    }
}
