// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import com.mojang.blaze3d.platform.GlStateManager;
import net.optifine.shaders.Shaders;
import net.optifine.shaders.ShadersTex;
import net.optifine.Config;
import java.nio.IntBuffer;
import org.lwjgl.PointerBuffer;

public class MultiTextureRenderer
{
    private static PointerBuffer bufferPositions;
    private static IntBuffer bufferCounts;
    private static boolean shaders;
    
    public static void draw(final eio.b drawMode, final int indexTypeIn, final MultiTextureData multiTextureData) {
        MultiTextureRenderer.shaders = Config.isShaders();
        final SpriteRenderData[] srds = multiTextureData.getSpriteRenderDatas();
        for (int i = 0; i < srds.length; ++i) {
            final SpriteRenderData srd = srds[i];
            draw(drawMode, indexTypeIn, srd);
        }
    }
    
    private static void draw(final eio.b drawMode, final int indexTypeIn, final SpriteRenderData srd) {
        final fuv sprite = srd.getSprite();
        final int[] positions = srd.getPositions();
        final int[] counts = srd.getCounts();
        sprite.bindSpriteTexture();
        if (MultiTextureRenderer.shaders) {
            final int normalTex = (sprite.spriteNormal != null) ? sprite.spriteNormal.glSpriteTextureId : 0;
            final int specularTex = (sprite.spriteSpecular != null) ? sprite.spriteSpecular.glSpriteTextureId : 0;
            final fuu at = sprite.getTextureAtlas();
            ShadersTex.bindNSTextures(normalTex, specularTex, at.isNormalBlend(), at.isSpecularBlend(), at.isMipmaps());
            if (Shaders.uniform_spriteBounds.isDefined()) {
                Shaders.uniform_spriteBounds.setValue(sprite.c(), sprite.g(), sprite.d(), sprite.h());
            }
        }
        if (MultiTextureRenderer.bufferPositions.capacity() < positions.length) {
            final int size = apa.c(positions.length);
            MultiTextureRenderer.bufferPositions = Config.createDirectPointerBuffer(size);
            MultiTextureRenderer.bufferCounts = Config.createDirectIntBuffer(size);
        }
        MultiTextureRenderer.bufferPositions.clear();
        MultiTextureRenderer.bufferCounts.clear();
        final int indexSize = getIndexSize(indexTypeIn);
        for (int i = 0; i < positions.length; ++i) {
            MultiTextureRenderer.bufferPositions.put((long)(drawMode.a(positions[i]) * indexSize));
        }
        for (int i = 0; i < counts.length; ++i) {
            MultiTextureRenderer.bufferCounts.put(drawMode.a(counts[i]));
        }
        MultiTextureRenderer.bufferPositions.flip();
        MultiTextureRenderer.bufferCounts.flip();
        GlStateManager.glMultiDrawElements(drawMode.i, MultiTextureRenderer.bufferCounts, indexTypeIn, MultiTextureRenderer.bufferPositions);
    }
    
    private static int getIndexSize(final int indexTypeIn) {
        if (indexTypeIn == 5125) {
            return 4;
        }
        if (indexTypeIn == 5123) {
            return 2;
        }
        return 1;
    }
    
    static {
        MultiTextureRenderer.bufferPositions = Config.createDirectPointerBuffer(1024);
        MultiTextureRenderer.bufferCounts = Config.createDirectIntBuffer(1024);
    }
}
