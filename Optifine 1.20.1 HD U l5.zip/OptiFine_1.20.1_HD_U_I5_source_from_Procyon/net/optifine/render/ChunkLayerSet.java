// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.render;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public class ChunkLayerSet implements Set<fkf>
{
    private boolean[] layers;
    private boolean empty;
    
    public ChunkLayerSet() {
        this.layers = new boolean[fkf.CHUNK_RENDER_TYPES.length];
        this.empty = true;
    }
    
    @Override
    public boolean add(final fkf renderType) {
        this.layers[renderType.ordinal()] = true;
        return this.empty = false;
    }
    
    public boolean contains(final fkf renderType) {
        return this.layers[renderType.ordinal()];
    }
    
    @Override
    public boolean contains(final Object obj) {
        return obj instanceof fkf && this.contains((fkf)obj);
    }
    
    @Override
    public boolean isEmpty() {
        return this.empty;
    }
    
    @Override
    public int size() {
        throw new UnsupportedOperationException("Not supported");
    }
    
    @Override
    public Iterator<fkf> iterator() {
        throw new UnsupportedOperationException("Not supported");
    }
    
    @Override
    public Object[] toArray() {
        throw new UnsupportedOperationException("Not supported");
    }
    
    @Override
    public <T> T[] toArray(final T[] a) {
        throw new UnsupportedOperationException("Not supported");
    }
    
    @Override
    public boolean remove(final Object o) {
        throw new UnsupportedOperationException("Not supported");
    }
    
    @Override
    public boolean containsAll(final Collection<?> c) {
        throw new UnsupportedOperationException("Not supported");
    }
    
    @Override
    public boolean addAll(final Collection<? extends fkf> c) {
        throw new UnsupportedOperationException("Not supported");
    }
    
    @Override
    public boolean retainAll(final Collection<?> c) {
        throw new UnsupportedOperationException("Not supported");
    }
    
    @Override
    public boolean removeAll(final Collection<?> c) {
        throw new UnsupportedOperationException("Not supported");
    }
    
    @Override
    public void clear() {
        throw new UnsupportedOperationException("Not supported");
    }
}
