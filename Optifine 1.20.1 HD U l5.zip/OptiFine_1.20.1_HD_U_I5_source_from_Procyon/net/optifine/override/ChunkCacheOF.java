// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.override;

import net.optifine.BlockPosM;
import java.util.Arrays;
import net.optifine.util.ArrayCache;
import net.optifine.render.RenderEnv;

public class ChunkCacheOF implements clp
{
    private final fmr chunkCache;
    private final int posX;
    private final int posY;
    private final int posZ;
    private final int sizeX;
    private final int sizeY;
    private final int sizeZ;
    private final int sizeXZ;
    private int[] combinedLights;
    private dcb[] blockStates;
    private cnk[] biomes;
    private final int arraySize;
    private RenderEnv renderEnv;
    private static final ArrayCache cacheCombinedLights;
    private static final ArrayCache cacheBlockStates;
    private static final ArrayCache cacheBiomes;
    
    public ChunkCacheOF(final fmr chunkCache, final gu posFromIn, final gu posToIn, final int subIn) {
        this.chunkCache = chunkCache;
        final int minChunkX = posFromIn.u() - subIn >> 4;
        final int minChunkY = posFromIn.v() - subIn >> 4;
        final int minChunkZ = posFromIn.w() - subIn >> 4;
        final int maxChunkX = posToIn.u() + subIn >> 4;
        final int maxChunkY = posToIn.v() + subIn >> 4;
        final int maxChunkZ = posToIn.w() + subIn >> 4;
        this.sizeX = maxChunkX - minChunkX + 1 << 4;
        this.sizeY = maxChunkY - minChunkY + 1 << 4;
        this.sizeZ = maxChunkZ - minChunkZ + 1 << 4;
        this.sizeXZ = this.sizeX * this.sizeZ;
        this.arraySize = this.sizeX * this.sizeY * this.sizeZ;
        this.posX = minChunkX << 4;
        this.posY = minChunkY << 4;
        this.posZ = minChunkZ << 4;
    }
    
    public int getPositionIndex(final gu pos) {
        final int dx = pos.u() - this.posX;
        if (dx < 0 || dx >= this.sizeX) {
            return -1;
        }
        final int dy = pos.v() - this.posY;
        if (dy < 0 || dy >= this.sizeY) {
            return -1;
        }
        final int dz = pos.w() - this.posZ;
        if (dz < 0 || dz >= this.sizeZ) {
            return -1;
        }
        return dy * this.sizeXZ + dz * this.sizeX + dx;
    }
    
    public int a(final cmv type, final gu pos) {
        return this.chunkCache.a(type, pos);
    }
    
    public dcb a_(final gu pos) {
        final int index = this.getPositionIndex(pos);
        if (index < 0 || index >= this.arraySize || this.blockStates == null) {
            return this.chunkCache.a_(pos);
        }
        dcb iblockstate = this.blockStates[index];
        if (iblockstate == null) {
            iblockstate = this.chunkCache.a_(pos);
            this.blockStates[index] = iblockstate;
        }
        return iblockstate;
    }
    
    public void renderStart() {
        if (this.combinedLights == null) {
            this.combinedLights = (int[])ChunkCacheOF.cacheCombinedLights.allocate(this.arraySize);
        }
        if (this.blockStates == null) {
            this.blockStates = (dcb[])ChunkCacheOF.cacheBlockStates.allocate(this.arraySize);
        }
        if (this.biomes == null) {
            this.biomes = (cnk[])ChunkCacheOF.cacheBiomes.allocate(this.arraySize);
        }
        Arrays.fill(this.combinedLights, -1);
        Arrays.fill(this.blockStates, null);
        Arrays.fill(this.biomes, null);
        this.loadBlockStates();
    }
    
    private void loadBlockStates() {
        if (this.sizeX != 48 || this.sizeY != 48 || this.sizeZ != 48) {
            return;
        }
        final dei chunk = this.chunkCache.getChunk(1, 1);
        final BlockPosM pos = new BlockPosM();
        for (int y = 16; y < 32; ++y) {
            final int dy = y * this.sizeXZ;
            for (int z = 16; z < 32; ++z) {
                final int dz = z * this.sizeX;
                for (int x = 16; x < 32; ++x) {
                    pos.setXyz(this.posX + x, this.posY + y, this.posZ + z);
                    final int index = dy + dz + x;
                    final dcb bs = chunk.a_((gu)pos);
                    this.blockStates[index] = bs;
                }
            }
        }
    }
    
    public void renderFinish() {
        ChunkCacheOF.cacheCombinedLights.free(this.combinedLights);
        this.combinedLights = null;
        ChunkCacheOF.cacheBlockStates.free(this.blockStates);
        this.blockStates = null;
        ChunkCacheOF.cacheBiomes.free(this.biomes);
        this.biomes = null;
        this.chunkCache.finish();
    }
    
    public int[] getCombinedLights() {
        return this.combinedLights;
    }
    
    public cnk getBiome(final gu pos) {
        final int index = this.getPositionIndex(pos);
        if (index < 0 || index >= this.arraySize || this.biomes == null) {
            return this.chunkCache.getBiome(pos);
        }
        cnk biome = this.biomes[index];
        if (biome == null) {
            biome = this.chunkCache.getBiome(pos);
            this.biomes[index] = biome;
        }
        return biome;
    }
    
    public czn c_(final gu pos) {
        return this.chunkCache.c_(pos);
    }
    
    public boolean g(final gu pos) {
        return this.chunkCache.g(pos);
    }
    
    public dxe b_(final gu pos) {
        return this.a_(pos).u();
    }
    
    public int a(final gu blockPosIn, final clx colorResolverIn) {
        return this.chunkCache.a(blockPosIn, colorResolverIn);
    }
    
    public dwt s_() {
        return this.chunkCache.s_();
    }
    
    public RenderEnv getRenderEnv() {
        return this.renderEnv;
    }
    
    public void setRenderEnv(final RenderEnv renderEnv) {
        this.renderEnv = renderEnv;
    }
    
    public float a(final ha directionIn, final boolean shadeIn) {
        return this.chunkCache.a(directionIn, shadeIn);
    }
    
    public int D_() {
        return this.chunkCache.D_();
    }
    
    public int C_() {
        return this.chunkCache.C_();
    }
    
    static {
        cacheCombinedLights = new ArrayCache(Integer.TYPE, 16);
        cacheBlockStates = new ArrayCache(dcb.class, 16);
        cacheBiomes = new ArrayCache(cnk.class, 16);
    }
}
