// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.override;

public class PlayerControllerOF extends ffa
{
    private boolean acting;
    private gu lastClickBlockPos;
    private bfj lastClickEntity;
    
    public PlayerControllerOF(final enn mcIn, final fex netHandler) {
        super(mcIn, netHandler);
        this.acting = false;
        this.lastClickBlockPos = null;
        this.lastClickEntity = null;
    }
    
    public boolean a(final gu loc, final ha face) {
        this.acting = true;
        this.lastClickBlockPos = loc;
        final boolean res = super.a(loc, face);
        this.acting = false;
        return res;
    }
    
    public boolean b(final gu posBlock, final ha directionFacing) {
        this.acting = true;
        this.lastClickBlockPos = posBlock;
        final boolean res = super.b(posBlock, directionFacing);
        this.acting = false;
        return res;
    }
    
    public bdx a(final byo player, final bdw hand) {
        this.acting = true;
        final bdx res = super.a(player, hand);
        this.acting = false;
        return res;
    }
    
    public bdx a(final fiy player, final bdw hand, final eee rayTrace) {
        this.acting = true;
        this.lastClickBlockPos = rayTrace.a();
        final bdx res = super.a(player, hand, rayTrace);
        this.acting = false;
        return res;
    }
    
    public bdx a(final byo player, final bfj target, final bdw hand) {
        this.lastClickEntity = target;
        return super.a(player, target, hand);
    }
    
    public bdx a(final byo player, final bfj target, final eef ray, final bdw hand) {
        this.lastClickEntity = target;
        return super.a(player, target, ray, hand);
    }
    
    public boolean isActing() {
        return this.acting;
    }
    
    public gu getLastClickBlockPos() {
        return this.lastClickBlockPos;
    }
    
    public bfj getLastClickEntity() {
        return this.lastClickEntity;
    }
}
