// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.shaders.config;

public class ShaderOptionRest extends ShaderOption
{
    public ShaderOptionRest(final String name) {
        super(name, name, null, new String[] { null }, null, null);
    }
}
