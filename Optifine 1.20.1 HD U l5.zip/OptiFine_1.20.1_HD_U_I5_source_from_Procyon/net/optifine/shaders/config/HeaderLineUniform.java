// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.shaders.config;

public class HeaderLineUniform extends HeaderLineVariable
{
    public HeaderLineUniform(final String name, final String text) {
        super("uniform", name, text);
    }
}
