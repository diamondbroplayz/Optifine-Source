// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.shaders;

public class SVertexAttrib
{
    public int index;
    public int count;
    public eip.a type;
    public int offset;
    
    public SVertexAttrib(final int index, final int count, final eip.a type) {
        this.index = index;
        this.count = count;
        this.type = type;
    }
}
