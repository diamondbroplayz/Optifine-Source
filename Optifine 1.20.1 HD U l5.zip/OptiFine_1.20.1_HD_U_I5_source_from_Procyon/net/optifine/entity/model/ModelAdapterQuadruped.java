// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;

public abstract class ModelAdapterQuadruped extends ModelAdapter
{
    public ModelAdapterQuadruped(final bfn type, final String name, final float shadowSize) {
        super(type, name, shadowSize);
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fcp)) {
            return null;
        }
        final fcp modelQuadruped = (fcp)model;
        if (modelPart.equals("head")) {
            return (fee)Reflector.ModelQuadruped_ModelRenderers.getValue(modelQuadruped, 0);
        }
        if (modelPart.equals("body")) {
            return (fee)Reflector.ModelQuadruped_ModelRenderers.getValue(modelQuadruped, 1);
        }
        if (modelPart.equals("leg1")) {
            return (fee)Reflector.ModelQuadruped_ModelRenderers.getValue(modelQuadruped, 2);
        }
        if (modelPart.equals("leg2")) {
            return (fee)Reflector.ModelQuadruped_ModelRenderers.getValue(modelQuadruped, 3);
        }
        if (modelPart.equals("leg3")) {
            return (fee)Reflector.ModelQuadruped_ModelRenderers.getValue(modelQuadruped, 4);
        }
        if (modelPart.equals("leg4")) {
            return (fee)Reflector.ModelQuadruped_ModelRenderers.getValue(modelQuadruped, 5);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "head", "body", "leg1", "leg2", "leg3", "leg4" };
    }
}
