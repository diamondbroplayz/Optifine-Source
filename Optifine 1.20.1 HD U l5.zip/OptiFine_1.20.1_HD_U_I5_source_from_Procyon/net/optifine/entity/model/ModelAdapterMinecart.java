// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import net.optifine.reflect.Reflector;

public class ModelAdapterMinecart extends ModelAdapter
{
    public ModelAdapterMinecart() {
        super(bfn.an, "minecart", 0.5f);
    }
    
    protected ModelAdapterMinecart(final bfn type, final String name, final float shadow) {
        super(type, name, shadow);
    }
    
    public fcb makeModel() {
        return (fcb)new fca(bakeModelLayer(fed.av));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fca)) {
            return null;
        }
        final fca modelMinecart = (fca)model;
        if (modelPart.equals("bottom")) {
            return modelMinecart.a().getChildModelDeep("bottom");
        }
        if (modelPart.equals("back")) {
            return modelMinecart.a().getChildModelDeep("back");
        }
        if (modelPart.equals("front")) {
            return modelMinecart.a().getChildModelDeep("front");
        }
        if (modelPart.equals("right")) {
            return modelMinecart.a().getChildModelDeep("right");
        }
        if (modelPart.equals("left")) {
            return modelMinecart.a().getChildModelDeep("left");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "bottom", "back", "front", "right", "left" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqd render = new fqd(renderManager.getContext(), fed.av);
        if (!Reflector.RenderMinecart_modelMinecart.exists()) {
            Config.warn("Field not found: RenderMinecart.modelMinecart");
            return null;
        }
        Reflector.setFieldValue(render, Reflector.RenderMinecart_modelMinecart, modelBase);
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
