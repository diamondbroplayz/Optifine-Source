// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterHeadZombie extends ModelAdapterHead
{
    public ModelAdapterHeadZombie() {
        super("head_zombie", fed.bY, cwp.b.d);
    }
}
