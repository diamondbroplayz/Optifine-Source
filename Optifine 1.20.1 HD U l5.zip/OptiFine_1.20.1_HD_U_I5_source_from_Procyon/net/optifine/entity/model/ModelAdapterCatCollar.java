// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.Iterator;
import java.util.List;
import net.optifine.Config;
import java.util.function.Supplier;

public class ModelAdapterCatCollar extends ModelAdapterOcelot
{
    public ModelAdapterCatCollar() {
        super(bfn.m, "cat_collar", 0.4f);
    }
    
    public fcb makeModel() {
        return (fcb)new faq(bakeModelLayer(fed.o));
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fof customRenderer = new fof(renderManager.getContext());
        customRenderer.f = (fbf)new faq(bakeModelLayer(fed.o));
        customRenderer.d = 0.4f;
        final fox render = rendererCache.get(bfn.m, index, (Supplier)ModelAdapterCatCollar::lambda$makeEntityRender$0);
        if (!(render instanceof fof)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, render));
            return null;
        }
        final fof renderCat = (fof)render;
        final fsi layer = new fsi((fqt)renderCat, renderManager.getContext().f());
        layer.b = (faq)modelBase;
        renderCat.removeLayers((Class)fsi.class);
        renderCat.a((ftg)layer);
        return (IEntityRenderer)renderCat;
    }
    
    public boolean setTextureLocation(final IEntityRenderer er, final acq textureLocation) {
        final fof renderCat = (fof)er;
        final List<fsi> layers = (List<fsi>)renderCat.getLayers((Class)fsi.class);
        for (final fsi layer : layers) {
            layer.b.locationTextureCustom = textureLocation;
        }
        return true;
    }
}
