// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;
import net.optifine.Config;
import java.util.function.Function;

public class BellModel extends fcb
{
    public fee bellBody;
    
    public BellModel() {
        super((Function)fkf::d);
        final flt dispatcher = Config.getMinecraft().ao();
        final fls renderer = new fls(dispatcher.getContext());
        this.bellBody = (fee)Reflector.TileEntityBellRenderer_modelRenderer.getValue(renderer);
    }
    
    public flu updateRenderer(final flu renderer) {
        if (!Reflector.TileEntityBellRenderer_modelRenderer.exists()) {
            Config.warn("Field not found: TileEntityBellRenderer.modelRenderer");
            return null;
        }
        Reflector.TileEntityBellRenderer_modelRenderer.setValue(renderer, this.bellBody);
        return renderer;
    }
    
    public void a(final eij matrixStackIn, final ein bufferIn, final int packedLightIn, final int packedOverlayIn, final float red, final float green, final float blue, final float alpha) {
    }
}
