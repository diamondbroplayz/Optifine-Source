// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;

public class ModelAdapterWitch extends ModelAdapterVillager
{
    public ModelAdapterWitch() {
        super(bfn.bj, "witch", 0.5f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdt(ModelAdapter.bakeModelLayer(fed.bN));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdt)) {
            return null;
        }
        final fdt modelWitch = (fdt)model;
        if (modelPart.equals("mole")) {
            return modelWitch.a().getChildModelDeep("mole");
        }
        return super.getModelRenderer((fcb)modelWitch, modelPart);
    }
    
    @Override
    public String[] getModelRendererNames() {
        String[] names = super.getModelRendererNames();
        names = (String[])Config.addObjectToArray(names, "mole");
        return names;
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frw render = new frw(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
