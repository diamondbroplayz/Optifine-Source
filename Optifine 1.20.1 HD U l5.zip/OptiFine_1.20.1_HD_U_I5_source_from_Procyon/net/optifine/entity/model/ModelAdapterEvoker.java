// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterEvoker extends ModelAdapterIllager
{
    public ModelAdapterEvoker() {
        super(bfn.G, "evoker", 0.5f, new String[] { "evocation_illager" });
    }
    
    public fcb makeModel() {
        return (fcb)new fbt(bakeModelLayer(fed.V));
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fpb render = new fpb(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
