// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.Iterator;
import java.util.Collection;
import java.util.HashSet;
import com.mojang.datafixers.util.Pair;
import java.util.HashMap;
import com.google.common.collect.ImmutableMap;
import java.util.Map;
import net.optifine.Config;
import net.optifine.reflect.Reflector;
import com.google.common.collect.ImmutableList;

public class ModelAdapterBoat extends ModelAdapter
{
    public ModelAdapterBoat() {
        super(bfn.k, "boat", 0.5f);
    }
    
    protected ModelAdapterBoat(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    public fcb makeModel() {
        return (fcb)new fan(bakeModelLayer(fed.c(cah.b.a)));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fan)) {
            return null;
        }
        final fan modelBoat = (fan)model;
        final ImmutableList<fee> parts = (ImmutableList<fee>)modelBoat.b();
        if (parts != null) {
            if (modelPart.equals("bottom")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 0);
            }
            if (modelPart.equals("back")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 1);
            }
            if (modelPart.equals("front")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 2);
            }
            if (modelPart.equals("right")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 3);
            }
            if (modelPart.equals("left")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 4);
            }
            if (modelPart.equals("paddle_left")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 5);
            }
            if (modelPart.equals("paddle_right")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 6);
            }
        }
        if (modelPart.equals("bottom_no_water")) {
            return modelBoat.c();
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "bottom", "back", "front", "right", "left", "paddle_left", "paddle_right", "bottom_no_water" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fod renderer = new fod(renderManager.getContext(), false);
        rendererCache.put(bfn.k, index, (fox)renderer);
        return makeEntityRender(modelBase, shadowSize, renderer);
    }
    
    protected static IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final fod render) {
        if (!Reflector.RenderBoat_boatResources.exists()) {
            Config.warn("Field not found: RenderBoat.boatResources");
            return null;
        }
        Map<cah.b, Pair<acq, fcb>> resources = (Map<cah.b, Pair<acq, fcb>>)Reflector.RenderBoat_boatResources.getValue(render);
        if (resources instanceof ImmutableMap) {
            resources = new HashMap<cah.b, Pair<acq, fcb>>(resources);
            Reflector.RenderBoat_boatResources.setValue(render, resources);
        }
        final Collection<cah.b> types = new HashSet<cah.b>(resources.keySet());
        for (final cah.b type : types) {
            Pair<acq, fcb> pair = resources.get(type);
            if (modelBase.getClass() != ((fcb)pair.getSecond()).getClass()) {
                continue;
            }
            pair = (Pair<acq, fcb>)Pair.of((Object)pair.getFirst(), (Object)modelBase);
            resources.put(type, pair);
        }
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
