// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;
import net.optifine.Config;
import java.util.function.Function;

public class ChestLargeModel extends fcb
{
    public fee lid_left;
    public fee base_left;
    public fee knob_left;
    public fee lid_right;
    public fee base_right;
    public fee knob_right;
    
    public ChestLargeModel() {
        super((Function)fkf::c);
        final flt dispatcher = Config.getMinecraft().ao();
        final fma renderer = new fma(dispatcher.getContext());
        this.lid_right = (fee)Reflector.TileEntityChestRenderer_modelRenderers.getValue(renderer, 3);
        this.base_right = (fee)Reflector.TileEntityChestRenderer_modelRenderers.getValue(renderer, 4);
        this.knob_right = (fee)Reflector.TileEntityChestRenderer_modelRenderers.getValue(renderer, 5);
        this.lid_left = (fee)Reflector.TileEntityChestRenderer_modelRenderers.getValue(renderer, 6);
        this.base_left = (fee)Reflector.TileEntityChestRenderer_modelRenderers.getValue(renderer, 7);
        this.knob_left = (fee)Reflector.TileEntityChestRenderer_modelRenderers.getValue(renderer, 8);
    }
    
    public flu updateRenderer(final flu renderer) {
        if (!Reflector.TileEntityChestRenderer_modelRenderers.exists()) {
            Config.warn("Field not found: TileEntityChestRenderer.modelRenderers");
            return null;
        }
        Reflector.TileEntityChestRenderer_modelRenderers.setValue(renderer, 3, this.lid_right);
        Reflector.TileEntityChestRenderer_modelRenderers.setValue(renderer, 4, this.base_right);
        Reflector.TileEntityChestRenderer_modelRenderers.setValue(renderer, 5, this.knob_right);
        Reflector.TileEntityChestRenderer_modelRenderers.setValue(renderer, 6, this.lid_left);
        Reflector.TileEntityChestRenderer_modelRenderers.setValue(renderer, 7, this.base_left);
        Reflector.TileEntityChestRenderer_modelRenderers.setValue(renderer, 8, this.knob_left);
        return renderer;
    }
    
    public void a(final eij matrixStackIn, final ein bufferIn, final int packedLightIn, final int packedOverlayIn, final float red, final float green, final float blue, final float alpha) {
    }
}
