// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import net.optifine.reflect.Reflector;

public class ModelAdapterLlamaSpit extends ModelAdapter
{
    public ModelAdapterLlamaSpit() {
        super(bfn.ak, "llama_spit", 0.0f);
    }
    
    public fcb makeModel() {
        return (fcb)new fbz(bakeModelLayer(fed.at));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fbz)) {
            return null;
        }
        final fbz modelLlamaSpit = (fbz)model;
        if (modelPart.equals("body")) {
            return modelLlamaSpit.a().getChildModelDeep("main");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqb render = new fqb(renderManager.getContext());
        if (!Reflector.RenderLlamaSpit_model.exists()) {
            Config.warn("Field not found: RenderLlamaSpit.model");
            return null;
        }
        Reflector.setFieldValue(render, Reflector.RenderLlamaSpit_model, modelBase);
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
