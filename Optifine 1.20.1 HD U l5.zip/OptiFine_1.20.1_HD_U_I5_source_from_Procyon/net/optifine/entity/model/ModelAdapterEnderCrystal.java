// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import java.util.function.Supplier;

public class ModelAdapterEnderCrystal extends ModelAdapter
{
    public ModelAdapterEnderCrystal() {
        this("end_crystal");
    }
    
    protected ModelAdapterEnderCrystal(final String name) {
        super(bfn.B, name, 0.5f);
    }
    
    public fcb makeModel() {
        return new EnderCrystalModel();
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof EnderCrystalModel)) {
            return null;
        }
        final EnderCrystalModel modelEnderCrystal = (EnderCrystalModel)model;
        if (modelPart.equals("cube")) {
            return modelEnderCrystal.cube;
        }
        if (modelPart.equals("glass")) {
            return modelEnderCrystal.glass;
        }
        if (modelPart.equals("base")) {
            return modelEnderCrystal.base;
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "cube", "glass", "base" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fox renderObj = rendererCache.get(bfn.B, index, (Supplier)ModelAdapterEnderCrystal::lambda$makeEntityRender$0);
        if (!(renderObj instanceof fos)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, renderObj));
            return null;
        }
        fos render = (fos)renderObj;
        if (!(modelBase instanceof EnderCrystalModel)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfcb;)Ljava/lang/String;, modelBase));
            return null;
        }
        final EnderCrystalModel enderCrystalModel = (EnderCrystalModel)modelBase;
        render = enderCrystalModel.updateRenderer(render);
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
