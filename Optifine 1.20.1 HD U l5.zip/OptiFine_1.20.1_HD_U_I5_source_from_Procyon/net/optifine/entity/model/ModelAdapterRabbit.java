// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.LinkedHashMap;
import net.optifine.reflect.Reflector;
import java.util.Map;

public class ModelAdapterRabbit extends ModelAdapter
{
    private static Map<String, Integer> mapPartFields;
    
    public ModelAdapterRabbit() {
        super(bfn.aC, "rabbit", 0.3f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fcq(ModelAdapter.bakeModelLayer(fed.aY));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fcq)) {
            return null;
        }
        final fcq modelRabbit = (fcq)model;
        final Map<String, Integer> mapParts = getMapPartFields();
        if (mapParts.containsKey(modelPart)) {
            final int index = mapParts.get(modelPart);
            return (fee)Reflector.getFieldValue(modelRabbit, Reflector.ModelRabbit_ModelRenderers, index);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "left_foot", "right_foot", "left_thigh", "right_thigh", "body", "left_arm", "right_arm", "head", "right_ear", "left_ear", "tail", "nose" };
    }
    
    private static Map<String, Integer> getMapPartFields() {
        if (ModelAdapterRabbit.mapPartFields != null) {
            return ModelAdapterRabbit.mapPartFields;
        }
        (ModelAdapterRabbit.mapPartFields = new LinkedHashMap<String, Integer>()).put("left_foot", 0);
        ModelAdapterRabbit.mapPartFields.put("right_foot", 1);
        ModelAdapterRabbit.mapPartFields.put("left_thigh", 2);
        ModelAdapterRabbit.mapPartFields.put("right_thigh", 3);
        ModelAdapterRabbit.mapPartFields.put("body", 4);
        ModelAdapterRabbit.mapPartFields.put("left_arm", 5);
        ModelAdapterRabbit.mapPartFields.put("right_arm", 6);
        ModelAdapterRabbit.mapPartFields.put("head", 7);
        ModelAdapterRabbit.mapPartFields.put("right_ear", 8);
        ModelAdapterRabbit.mapPartFields.put("left_ear", 9);
        ModelAdapterRabbit.mapPartFields.put("tail", 10);
        ModelAdapterRabbit.mapPartFields.put("nose", 11);
        return ModelAdapterRabbit.mapPartFields;
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqr render = new fqr(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
    
    static {
        ModelAdapterRabbit.mapPartFields = null;
    }
}
