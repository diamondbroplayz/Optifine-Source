// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.Iterator;
import java.util.List;
import net.optifine.Config;
import java.util.function.Supplier;

public class ModelAdapterCreeperCharge extends ModelAdapterCreeper
{
    public ModelAdapterCreeperCharge() {
        super(bfn.u, "creeper_charge", 0.25f);
    }
    
    public fcb makeModel() {
        return (fcb)new faz(bakeModelLayer(fed.C));
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fol customRenderer = new fol(renderManager.getContext());
        customRenderer.f = (fbf)new faz(bakeModelLayer(fed.C));
        customRenderer.d = 0.25f;
        final fox render = rendererCache.get(bfn.u, index, (Supplier)ModelAdapterCreeperCharge::lambda$makeEntityRender$0);
        if (!(render instanceof fol)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, render));
            return null;
        }
        final fol renderCreeper = (fol)render;
        final fsj layer = new fsj((fqt)renderCreeper, renderManager.getContext().f());
        layer.b = (faz)modelBase;
        renderCreeper.removeLayers((Class)fsj.class);
        renderCreeper.a((ftg)layer);
        return (IEntityRenderer)renderCreeper;
    }
    
    public boolean setTextureLocation(final IEntityRenderer er, final acq textureLocation) {
        final fol renderer = (fol)er;
        final List<fsj> layers = (List<fsj>)renderer.getLayers((Class)fsj.class);
        for (final fsj layer : layers) {
            layer.customTextureLocation = textureLocation;
        }
        return true;
    }
}
