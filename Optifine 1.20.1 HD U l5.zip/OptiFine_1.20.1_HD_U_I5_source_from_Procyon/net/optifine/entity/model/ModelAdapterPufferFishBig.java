// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;
import net.optifine.Config;

public class ModelAdapterPufferFishBig extends ModelAdapter
{
    public ModelAdapterPufferFishBig() {
        super(bfn.aB, "puffer_fish_big", 0.2f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fcm(ModelAdapter.bakeModelLayer(fed.aV));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fcm)) {
            return null;
        }
        final fcm modelPufferFishBig = (fcm)model;
        if (modelPart.equals("body")) {
            return modelPufferFishBig.a().getChildModelDeep("body");
        }
        if (modelPart.equals("fin_right")) {
            return modelPufferFishBig.a().getChildModelDeep("right_blue_fin");
        }
        if (modelPart.equals("fin_left")) {
            return modelPufferFishBig.a().getChildModelDeep("left_blue_fin");
        }
        if (modelPart.equals("spikes_front_top")) {
            return modelPufferFishBig.a().getChildModelDeep("top_front_fin");
        }
        if (modelPart.equals("spikes_middle_top")) {
            return modelPufferFishBig.a().getChildModelDeep("top_middle_fin");
        }
        if (modelPart.equals("spikes_back_top")) {
            return modelPufferFishBig.a().getChildModelDeep("top_back_fin");
        }
        if (modelPart.equals("spikes_front_right")) {
            return modelPufferFishBig.a().getChildModelDeep("right_front_fin");
        }
        if (modelPart.equals("spikes_front_left")) {
            return modelPufferFishBig.a().getChildModelDeep("left_front_fin");
        }
        if (modelPart.equals("spikes_front_bottom")) {
            return modelPufferFishBig.a().getChildModelDeep("bottom_front_fin");
        }
        if (modelPart.equals("spikes_middle_bottom")) {
            return modelPufferFishBig.a().getChildModelDeep("bottom_middle_fin");
        }
        if (modelPart.equals("spikes_back_bottom")) {
            return modelPufferFishBig.a().getChildModelDeep("bottom_back_fin");
        }
        if (modelPart.equals("spikes_back_right")) {
            return modelPufferFishBig.a().getChildModelDeep("right_back_fin");
        }
        if (modelPart.equals("spikes_back_left")) {
            return modelPufferFishBig.a().getChildModelDeep("left_back_fin");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body", "fin_right", "fin_left", "spikes_front_top", "spikes_middle_top", "spikes_back_top", "spikes_front_right", "spikes_front_left", "spikes_front_bottom", "spikes_middle_bottom", "spikes_back_bottom", "spikes_back_right", "spikes_back_left" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqq customRenderer = new fqq(renderManager.getContext());
        customRenderer.d = shadowSize;
        final fox render = rendererCache.get(bfn.aB, index, () -> customRenderer);
        if (!(render instanceof fqq)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, render));
            return null;
        }
        final fqq renderFish = (fqq)render;
        if (!Reflector.RenderPufferfish_modelBig.exists()) {
            Config.warn("Model field not found: RenderPufferfish.modelBig");
            return null;
        }
        Reflector.RenderPufferfish_modelBig.setValue(renderFish, modelBase);
        return (IEntityRenderer)renderFish;
    }
}
