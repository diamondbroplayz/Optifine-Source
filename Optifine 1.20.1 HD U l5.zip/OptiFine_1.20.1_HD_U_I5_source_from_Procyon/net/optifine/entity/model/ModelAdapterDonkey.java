// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.List;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import net.optifine.reflect.Reflector;

public class ModelAdapterDonkey extends ModelAdapterHorse
{
    public ModelAdapterDonkey() {
        super(bfn.w, "donkey", 0.75f);
    }
    
    public fcb makeModel() {
        return (fcb)new fat(bakeModelLayer(fed.H));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fat)) {
            return null;
        }
        final fat modelHorseChests = (fat)model;
        if (modelPart.equals("left_chest")) {
            return (fee)Reflector.ModelHorseChests_ModelRenderers.getValue(modelHorseChests, 0);
        }
        if (modelPart.equals("right_chest")) {
            return (fee)Reflector.ModelHorseChests_ModelRenderers.getValue(modelHorseChests, 1);
        }
        return super.getModelRenderer(model, modelPart);
    }
    
    @Override
    public String[] getModelRendererNames() {
        final List<String> list = new ArrayList<String>(Arrays.asList(super.getModelRendererNames()));
        list.add("left_chest");
        list.add("right_chest");
        return list.toArray(new String[list.size()]);
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final foh render = new foh(renderManager.getContext(), 0.87f, fed.H);
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
