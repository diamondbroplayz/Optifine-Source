// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.function.Supplier;
import net.optifine.Config;

public class ModelAdapterBed extends ModelAdapter
{
    public ModelAdapterBed() {
        super(czp.y, "bed", 0.0f);
    }
    
    public fcb makeModel() {
        return new BedModel();
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof BedModel)) {
            return null;
        }
        final BedModel modelBed = (BedModel)model;
        if (modelPart.equals("head")) {
            return modelBed.headPiece;
        }
        if (modelPart.equals("foot")) {
            return modelBed.footPiece;
        }
        final fee[] legs = modelBed.legs;
        if (legs != null) {
            if (modelPart.equals("leg1")) {
                return legs[0];
            }
            if (modelPart.equals("leg2")) {
                return legs[1];
            }
            if (modelPart.equals("leg3")) {
                return legs[2];
            }
            if (modelPart.equals("leg4")) {
                return legs[3];
            }
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "head", "foot", "leg1", "leg2", "leg3", "leg4" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final flt dispatcher = Config.getMinecraft().ao();
        flu renderer = rendererCache.get(czp.y, index, (Supplier)ModelAdapterBed::lambda$makeEntityRender$0);
        if (!(renderer instanceof flr)) {
            return null;
        }
        if (!(modelBase instanceof BedModel)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfcb;)Ljava/lang/String;, modelBase));
            return null;
        }
        final BedModel bedModel = (BedModel)modelBase;
        renderer = bedModel.updateRenderer(renderer);
        return (IEntityRenderer)renderer;
    }
}
