// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;

public class ModelAdapterGoat extends ModelAdapterQuadruped
{
    public ModelAdapterGoat() {
        super(bfn.U, "goat", 0.7f);
    }
    
    public fcb makeModel() {
        return (fcb)new fbl(bakeModelLayer(fed.af));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fbl)) {
            return null;
        }
        final fbl modelGoat = (fbl)model;
        final fee head = super.getModelRenderer((fcb)modelGoat, "head");
        if (head != null) {
            if (modelPart.equals("left_horn")) {
                return head.b(modelPart);
            }
            if (modelPart.equals("right_horn")) {
                return head.b(modelPart);
            }
            if (modelPart.equals("nose")) {
                return head.b(modelPart);
            }
        }
        return super.getModelRenderer(model, modelPart);
    }
    
    @Override
    public String[] getModelRendererNames() {
        String[] names = super.getModelRendererNames();
        names = (String[])Config.addObjectsToArray(names, new String[] { "left_horn", "right_horn", "nose" });
        return names;
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fpl render = new fpl(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
