// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterDolphin extends ModelAdapter
{
    public ModelAdapterDolphin() {
        super(bfn.v, "dolphin", 0.7f);
    }
    
    public fcb makeModel() {
        return (fcb)new fba(bakeModelLayer(fed.G));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fba)) {
            return null;
        }
        final fba modelDolphin = (fba)model;
        final fee modelBody = modelDolphin.a().b("body");
        if (modelBody == null) {
            return null;
        }
        if (modelPart.equals("body")) {
            return modelBody;
        }
        if (modelPart.equals("back_fin")) {
            return modelBody.b("back_fin");
        }
        if (modelPart.equals("left_fin")) {
            return modelBody.b("left_fin");
        }
        if (modelPart.equals("right_fin")) {
            return modelBody.b("right_fin");
        }
        if (modelPart.equals("tail")) {
            return modelBody.b("tail");
        }
        if (modelPart.equals("tail_fin")) {
            return modelBody.b("tail").b("tail_fin");
        }
        if (modelPart.equals("head")) {
            return modelBody.b("head");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body", "back_fin", "left_fin", "right_fin", "tail", "tail_fin", "head" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fon render = new fon(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
