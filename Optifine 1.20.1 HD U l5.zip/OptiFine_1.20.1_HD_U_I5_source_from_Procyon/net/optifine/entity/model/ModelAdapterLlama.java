// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;

public class ModelAdapterLlama extends ModelAdapter
{
    public ModelAdapterLlama() {
        super(bfn.aj, "llama", 0.7f);
    }
    
    public ModelAdapterLlama(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    public fcb makeModel() {
        return (fcb)new fby(bakeModelLayer(fed.ar));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fby)) {
            return null;
        }
        final fby modelLlama = (fby)model;
        if (modelPart.equals("head")) {
            return (fee)Reflector.ModelLlama_ModelRenderers.getValue(modelLlama, 0);
        }
        if (modelPart.equals("body")) {
            return (fee)Reflector.ModelLlama_ModelRenderers.getValue(modelLlama, 1);
        }
        if (modelPart.equals("leg1")) {
            return (fee)Reflector.ModelLlama_ModelRenderers.getValue(modelLlama, 2);
        }
        if (modelPart.equals("leg2")) {
            return (fee)Reflector.ModelLlama_ModelRenderers.getValue(modelLlama, 3);
        }
        if (modelPart.equals("leg3")) {
            return (fee)Reflector.ModelLlama_ModelRenderers.getValue(modelLlama, 4);
        }
        if (modelPart.equals("leg4")) {
            return (fee)Reflector.ModelLlama_ModelRenderers.getValue(modelLlama, 5);
        }
        if (modelPart.equals("chest_right")) {
            return (fee)Reflector.ModelLlama_ModelRenderers.getValue(modelLlama, 6);
        }
        if (modelPart.equals("chest_left")) {
            return (fee)Reflector.ModelLlama_ModelRenderers.getValue(modelLlama, 7);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "head", "body", "leg1", "leg2", "leg3", "leg4", "chest_right", "chest_left" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqa render = new fqa(renderManager.getContext(), fed.ar);
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
