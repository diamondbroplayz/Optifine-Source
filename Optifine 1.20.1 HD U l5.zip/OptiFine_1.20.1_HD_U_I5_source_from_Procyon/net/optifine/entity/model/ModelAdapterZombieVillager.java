// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterZombieVillager extends ModelAdapterBiped
{
    public ModelAdapterZombieVillager() {
        super(bfn.br, "zombie_villager", 0.5f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdx(ModelAdapter.bakeModelLayer(fed.cc));
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final aku resourceManager = (aku)enn.N().Y();
        final fow renderManager = enn.N().an();
        final fsd render = new fsd(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
