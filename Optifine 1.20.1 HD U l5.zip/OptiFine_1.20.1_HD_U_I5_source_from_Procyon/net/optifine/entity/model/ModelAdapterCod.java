// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterCod extends ModelAdapter
{
    public ModelAdapterCod() {
        super(bfn.r, "cod", 0.3f);
    }
    
    public fcb makeModel() {
        return (fcb)new fav(bakeModelLayer(fed.u));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fav)) {
            return null;
        }
        final fav modelCod = (fav)model;
        if (modelPart.equals("body")) {
            return modelCod.a().getChildModelDeep("body");
        }
        if (modelPart.equals("fin_back")) {
            return modelCod.a().getChildModelDeep("top_fin");
        }
        if (modelPart.equals("head")) {
            return modelCod.a().getChildModelDeep("head");
        }
        if (modelPart.equals("nose")) {
            return modelCod.a().getChildModelDeep("nose");
        }
        if (modelPart.equals("fin_right")) {
            return modelCod.a().getChildModelDeep("right_fin");
        }
        if (modelPart.equals("fin_left")) {
            return modelCod.a().getChildModelDeep("left_fin");
        }
        if (modelPart.equals("tail")) {
            return modelCod.a().getChildModelDeep("tail_fin");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body", "fin_back", "head", "nose", "fin_right", "fin_left", "tail" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final foj render = new foj(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
