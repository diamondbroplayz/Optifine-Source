// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterTraderLlamaDecor extends ModelAdapterLlamaDecor
{
    public ModelAdapterTraderLlamaDecor() {
        super(bfn.ba, "trader_llama_decor", 0.7f);
    }
}
