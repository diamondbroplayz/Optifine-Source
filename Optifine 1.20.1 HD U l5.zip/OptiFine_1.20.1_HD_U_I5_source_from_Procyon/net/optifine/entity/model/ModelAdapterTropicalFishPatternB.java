// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.Iterator;
import java.util.List;
import net.optifine.reflect.Reflector;
import net.optifine.Config;

public class ModelAdapterTropicalFishPatternB extends ModelAdapterTropicalFishB
{
    public ModelAdapterTropicalFishPatternB() {
        super(bfn.bc, "tropical_fish_pattern_b", 0.2f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdm(ModelAdapter.bakeModelLayer(fed.bE));
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fro customRenderer = new fro(renderManager.getContext());
        customRenderer.f = (fbf)new fdm(ModelAdapter.bakeModelLayer(fed.bE));
        customRenderer.d = 0.2f;
        final fox render = rendererCache.get(bfn.bc, index, () -> customRenderer);
        if (!(render instanceof fro)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, render));
            return null;
        }
        final fro renderTropicalFish = (fro)render;
        ftq layer = (ftq)renderTropicalFish.getLayer((Class)ftq.class);
        if (layer == null || !layer.custom) {
            layer = new ftq((fqt)renderTropicalFish, renderManager.getContext().f());
            layer.custom = true;
        }
        if (!Reflector.TropicalFishPatternLayer_modelB.exists()) {
            Config.warn("Field not found: TropicalFishPatternLayer.modelB");
            return null;
        }
        Reflector.TropicalFishPatternLayer_modelB.setValue(layer, modelBase);
        renderTropicalFish.removeLayers((Class)ftq.class);
        renderTropicalFish.a((ftg)layer);
        return (IEntityRenderer)renderTropicalFish;
    }
    
    @Override
    public boolean setTextureLocation(final IEntityRenderer er, final acq textureLocation) {
        final fro renderTropicalFish = (fro)er;
        final List<ftq> layers = (List<ftq>)renderTropicalFish.getLayers((Class)ftq.class);
        for (final ftq layer : layers) {
            final fdm modelB = (fdm)Reflector.TropicalFishPatternLayer_modelB.getValue(layer);
            if (modelB != null) {
                modelB.locationTextureCustom = textureLocation;
            }
        }
        return true;
    }
}
