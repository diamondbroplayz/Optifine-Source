// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterStray extends ModelAdapterBiped
{
    public ModelAdapterStray() {
        super(bfn.aU, "stray", 0.7f);
    }
    
    public ModelAdapterStray(final bfn type, final String name, final float shadowSize) {
        super(type, name, shadowSize);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fda(ModelAdapter.bakeModelLayer(fed.bt));
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frg render = new frg(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
