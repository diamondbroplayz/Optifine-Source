// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import net.optifine.reflect.Reflector;

public class ModelAdapterTrident extends ModelAdapter
{
    public ModelAdapterTrident() {
        super(bfn.bb, "trident", 0.0f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdk(ModelAdapter.bakeModelLayer(fed.bC));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdk)) {
            return null;
        }
        final fdk modelTrident = (fdk)model;
        if (modelPart.equals("body")) {
            final fee root = (fee)Reflector.ModelTrident_root.getValue(modelTrident);
            if (root != null) {
                return root.getChildModelDeep("pole");
            }
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frk render = new frk(renderManager.getContext());
        if (!Reflector.RenderTrident_modelTrident.exists()) {
            Config.warn("Field not found: RenderTrident.modelTrident");
            return null;
        }
        Reflector.setFieldValue(render, Reflector.RenderTrident_modelTrident, modelBase);
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
