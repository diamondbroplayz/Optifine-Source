// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterHeadCreeper extends ModelAdapterHead
{
    public ModelAdapterHeadCreeper() {
        super("head_creeper", fed.D, cwp.b.e);
    }
}
