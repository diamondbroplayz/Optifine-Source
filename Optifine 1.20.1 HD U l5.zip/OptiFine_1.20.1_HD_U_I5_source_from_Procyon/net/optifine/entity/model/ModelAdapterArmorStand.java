// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import net.optifine.reflect.Reflector;

public class ModelAdapterArmorStand extends ModelAdapterBiped
{
    public ModelAdapterArmorStand() {
        super(bfn.d, "armor_stand", 0.0f);
    }
    
    public fcb makeModel() {
        return (fcb)new fai(bakeModelLayer(fed.b));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fai)) {
            return null;
        }
        final fai modelArmorStand = (fai)model;
        if (modelPart.equals("right")) {
            return (fee)Reflector.getFieldValue(modelArmorStand, Reflector.ModelArmorStand_ModelRenderers, 0);
        }
        if (modelPart.equals("left")) {
            return (fee)Reflector.getFieldValue(modelArmorStand, Reflector.ModelArmorStand_ModelRenderers, 1);
        }
        if (modelPart.equals("waist")) {
            return (fee)Reflector.getFieldValue(modelArmorStand, Reflector.ModelArmorStand_ModelRenderers, 2);
        }
        if (modelPart.equals("base")) {
            return (fee)Reflector.getFieldValue(modelArmorStand, Reflector.ModelArmorStand_ModelRenderers, 3);
        }
        return super.getModelRenderer((fcb)modelArmorStand, modelPart);
    }
    
    @Override
    public String[] getModelRendererNames() {
        String[] names = super.getModelRendererNames();
        names = (String[])Config.addObjectsToArray(names, new String[] { "right", "left", "waist", "base" });
        return names;
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fnx render = new fnx(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
