// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import com.google.common.collect.ImmutableList;
import java.util.Iterator;

public class ModelRendererUtils
{
    public static fee getModelRenderer(final Iterator<fee> iterator, final int index) {
        if (iterator == null) {
            return null;
        }
        if (index < 0) {
            return null;
        }
        for (int i = 0; i < index; ++i) {
            if (!iterator.hasNext()) {
                return null;
            }
            final fee fee = iterator.next();
        }
        if (!iterator.hasNext()) {
            return null;
        }
        final fee model = iterator.next();
        return model;
    }
    
    public static fee getModelRenderer(final ImmutableList<fee> models, final int index) {
        if (models == null) {
            return null;
        }
        if (index < 0) {
            return null;
        }
        if (index >= models.size()) {
            return null;
        }
        return (fee)models.get(index);
    }
}
