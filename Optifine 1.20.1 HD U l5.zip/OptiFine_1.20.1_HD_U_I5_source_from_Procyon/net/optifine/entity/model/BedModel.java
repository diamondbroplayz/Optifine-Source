// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;
import net.optifine.Config;
import java.util.function.Function;

public class BedModel extends fcb
{
    public fee headPiece;
    public fee footPiece;
    public fee[] legs;
    
    public BedModel() {
        super((Function)fkf::d);
        this.legs = new fee[4];
        final flt dispatcher = Config.getMinecraft().ao();
        final flr renderer = new flr(dispatcher.getContext());
        final fee headRoot = (fee)Reflector.TileEntityBedRenderer_headModel.getValue(renderer);
        if (headRoot != null) {
            this.headPiece = headRoot.b("main");
            this.legs[0] = headRoot.b("left_leg");
            this.legs[1] = headRoot.b("right_leg");
        }
        final fee footRoot = (fee)Reflector.TileEntityBedRenderer_footModel.getValue(renderer);
        if (footRoot != null) {
            this.footPiece = footRoot.b("main");
            this.legs[2] = footRoot.b("left_leg");
            this.legs[3] = footRoot.b("right_leg");
        }
    }
    
    public void a(final eij matrixStackIn, final ein bufferIn, final int packedLightIn, final int packedOverlayIn, final float red, final float green, final float blue, final float alpha) {
    }
    
    public flu updateRenderer(final flu renderer) {
        if (!Reflector.TileEntityBedRenderer_headModel.exists()) {
            Config.warn("Field not found: TileEntityBedRenderer.head");
            return null;
        }
        if (!Reflector.TileEntityBedRenderer_footModel.exists()) {
            Config.warn("Field not found: TileEntityBedRenderer.footModel");
            return null;
        }
        final fee headRoot = (fee)Reflector.TileEntityBedRenderer_headModel.getValue(renderer);
        if (headRoot != null) {
            headRoot.addChildModel("main", this.headPiece);
            headRoot.addChildModel("left_leg", this.legs[0]);
            headRoot.addChildModel("right_leg", this.legs[1]);
        }
        final fee footRoot = (fee)Reflector.TileEntityBedRenderer_footModel.getValue(renderer);
        if (footRoot != null) {
            footRoot.addChildModel("main", this.footPiece);
            footRoot.addChildModel("left_leg", this.legs[2]);
            footRoot.addChildModel("right_leg", this.legs[3]);
        }
        return renderer;
    }
}
