// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.LinkedHashMap;
import net.optifine.reflect.Reflector;
import java.util.Map;

public class ModelAdapterAxolotl extends ModelAdapter
{
    private static Map<String, Integer> mapPartFields;
    
    public ModelAdapterAxolotl() {
        super(bfn.f, "axolotl", 0.5f);
    }
    
    public fcb makeModel() {
        return (fcb)new faj(bakeModelLayer(fed.e));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof faj)) {
            return null;
        }
        final faj modelAxolotl = (faj)model;
        final Map<String, Integer> mapParts = getMapPartFields();
        if (mapParts.containsKey(modelPart)) {
            final int index = mapParts.get(modelPart);
            return (fee)Reflector.getFieldValue(modelAxolotl, Reflector.ModelAxolotl_ModelRenderers, index);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return getMapPartFields().keySet().toArray(new String[0]);
    }
    
    private static Map<String, Integer> getMapPartFields() {
        if (ModelAdapterAxolotl.mapPartFields != null) {
            return ModelAdapterAxolotl.mapPartFields;
        }
        (ModelAdapterAxolotl.mapPartFields = new LinkedHashMap<String, Integer>()).put("tail", 0);
        ModelAdapterAxolotl.mapPartFields.put("leg2", 1);
        ModelAdapterAxolotl.mapPartFields.put("leg1", 2);
        ModelAdapterAxolotl.mapPartFields.put("leg4", 3);
        ModelAdapterAxolotl.mapPartFields.put("leg3", 4);
        ModelAdapterAxolotl.mapPartFields.put("body", 5);
        ModelAdapterAxolotl.mapPartFields.put("head", 6);
        ModelAdapterAxolotl.mapPartFields.put("top_gills", 7);
        ModelAdapterAxolotl.mapPartFields.put("left_gills", 8);
        ModelAdapterAxolotl.mapPartFields.put("right_gills", 9);
        return ModelAdapterAxolotl.mapPartFields;
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fnz render = new fnz(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
    
    static {
        ModelAdapterAxolotl.mapPartFields = null;
    }
}
