// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;

public class ModelAdapterShulker extends ModelAdapter
{
    public ModelAdapterShulker() {
        super(bfn.aG, "shulker", 0.0f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fcy(ModelAdapter.bakeModelLayer(fed.be));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fcy)) {
            return null;
        }
        final fcy modelShulker = (fcy)model;
        if (modelPart.equals("base")) {
            return (fee)Reflector.ModelShulker_ModelRenderers.getValue(modelShulker, 0);
        }
        if (modelPart.equals("lid")) {
            return (fee)Reflector.ModelShulker_ModelRenderers.getValue(modelShulker, 1);
        }
        if (modelPart.equals("head")) {
            return (fee)Reflector.ModelShulker_ModelRenderers.getValue(modelShulker, 2);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "base", "lid", "head" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqx render = new fqx(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
