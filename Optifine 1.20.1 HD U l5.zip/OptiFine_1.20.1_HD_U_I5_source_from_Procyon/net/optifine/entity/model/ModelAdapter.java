// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.List;
import java.util.ArrayList;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.entity.EntityType;
import net.optifine.util.Either;

public abstract class ModelAdapter
{
    private Either<bfn, czp> type;
    private String name;
    private float shadowSize;
    private String[] aliases;
    
    public ModelAdapter(final bfn entityType, final String name, final float shadowSize) {
        this((Either<EntityType, BlockEntityType>)Either.makeLeft(entityType), name, shadowSize, (String[])null);
    }
    
    public ModelAdapter(final bfn entityType, final String name, final float shadowSize, final String[] aliases) {
        this((Either<EntityType, BlockEntityType>)Either.makeLeft(entityType), name, shadowSize, aliases);
    }
    
    public ModelAdapter(final czp tileEntityType, final String name, final float shadowSize) {
        this((Either<EntityType, BlockEntityType>)Either.makeRight(tileEntityType), name, shadowSize, (String[])null);
    }
    
    public ModelAdapter(final czp tileEntityType, final String name, final float shadowSize, final String[] aliases) {
        this((Either<EntityType, BlockEntityType>)Either.makeRight(tileEntityType), name, shadowSize, aliases);
    }
    
    public ModelAdapter(final Either<bfn, czp> type, final String name, final float shadowSize, final String[] aliases) {
        this.type = (Either<EntityType, BlockEntityType>)type;
        this.name = name;
        this.shadowSize = shadowSize;
        this.aliases = aliases;
    }
    
    public Either<bfn, czp> getType() {
        return (Either<bfn, czp>)this.type;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String[] getAliases() {
        return this.aliases;
    }
    
    public float getShadowSize() {
        return this.shadowSize;
    }
    
    public abstract fcb makeModel();
    
    public abstract fee getModelRenderer(final fcb p0, final String p1);
    
    public abstract String[] getModelRendererNames();
    
    public abstract IEntityRenderer makeEntityRender(final fcb p0, final float p1, final RendererCache p2, final int p3);
    
    public boolean setTextureLocation(final IEntityRenderer er, final acq textureLocation) {
        return false;
    }
    
    public fee[] getModelRenderers(final fcb model) {
        final String[] names = this.getModelRendererNames();
        final List<fee> list = new ArrayList<fee>();
        for (int i = 0; i < names.length; ++i) {
            final String name = names[i];
            final fee mr = this.getModelRenderer(model, name);
            if (mr != null) {
                list.add(mr);
            }
        }
        final fee[] mrs = list.toArray(new fee[list.size()]);
        return mrs;
    }
    
    public static fee bakeModelLayer(final fec loc) {
        return enn.N().an().getContext().a(loc);
    }
}
