// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.Iterator;
import java.util.List;
import net.optifine.Config;

public class ModelAdapterPigSaddle extends ModelAdapterQuadruped
{
    public ModelAdapterPigSaddle() {
        super(bfn.av, "pig_saddle", 0.7f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fch(ModelAdapter.bakeModelLayer(fed.aK));
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqm customRenderer = new fqm(renderManager.getContext());
        customRenderer.f = (fbf)new fch(ModelAdapter.bakeModelLayer(fed.aK));
        customRenderer.d = 0.7f;
        final fox render = rendererCache.get(bfn.av, index, () -> customRenderer);
        if (!(render instanceof fqm)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, render));
            return null;
        }
        final fqm renderPig = (fqm)render;
        final fth layer = new fth((fqt)renderPig, (fbf)modelBase, new acq("textures/entity/pig/pig_saddle.png"));
        renderPig.removeLayers((Class)fth.class);
        renderPig.a((ftg)layer);
        return (IEntityRenderer)renderPig;
    }
    
    @Override
    public boolean setTextureLocation(final IEntityRenderer er, final acq textureLocation) {
        final fqm renderer = (fqm)er;
        final List<fth> layers = (List<fth>)renderer.getLayers((Class)fth.class);
        for (final fth layer : layers) {
            layer.a = textureLocation;
        }
        return true;
    }
}
