// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;
import java.util.function.Supplier;
import net.optifine.Config;

public class ModelAdapterBookLectern extends ModelAdapterBook
{
    public ModelAdapterBookLectern() {
        super(czp.D, "lectern_book", 0.0f);
    }
    
    public fcb makeModel() {
        return (fcb)new fao(bakeModelLayer(fed.m));
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final flt dispatcher = Config.getMinecraft().ao();
        final flu renderer = rendererCache.get(czp.D, index, (Supplier)ModelAdapterBookLectern::lambda$makeEntityRender$0);
        if (!(renderer instanceof fmf)) {
            return null;
        }
        if (!Reflector.TileEntityLecternRenderer_modelBook.exists()) {
            Config.warn("Field not found: TileEntityLecternRenderer.modelBook");
            return null;
        }
        Reflector.setFieldValue(renderer, Reflector.TileEntityLecternRenderer_modelBook, modelBase);
        return (IEntityRenderer)renderer;
    }
}
