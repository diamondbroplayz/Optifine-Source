// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.LinkedHashMap;
import net.optifine.reflect.Reflector;
import java.util.Map;

public class ModelAdapterHorse extends ModelAdapter
{
    private static Map<String, Integer> mapParts;
    private static Map<String, String> mapPartsNeck;
    private static Map<String, String> mapPartsHead;
    private static Map<String, String> mapPartsBody;
    
    public ModelAdapterHorse() {
        super(bfn.Y, "horse", 0.75f);
    }
    
    protected ModelAdapterHorse(final bfn type, final String name, final float shadowSize) {
        super(type, name, shadowSize);
    }
    
    public fcb makeModel() {
        return (fcb)new fbq(bakeModelLayer(fed.aj));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fbq)) {
            return null;
        }
        final fbq modelHorse = (fbq)model;
        if (ModelAdapterHorse.mapParts.containsKey(modelPart)) {
            final int index = ModelAdapterHorse.mapParts.get(modelPart);
            return (fee)Reflector.getFieldValue(modelHorse, Reflector.ModelHorse_ModelRenderers, index);
        }
        if (ModelAdapterHorse.mapPartsNeck.containsKey(modelPart)) {
            final fee modelNeck = this.getModelRenderer((fcb)modelHorse, "neck");
            final String name = ModelAdapterHorse.mapPartsNeck.get(modelPart);
            return modelNeck.b(name);
        }
        if (ModelAdapterHorse.mapPartsHead.containsKey(modelPart)) {
            final fee modelHead = this.getModelRenderer((fcb)modelHorse, "head");
            final String name = ModelAdapterHorse.mapPartsHead.get(modelPart);
            return modelHead.b(name);
        }
        if (ModelAdapterHorse.mapPartsBody.containsKey(modelPart)) {
            final fee modelBody = this.getModelRenderer((fcb)modelHorse, "body");
            final String name = ModelAdapterHorse.mapPartsBody.get(modelPart);
            return modelBody.b(name);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body", "neck", "back_left_leg", "back_right_leg", "front_left_leg", "front_right_leg", "child_back_left_leg", "child_back_right_leg", "child_front_left_leg", "child_front_right_leg", "tail", "saddle", "head", "mane", "mouth", "left_ear", "right_ear", "left_bit", "right_bit", "left_rein", "right_rein", "headpiece", "noseband" };
    }
    
    private static Map<String, Integer> makeMapParts() {
        final Map<String, Integer> map = new LinkedHashMap<String, Integer>();
        map.put("body", 0);
        map.put("neck", 1);
        map.put("back_right_leg", 2);
        map.put("back_left_leg", 3);
        map.put("front_right_leg", 4);
        map.put("front_left_leg", 5);
        map.put("child_back_right_leg", 6);
        map.put("child_back_left_leg", 7);
        map.put("child_front_right_leg", 8);
        map.put("child_front_left_leg", 9);
        return map;
    }
    
    private static Map<String, String> makeMapPartsNeck() {
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("head", "head");
        map.put("mane", "mane");
        map.put("mouth", "upper_mouth");
        map.put("left_bit", "left_saddle_mouth");
        map.put("right_bit", "right_saddle_mouth");
        map.put("left_rein", "left_saddle_line");
        map.put("right_rein", "right_saddle_line");
        map.put("headpiece", "head_saddle");
        map.put("noseband", "mouth_saddle_wrap");
        return map;
    }
    
    private static Map<String, String> makeMapPartsBody() {
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("tail", "tail");
        map.put("saddle", "saddle");
        return map;
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fpo render = new fpo(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
    
    private static Map<String, String> makeMapPartsHead() {
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("left_ear", "left_ear");
        map.put("right_ear", "right_ear");
        return map;
    }
    
    static {
        ModelAdapterHorse.mapParts = makeMapParts();
        ModelAdapterHorse.mapPartsNeck = makeMapPartsNeck();
        ModelAdapterHorse.mapPartsHead = makeMapPartsHead();
        ModelAdapterHorse.mapPartsBody = makeMapPartsBody();
    }
}
