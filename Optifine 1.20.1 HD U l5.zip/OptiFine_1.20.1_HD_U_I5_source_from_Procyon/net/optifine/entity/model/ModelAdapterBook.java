// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.function.Supplier;
import net.optifine.Config;
import net.optifine.reflect.Reflector;

public class ModelAdapterBook extends ModelAdapter
{
    public ModelAdapterBook() {
        super(czp.m, "enchanting_book", 0.0f, new String[] { "book" });
    }
    
    protected ModelAdapterBook(final czp tileEntityType, final String name, final float shadowSize) {
        super(tileEntityType, name, shadowSize);
    }
    
    public fcb makeModel() {
        return (fcb)new fao(bakeModelLayer(fed.m));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fao)) {
            return null;
        }
        final fao modelBook = (fao)model;
        final fee root = (fee)Reflector.ModelBook_root.getValue(modelBook);
        if (root != null) {
            if (modelPart.equals("cover_right")) {
                return root.getChildModelDeep("left_lid");
            }
            if (modelPart.equals("cover_left")) {
                return root.getChildModelDeep("right_lid");
            }
            if (modelPart.equals("pages_right")) {
                return root.getChildModelDeep("left_pages");
            }
            if (modelPart.equals("pages_left")) {
                return root.getChildModelDeep("right_pages");
            }
            if (modelPart.equals("flipping_page_right")) {
                return root.getChildModelDeep("flip_page1");
            }
            if (modelPart.equals("flipping_page_left")) {
                return root.getChildModelDeep("flip_page2");
            }
            if (modelPart.equals("book_spine")) {
                return root.getChildModelDeep("seam");
            }
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "cover_right", "cover_left", "pages_right", "pages_left", "flipping_page_right", "flipping_page_left", "book_spine" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final flt dispatcher = Config.getMinecraft().ao();
        final flu renderer = rendererCache.get(czp.m, index, (Supplier)ModelAdapterBook::lambda$makeEntityRender$0);
        if (!(renderer instanceof fmd)) {
            return null;
        }
        if (!Reflector.TileEntityEnchantmentTableRenderer_modelBook.exists()) {
            Config.warn("Field not found: TileEntityEnchantmentTableRenderer.modelBook");
            return null;
        }
        Reflector.setFieldValue(renderer, Reflector.TileEntityEnchantmentTableRenderer_modelBook, modelBase);
        return (IEntityRenderer)renderer;
    }
}
