// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import com.google.common.collect.ImmutableList;

public class ModelAdapterRaft extends ModelAdapter
{
    public ModelAdapterRaft() {
        super(bfn.k, "raft", 0.5f);
    }
    
    protected ModelAdapterRaft(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fcr(ModelAdapter.bakeModelLayer(fed.c(cah.b.i)));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fcr)) {
            return null;
        }
        final fcr modelRaft = (fcr)model;
        final ImmutableList<fee> parts = (ImmutableList<fee>)modelRaft.c();
        if (parts != null) {
            if (modelPart.equals("bottom")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 0);
            }
            if (modelPart.equals("paddle_left")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 1);
            }
            if (modelPart.equals("paddle_right")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 2);
            }
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "bottom", "paddle_left", "paddle_right" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fod customRenderer = new fod(renderManager.getContext(), false);
        final fox rendererCached = rendererCache.get(bfn.k, index, () -> customRenderer);
        if (!(rendererCached instanceof fod)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, rendererCached));
            return null;
        }
        final fod renderer = (fod)rendererCached;
        return ModelAdapterBoat.makeEntityRender(modelBase, shadowSize, renderer);
    }
}
