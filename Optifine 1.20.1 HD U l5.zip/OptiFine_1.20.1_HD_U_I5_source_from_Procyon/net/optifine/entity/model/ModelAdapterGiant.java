// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterGiant extends ModelAdapterZombie
{
    public ModelAdapterGiant() {
        super(bfn.R, "giant", 3.0f);
    }
    
    public fcb makeModel() {
        return (fcb)new fbk(bakeModelLayer(fed.ab));
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fpj render = new fpj(renderManager.getContext(), 6.0f);
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
