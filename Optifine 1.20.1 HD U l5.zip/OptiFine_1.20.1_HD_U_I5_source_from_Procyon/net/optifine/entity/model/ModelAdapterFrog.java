// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModelAdapterFrog extends ModelAdapter
{
    private static Map<String, String> mapParts;
    
    public ModelAdapterFrog() {
        super(bfn.O, "frog", 0.3f);
    }
    
    public fcb makeModel() {
        return (fcb)new fbi(bakeModelLayer(fed.Y));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fbi)) {
            return null;
        }
        final fbi modelFrog = (fbi)model;
        if (ModelAdapterFrog.mapParts.containsKey(modelPart)) {
            final String name = ModelAdapterFrog.mapParts.get(modelPart);
            return modelFrog.a().getChildModelDeep(name);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        final String[] names = ModelAdapterFrog.mapParts.keySet().toArray(new String[0]);
        return names;
    }
    
    private static Map<String, String> makeMapParts() {
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("body", "body");
        map.put("head", "head");
        map.put("eyes", "eyes");
        map.put("tongue", "tongue");
        map.put("left_arm", "left_arm");
        map.put("right_arm", "right_arm");
        map.put("left_leg", "left_leg");
        map.put("right_leg", "right_leg");
        map.put("croaking_body", "croaking_body");
        return map;
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fph render = new fph(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
    
    static {
        ModelAdapterFrog.mapParts = makeMapParts();
    }
}
