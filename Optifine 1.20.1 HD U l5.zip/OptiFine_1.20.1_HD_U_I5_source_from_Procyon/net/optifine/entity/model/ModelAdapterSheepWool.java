// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.Iterator;
import java.util.List;
import net.optifine.Config;

public class ModelAdapterSheepWool extends ModelAdapterQuadruped
{
    public ModelAdapterSheepWool() {
        super(bfn.aF, "sheep_wool", 0.7f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fcu(ModelAdapter.bakeModelLayer(fed.bc));
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqv customRenderer = new fqv(renderManager.getContext());
        customRenderer.f = (fbf)new fcv(ModelAdapter.bakeModelLayer(fed.bc));
        customRenderer.d = 0.7f;
        final fox render = rendererCache.get(bfn.aF, index, () -> customRenderer);
        if (!(render instanceof fqv)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, render));
            return null;
        }
        final fqv renderSheep = (fqv)render;
        final fti layer = new fti((fqt)renderSheep, renderManager.getContext().f());
        layer.b = (fcu)modelBase;
        renderSheep.removeLayers((Class)fti.class);
        renderSheep.a((ftg)layer);
        return (IEntityRenderer)renderSheep;
    }
    
    @Override
    public boolean setTextureLocation(final IEntityRenderer er, final acq textureLocation) {
        final fqv renderSheep = (fqv)er;
        final List<fti> layers = (List<fti>)renderSheep.getLayers((Class)fti.class);
        for (final fti layer : layers) {
            layer.b.locationTextureCustom = textureLocation;
        }
        return true;
    }
}
