// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModelAdapterWarden extends ModelAdapter
{
    private static Map<String, String> mapParts;
    
    public ModelAdapterWarden() {
        super(bfn.bi, "warden", 0.9f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdr(ModelAdapter.bakeModelLayer(fed.bL));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdr)) {
            return null;
        }
        final fdr modelWarden = (fdr)model;
        if (ModelAdapterWarden.mapParts.containsKey(modelPart)) {
            final String name = ModelAdapterWarden.mapParts.get(modelPart);
            return modelWarden.a().getChildModelDeep(name);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        final String[] names = ModelAdapterWarden.mapParts.keySet().toArray(new String[0]);
        return names;
    }
    
    private static Map<String, String> makeMapParts() {
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("body", "bone");
        map.put("torso", "body");
        map.put("head", "head");
        map.put("right_leg", "right_leg");
        map.put("left_leg", "left_leg");
        map.put("right_arm", "right_arm");
        map.put("left_arm", "left_arm");
        map.put("right_tendril", "right_tendril");
        map.put("left_tendril", "left_tendril");
        map.put("right_ribcage", "right_ribcage");
        map.put("left_ribcage", "left_ribcage");
        return map;
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frv render = new frv(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
    
    static {
        ModelAdapterWarden.mapParts = makeMapParts();
    }
}
