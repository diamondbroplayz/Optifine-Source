// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.Map;
import java.util.function.Supplier;
import net.optifine.Config;
import net.optifine.reflect.Reflector;

public class ModelAdapterHead extends ModelAdapter
{
    private fec modelLayer;
    private cwp.b skullBlockType;
    
    public ModelAdapterHead(final String name, final fec modelLayer, final cwp.b skullBlockType) {
        super(czp.p, name, 0.0f);
        this.modelLayer = modelLayer;
        this.skullBlockType = skullBlockType;
    }
    
    public fcb makeModel() {
        return (fcb)new fdb(bakeModelLayer(this.modelLayer));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdb)) {
            return null;
        }
        final fdb modelSkul = (fdb)model;
        if (modelPart.equals("head")) {
            return (fee)Reflector.ModelSkull_head.getValue(modelSkul);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "head" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final flt dispatcher = Config.getMinecraft().ao();
        final flu renderer = rendererCache.get(czp.p, index, (Supplier)ModelAdapterHead::lambda$makeEntityRender$0);
        if (!(renderer instanceof fmj)) {
            return null;
        }
        final Map<cwp.a, fdc> models = (Map<cwp.a, fdc>)fmj.models;
        if (models == null) {
            Config.warn("Field not found: SkullBlockRenderer.models");
            return null;
        }
        models.put((cwp.a)this.skullBlockType, (fdc)modelBase);
        return (IEntityRenderer)renderer;
    }
}
