// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterSnowman extends ModelAdapter
{
    public ModelAdapterSnowman() {
        super(bfn.aO, "snow_golem", 0.5f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdf(ModelAdapter.bakeModelLayer(fed.bp));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdf)) {
            return null;
        }
        final fdf modelSnowman = (fdf)model;
        if (modelPart.equals("body")) {
            return modelSnowman.a().getChildModelDeep("upper_body");
        }
        if (modelPart.equals("body_bottom")) {
            return modelSnowman.a().getChildModelDeep("lower_body");
        }
        if (modelPart.equals("head")) {
            return modelSnowman.a().getChildModelDeep("head");
        }
        if (modelPart.equals("right_hand")) {
            return modelSnowman.a().getChildModelDeep("right_arm");
        }
        if (modelPart.equals("left_hand")) {
            return modelSnowman.a().getChildModelDeep("left_arm");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body", "body_bottom", "head", "right_hand", "left_hand" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frc render = new frc(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
