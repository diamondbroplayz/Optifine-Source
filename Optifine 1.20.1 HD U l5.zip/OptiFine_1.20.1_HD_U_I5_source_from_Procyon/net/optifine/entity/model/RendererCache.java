// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.function.Supplier;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import java.util.HashMap;
import java.util.Map;

public class RendererCache
{
    private Map<String, fox> mapEntityRenderers;
    private Map<String, flu> mapBlockEntityRenderers;
    
    public RendererCache() {
        this.mapEntityRenderers = new HashMap<String, EntityRenderer>();
        this.mapBlockEntityRenderers = new HashMap<String, BlockEntityRenderer>();
    }
    
    public fox get(final bfn type, final int index, final Supplier<fox> supplier) {
        final String key = invokedynamic(makeConcatWithConstants:(Lacq;I)Ljava/lang/String;, jb.h.b((Object)type), index);
        fox renderer = (fox)this.mapEntityRenderers.get(key);
        if (renderer == null) {
            renderer = supplier.get();
            this.mapEntityRenderers.put(key, (EntityRenderer)renderer);
        }
        return renderer;
    }
    
    public flu get(final czp type, final int index, final Supplier<flu> supplier) {
        final String key = invokedynamic(makeConcatWithConstants:(Lacq;I)Ljava/lang/String;, jb.l.b((Object)type), index);
        flu renderer = (flu)this.mapBlockEntityRenderers.get(key);
        if (renderer == null) {
            renderer = supplier.get();
            this.mapBlockEntityRenderers.put(key, (BlockEntityRenderer)renderer);
        }
        return renderer;
    }
    
    public void put(final bfn type, final int index, final fox renderer) {
        final String key = invokedynamic(makeConcatWithConstants:(Lacq;I)Ljava/lang/String;, jb.h.b((Object)type), index);
        this.mapEntityRenderers.put(key, (EntityRenderer)renderer);
    }
    
    public void put(final czp type, final int index, final flu renderer) {
        final String key = invokedynamic(makeConcatWithConstants:(Lacq;I)Ljava/lang/String;, jb.l.b((Object)type), index);
        this.mapBlockEntityRenderers.put(key, (BlockEntityRenderer)renderer);
    }
    
    public void clear() {
        this.mapEntityRenderers.clear();
        this.mapBlockEntityRenderers.clear();
    }
}
