// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;
import net.optifine.Config;
import java.util.function.Function;

public class BannerModel extends fcb
{
    public fee bannerSlate;
    public fee bannerStand;
    public fee bannerTop;
    
    public BannerModel() {
        super((Function)fkf::d);
        final flt dispatcher = Config.getMinecraft().ao();
        final flp renderer = new flp(dispatcher.getContext());
        this.bannerSlate = (fee)Reflector.TileEntityBannerRenderer_modelRenderers.getValue(renderer, 0);
        this.bannerStand = (fee)Reflector.TileEntityBannerRenderer_modelRenderers.getValue(renderer, 1);
        this.bannerTop = (fee)Reflector.TileEntityBannerRenderer_modelRenderers.getValue(renderer, 2);
    }
    
    public flu updateRenderer(final flu renderer) {
        if (!Reflector.TileEntityBannerRenderer_modelRenderers.exists()) {
            Config.warn("Field not found: TileEntityBannerRenderer.modelRenderers");
            return null;
        }
        Reflector.TileEntityBannerRenderer_modelRenderers.setValue(renderer, 0, this.bannerSlate);
        Reflector.TileEntityBannerRenderer_modelRenderers.setValue(renderer, 1, this.bannerStand);
        Reflector.TileEntityBannerRenderer_modelRenderers.setValue(renderer, 2, this.bannerTop);
        return renderer;
    }
    
    public void a(final eij matrixStackIn, final ein bufferIn, final int packedLightIn, final int packedOverlayIn, final float red, final float green, final float blue, final float alpha) {
    }
}
