// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import java.util.function.Supplier;
import net.optifine.util.ArrayUtils;
import com.google.common.collect.ImmutableList;

public class ModelAdapterChestRaft extends ModelAdapterRaft
{
    public ModelAdapterChestRaft() {
        super(bfn.o, "chest_raft", 0.5f);
    }
    
    public fcb makeModel() {
        return (fcb)new fas(bakeModelLayer(fed.d(cah.b.i)));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fas)) {
            return null;
        }
        final fas modelChestRaft = (fas)model;
        final ImmutableList<fee> parts = (ImmutableList<fee>)modelChestRaft.c();
        if (parts != null) {
            if (modelPart.equals("chest_base")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 3);
            }
            if (modelPart.equals("chest_lid")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 4);
            }
            if (modelPart.equals("chest_knob")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 5);
            }
        }
        return super.getModelRenderer((fcb)modelChestRaft, modelPart);
    }
    
    @Override
    public String[] getModelRendererNames() {
        String[] names = super.getModelRendererNames();
        names = (String[])ArrayUtils.addObjectsToArray(names, new String[] { "chest_base", "chest_lid", "chest_knob" });
        return names;
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fod customRenderer = new fod(renderManager.getContext(), true);
        final fox rendererCached = rendererCache.get(bfn.o, index, (Supplier)ModelAdapterChestRaft::lambda$makeEntityRender$0);
        if (!(rendererCached instanceof fod)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, rendererCached));
            return null;
        }
        final fod renderer = (fod)rendererCached;
        return ModelAdapterBoat.makeEntityRender(modelBase, shadowSize, renderer);
    }
}
