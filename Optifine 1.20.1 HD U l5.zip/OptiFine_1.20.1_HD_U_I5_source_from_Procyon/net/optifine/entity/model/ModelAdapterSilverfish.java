// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import net.optifine.util.StrUtils;

public class ModelAdapterSilverfish extends ModelAdapter
{
    public ModelAdapterSilverfish() {
        super(bfn.aI, "silverfish", 0.3f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fcz(ModelAdapter.bakeModelLayer(fed.bg));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fcz)) {
            return null;
        }
        final fcz modelSilverfish = (fcz)model;
        final String PREFIX_BODY = "body";
        if (modelPart.startsWith(PREFIX_BODY)) {
            final String numStr = StrUtils.removePrefix(modelPart, PREFIX_BODY);
            final int index = Config.parseInt(numStr, -1);
            final int indexPart = index - 1;
            return modelSilverfish.a().getChildModelDeep(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, indexPart));
        }
        final String PREFIX_WINGS = "wing";
        if (modelPart.startsWith(PREFIX_WINGS)) {
            final String numStr2 = StrUtils.removePrefix(modelPart, PREFIX_WINGS);
            final int index2 = Config.parseInt(numStr2, -1);
            final int indexPart2 = index2 - 1;
            return modelSilverfish.a().getChildModelDeep(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, indexPart2));
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body1", "body2", "body3", "body4", "body5", "body6", "body7", "wing1", "wing2", "wing3" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqy render = new fqy(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
