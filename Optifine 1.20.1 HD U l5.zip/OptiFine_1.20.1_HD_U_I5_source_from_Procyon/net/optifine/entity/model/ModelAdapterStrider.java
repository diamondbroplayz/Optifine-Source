// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModelAdapterStrider extends ModelAdapter
{
    private static Map<String, String> mapParts;
    
    public ModelAdapterStrider() {
        super(bfn.aV, "strider", 0.5f);
    }
    
    protected ModelAdapterStrider(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdi(ModelAdapter.bakeModelLayer(fed.bx));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdi)) {
            return null;
        }
        final fdi modelStrider = (fdi)model;
        if (ModelAdapterStrider.mapParts.containsKey(modelPart)) {
            final String name = ModelAdapterStrider.mapParts.get(modelPart);
            return modelStrider.a().getChildModelDeep(name);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        final String[] names = ModelAdapterStrider.mapParts.keySet().toArray(new String[0]);
        return names;
    }
    
    private static Map<String, String> makeMapParts() {
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("right_leg", "right_leg");
        map.put("left_leg", "left_leg");
        map.put("body", "body");
        map.put("hair_right_bottom", "right_bottom_bristle");
        map.put("hair_right_middle", "right_middle_bristle");
        map.put("hair_right_top", "right_top_bristle");
        map.put("hair_left_top", "left_top_bristle");
        map.put("hair_left_middle", "left_middle_bristle");
        map.put("hair_left_bottom", "left_bottom_bristle");
        return map;
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frh render = new frh(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
    
    static {
        ModelAdapterStrider.mapParts = makeMapParts();
    }
}
