// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.LinkedHashMap;
import net.optifine.reflect.Reflector;
import java.util.Map;

public class ModelAdapterHoglin extends ModelAdapter
{
    private static Map<String, Integer> mapParts;
    
    public ModelAdapterHoglin() {
        super(bfn.W, "hoglin", 0.7f);
    }
    
    public ModelAdapterHoglin(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    public fcb makeModel() {
        return (fcb)new fbp(bakeModelLayer(fed.ah));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fbp)) {
            return null;
        }
        final fbp modelBoar = (fbp)model;
        if (ModelAdapterHoglin.mapParts.containsKey(modelPart)) {
            final int index = ModelAdapterHoglin.mapParts.get(modelPart);
            return (fee)Reflector.getFieldValue(modelBoar, Reflector.ModelBoar_ModelRenderers, index);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        final String[] names = ModelAdapterHoglin.mapParts.keySet().toArray(new String[0]);
        return names;
    }
    
    private static Map<String, Integer> makeMapParts() {
        final Map<String, Integer> map = new LinkedHashMap<String, Integer>();
        map.put("head", 0);
        map.put("right_ear", 1);
        map.put("left_ear", 2);
        map.put("body", 3);
        map.put("front_right_leg", 4);
        map.put("front_left_leg", 5);
        map.put("back_right_leg", 6);
        map.put("back_left_leg", 7);
        map.put("mane", 8);
        return map;
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fpn render = new fpn(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
    
    static {
        ModelAdapterHoglin.mapParts = makeMapParts();
    }
}
