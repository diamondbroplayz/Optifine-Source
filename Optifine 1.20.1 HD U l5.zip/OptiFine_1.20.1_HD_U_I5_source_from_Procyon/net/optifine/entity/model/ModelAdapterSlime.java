// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterSlime extends ModelAdapter
{
    public ModelAdapterSlime() {
        super(bfn.aL, "slime", 0.25f);
    }
    
    public ModelAdapterSlime(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdd(ModelAdapter.bakeModelLayer(fed.bm));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdd)) {
            return null;
        }
        final fdd modelSlime = (fdd)model;
        if (modelPart.equals("body")) {
            return modelSlime.a().getChildModelDeep("cube");
        }
        if (modelPart.equals("left_eye")) {
            return modelSlime.a().getChildModelDeep("left_eye");
        }
        if (modelPart.equals("right_eye")) {
            return modelSlime.a().getChildModelDeep("right_eye");
        }
        if (modelPart.equals("mouth")) {
            return modelSlime.a().getChildModelDeep("mouth");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body", "left_eye", "right_eye", "mouth" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fra render = new fra(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
