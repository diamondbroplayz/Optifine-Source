// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;

public class ModelAdapterTrappedChestLarge extends ModelAdapter
{
    public ModelAdapterTrappedChestLarge() {
        super(czp.c, "trapped_chest_large", 0.0f);
    }
    
    @Override
    public fcb makeModel() {
        return new ChestLargeModel();
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof ChestLargeModel)) {
            return null;
        }
        final ChestLargeModel modelChest = (ChestLargeModel)model;
        if (modelPart.equals("lid_left")) {
            return modelChest.lid_left;
        }
        if (modelPart.equals("base_left")) {
            return modelChest.base_left;
        }
        if (modelPart.equals("knob_left")) {
            return modelChest.knob_left;
        }
        if (modelPart.equals("lid_right")) {
            return modelChest.lid_right;
        }
        if (modelPart.equals("base_right")) {
            return modelChest.base_right;
        }
        if (modelPart.equals("knob_right")) {
            return modelChest.knob_right;
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "lid_left", "base_left", "knob_left", "lid_right", "base_right", "knob_right" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final flt dispatcher = Config.getMinecraft().ao();
        flu renderer = rendererCache.get(czp.c, index, () -> new fma(dispatcher.getContext()));
        if (!(renderer instanceof fma)) {
            return null;
        }
        if (!(modelBase instanceof ChestLargeModel)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfcb;)Ljava/lang/String;, modelBase));
            return null;
        }
        final ChestLargeModel chestModel = (ChestLargeModel)modelBase;
        renderer = chestModel.updateRenderer(renderer);
        return (IEntityRenderer)renderer;
    }
}
