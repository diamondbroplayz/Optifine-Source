// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.Iterator;
import java.util.List;
import net.optifine.reflect.Reflector;
import net.optifine.Config;
import java.util.function.Supplier;

public class ModelAdapterLlamaDecor extends ModelAdapterLlama
{
    public ModelAdapterLlamaDecor() {
        super(bfn.aj, "llama_decor", 0.7f);
    }
    
    protected ModelAdapterLlamaDecor(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    public fcb makeModel() {
        return (fcb)new fby(bakeModelLayer(fed.as));
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqa customRenderer = new fqa(renderManager.getContext(), fed.as);
        customRenderer.f = (fbf)new fby(bakeModelLayer(fed.as));
        customRenderer.d = 0.7f;
        final bfn entityType = (bfn)this.getType().getLeft().get();
        final fox render = rendererCache.get(entityType, index, (Supplier)ModelAdapterLlamaDecor::lambda$makeEntityRender$0);
        if (!(render instanceof fqa)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, render));
            return null;
        }
        final fqa renderLlama = (fqa)render;
        final fta layer = new fta((fqt)renderLlama, renderManager.getContext().f());
        if (!Reflector.LayerLlamaDecor_model.exists()) {
            Config.warn("Field not found: LayerLlamaDecor.model");
            return null;
        }
        Reflector.LayerLlamaDecor_model.setValue(layer, modelBase);
        renderLlama.removeLayers((Class)fta.class);
        renderLlama.a((ftg)layer);
        return (IEntityRenderer)renderLlama;
    }
    
    public boolean setTextureLocation(final IEntityRenderer er, final acq textureLocation) {
        final fqa llamaRenderer = (fqa)er;
        final List<fta> layers = (List<fta>)llamaRenderer.getLayers((Class)fta.class);
        for (final ftg layer : layers) {
            final fcb model = (fcb)Reflector.LayerLlamaDecor_model.getValue(layer);
            if (model != null) {
                model.locationTextureCustom = textureLocation;
            }
        }
        return true;
    }
}
