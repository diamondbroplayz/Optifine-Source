// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterPiglinBrute extends ModelAdapterPiglin
{
    public ModelAdapterPiglinBrute() {
        super(bfn.ax, "piglin_brute", 0.5f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fcj(ModelAdapter.bakeModelLayer(fed.aE));
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqn render = new fqn(renderManager.getContext(), fed.aE, fed.aF, fed.aG, false);
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
