// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterDrowned extends ModelAdapterZombie
{
    public ModelAdapterDrowned() {
        super(bfn.y, "drowned", 0.5f);
    }
    
    public ModelAdapterDrowned(final bfn type, final String name, final float shadowSize) {
        super(type, name, shadowSize);
    }
    
    public fcb makeModel() {
        return (fcb)new fbb(bakeModelLayer(fed.L));
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fop render = new fop(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
