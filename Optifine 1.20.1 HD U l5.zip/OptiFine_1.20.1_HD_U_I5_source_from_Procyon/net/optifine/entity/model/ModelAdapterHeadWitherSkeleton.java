// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterHeadWitherSkeleton extends ModelAdapterHead
{
    public ModelAdapterHeadWitherSkeleton() {
        super("head_wither_skeleton", fed.bT, cwp.b.b);
    }
}
