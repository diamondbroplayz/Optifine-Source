// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import net.optifine.util.StrUtils;

public class ModelAdapterEndermite extends ModelAdapter
{
    public ModelAdapterEndermite() {
        super(bfn.F, "endermite", 0.3f);
    }
    
    public fcb makeModel() {
        return (fcb)new fbe(bakeModelLayer(fed.S));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fbe)) {
            return null;
        }
        final fbe modelEnderMite = (fbe)model;
        final String PREFIX_BODY = "body";
        if (modelPart.startsWith(PREFIX_BODY)) {
            final String numStr = StrUtils.removePrefix(modelPart, PREFIX_BODY);
            final int index = Config.parseInt(numStr, -1);
            final int indexPart = index - 1;
            return modelEnderMite.a().getChildModelDeep(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, indexPart));
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body1", "body2", "body3", "body4" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fov render = new fov(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
