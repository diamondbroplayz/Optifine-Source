// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;
import net.optifine.Config;
import java.util.function.Function;

public class ChestModel extends fcb
{
    public fee lid;
    public fee base;
    public fee knob;
    
    public ChestModel() {
        super((Function)fkf::c);
        final flt dispatcher = Config.getMinecraft().ao();
        final fma renderer = new fma(dispatcher.getContext());
        this.lid = (fee)Reflector.TileEntityChestRenderer_modelRenderers.getValue(renderer, 0);
        this.base = (fee)Reflector.TileEntityChestRenderer_modelRenderers.getValue(renderer, 1);
        this.knob = (fee)Reflector.TileEntityChestRenderer_modelRenderers.getValue(renderer, 2);
    }
    
    public flu updateRenderer(final flu renderer) {
        if (!Reflector.TileEntityChestRenderer_modelRenderers.exists()) {
            Config.warn("Field not found: TileEntityChestRenderer.modelRenderers");
            return null;
        }
        Reflector.TileEntityChestRenderer_modelRenderers.setValue(renderer, 0, this.lid);
        Reflector.TileEntityChestRenderer_modelRenderers.setValue(renderer, 1, this.base);
        Reflector.TileEntityChestRenderer_modelRenderers.setValue(renderer, 2, this.knob);
        return renderer;
    }
    
    public void a(final eij matrixStackIn, final ein bufferIn, final int packedLightIn, final int packedOverlayIn, final float red, final float green, final float blue, final float alpha) {
    }
}
