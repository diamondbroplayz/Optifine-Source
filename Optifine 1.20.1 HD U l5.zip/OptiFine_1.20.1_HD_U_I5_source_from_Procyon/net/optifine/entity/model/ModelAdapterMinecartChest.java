// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterMinecartChest extends ModelAdapterMinecart
{
    public ModelAdapterMinecartChest() {
        super(bfn.p, "chest_minecart", 0.5f);
    }
}
