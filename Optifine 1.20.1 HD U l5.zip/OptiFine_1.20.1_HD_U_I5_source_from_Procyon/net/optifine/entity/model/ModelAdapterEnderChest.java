// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.function.Supplier;
import net.optifine.Config;

public class ModelAdapterEnderChest extends ModelAdapter
{
    public ModelAdapterEnderChest() {
        super(czp.d, "ender_chest", 0.0f);
    }
    
    public fcb makeModel() {
        return new ChestModel();
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof ChestModel)) {
            return null;
        }
        final ChestModel modelChest = (ChestModel)model;
        if (modelPart.equals("lid")) {
            return modelChest.lid;
        }
        if (modelPart.equals("base")) {
            return modelChest.base;
        }
        if (modelPart.equals("knob")) {
            return modelChest.knob;
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "lid", "base", "knob" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final flt dispatcher = Config.getMinecraft().ao();
        flu renderer = rendererCache.get(czp.d, index, (Supplier)ModelAdapterEnderChest::lambda$makeEntityRender$0);
        if (!(renderer instanceof fma)) {
            return null;
        }
        if (!(modelBase instanceof ChestModel)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfcb;)Ljava/lang/String;, modelBase));
            return null;
        }
        final ChestModel chestModel = (ChestModel)modelBase;
        renderer = chestModel.updateRenderer(renderer);
        return (IEntityRenderer)renderer;
    }
}
