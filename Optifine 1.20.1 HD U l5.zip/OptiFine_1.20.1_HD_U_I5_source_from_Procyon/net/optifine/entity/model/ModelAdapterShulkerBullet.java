// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import net.optifine.reflect.Reflector;

public class ModelAdapterShulkerBullet extends ModelAdapter
{
    public ModelAdapterShulkerBullet() {
        super(bfn.aH, "shulker_bullet", 0.0f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fcx(ModelAdapter.bakeModelLayer(fed.bf));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fcx)) {
            return null;
        }
        final fcx modelShulkerBullet = (fcx)model;
        if (modelPart.equals("bullet")) {
            return modelShulkerBullet.a().getChildModelDeep("main");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "bullet" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqw render = new fqw(renderManager.getContext());
        if (!Reflector.RenderShulkerBullet_model.exists()) {
            Config.warn("Field not found: RenderShulkerBullet.model");
            return null;
        }
        Reflector.setFieldValue(render, Reflector.RenderShulkerBullet_model, modelBase);
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
