// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import net.optifine.reflect.Reflector;

public class ModelAdapterTurtle extends ModelAdapterQuadruped
{
    public ModelAdapterTurtle() {
        super(bfn.bd, "turtle", 0.7f);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdn(ModelAdapter.bakeModelLayer(fed.bH));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fcp)) {
            return null;
        }
        final fdn modelQuadruped = (fdn)model;
        if (modelPart.equals("body2")) {
            return (fee)Reflector.ModelTurtle_body2.getValue(modelQuadruped);
        }
        return super.getModelRenderer(model, modelPart);
    }
    
    @Override
    public String[] getModelRendererNames() {
        String[] names = super.getModelRendererNames();
        names = (String[])Config.addObjectToArray(names, "body2");
        return names;
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frp render = new frp(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
