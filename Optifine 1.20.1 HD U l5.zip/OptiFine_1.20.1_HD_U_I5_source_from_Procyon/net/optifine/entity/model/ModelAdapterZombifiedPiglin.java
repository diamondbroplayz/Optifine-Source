// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterZombifiedPiglin extends ModelAdapterPiglin
{
    public ModelAdapterZombifiedPiglin() {
        super(bfn.bs, "zombified_piglin", 0.5f);
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqn render = new fqn(renderManager.getContext(), fed.cf, fed.cg, fed.ch, true);
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
