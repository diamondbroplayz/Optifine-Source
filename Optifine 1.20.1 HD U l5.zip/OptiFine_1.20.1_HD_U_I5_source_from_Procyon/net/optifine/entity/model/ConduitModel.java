// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;
import net.optifine.Config;
import java.util.function.Function;

public class ConduitModel extends fcb
{
    public fee eye;
    public fee wind;
    public fee base;
    public fee cage;
    
    public ConduitModel() {
        super((Function)fkf::c);
        final flt dispatcher = Config.getMinecraft().ao();
        final fmb renderer = new fmb(dispatcher.getContext());
        this.eye = (fee)Reflector.TileEntityConduitRenderer_modelRenderers.getValue(renderer, 0);
        this.wind = (fee)Reflector.TileEntityConduitRenderer_modelRenderers.getValue(renderer, 1);
        this.base = (fee)Reflector.TileEntityConduitRenderer_modelRenderers.getValue(renderer, 2);
        this.cage = (fee)Reflector.TileEntityConduitRenderer_modelRenderers.getValue(renderer, 3);
    }
    
    public flu updateRenderer(final flu renderer) {
        if (!Reflector.TileEntityConduitRenderer_modelRenderers.exists()) {
            Config.warn("Field not found: TileEntityConduitRenderer.modelRenderers");
            return null;
        }
        Reflector.TileEntityConduitRenderer_modelRenderers.setValue(renderer, 0, this.eye);
        Reflector.TileEntityConduitRenderer_modelRenderers.setValue(renderer, 1, this.wind);
        Reflector.TileEntityConduitRenderer_modelRenderers.setValue(renderer, 2, this.base);
        Reflector.TileEntityConduitRenderer_modelRenderers.setValue(renderer, 3, this.cage);
        return renderer;
    }
    
    public void a(final eij matrixStackIn, final ein bufferIn, final int packedLightIn, final int packedOverlayIn, final float red, final float green, final float blue, final float alpha) {
    }
}
