// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;
import net.optifine.Config;

public class ModelAdapterTropicalFishA extends ModelAdapter
{
    public ModelAdapterTropicalFishA() {
        super(bfn.bc, "tropical_fish_a", 0.2f);
    }
    
    public ModelAdapterTropicalFishA(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdl(ModelAdapter.bakeModelLayer(fed.bF));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdl)) {
            return null;
        }
        final fdl modelTropicalFish = (fdl)model;
        if (modelPart.equals("body")) {
            return modelTropicalFish.a().getChildModelDeep("body");
        }
        if (modelPart.equals("tail")) {
            return modelTropicalFish.a().getChildModelDeep("tail");
        }
        if (modelPart.equals("fin_right")) {
            return modelTropicalFish.a().getChildModelDeep("right_fin");
        }
        if (modelPart.equals("fin_left")) {
            return modelTropicalFish.a().getChildModelDeep("left_fin");
        }
        if (modelPart.equals("fin_top")) {
            return modelTropicalFish.a().getChildModelDeep("top_fin");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body", "tail", "fin_right", "fin_left", "fin_top" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fro customRenderer = new fro(renderManager.getContext());
        customRenderer.d = shadowSize;
        final fox render = rendererCache.get(bfn.bc, index, () -> customRenderer);
        if (!(render instanceof fro)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfox;)Ljava/lang/String;, render));
            return null;
        }
        final fro renderFish = (fro)render;
        if (!Reflector.RenderTropicalFish_modelA.exists()) {
            Config.warn("Model field not found: RenderTropicalFish.modelA");
            return null;
        }
        Reflector.RenderTropicalFish_modelA.setValue(renderFish, modelBase);
        return (IEntityRenderer)renderFish;
    }
}
