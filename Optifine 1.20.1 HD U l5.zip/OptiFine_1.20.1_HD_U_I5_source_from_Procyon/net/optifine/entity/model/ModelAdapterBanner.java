// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.function.Supplier;
import net.optifine.Config;

public class ModelAdapterBanner extends ModelAdapter
{
    public ModelAdapterBanner() {
        super(czp.t, "banner", 0.0f);
    }
    
    public fcb makeModel() {
        return new BannerModel();
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof BannerModel)) {
            return null;
        }
        final BannerModel modelBanner = (BannerModel)model;
        if (modelPart.equals("slate")) {
            return modelBanner.bannerSlate;
        }
        if (modelPart.equals("stand")) {
            return modelBanner.bannerStand;
        }
        if (modelPart.equals("top")) {
            return modelBanner.bannerTop;
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "slate", "stand", "top" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb model, final float shadowSize, final RendererCache rendererCache, final int index) {
        final flt dispatcher = Config.getMinecraft().ao();
        flu renderer = rendererCache.get(czp.t, index, (Supplier)ModelAdapterBanner::lambda$makeEntityRender$0);
        if (!(renderer instanceof flp)) {
            return null;
        }
        if (!(model instanceof BannerModel)) {
            Config.warn(invokedynamic(makeConcatWithConstants:(Lfcb;)Ljava/lang/String;, model));
            return null;
        }
        final BannerModel bannerModel = (BannerModel)model;
        renderer = bannerModel.updateRenderer(renderer);
        return (IEntityRenderer)renderer;
    }
}
