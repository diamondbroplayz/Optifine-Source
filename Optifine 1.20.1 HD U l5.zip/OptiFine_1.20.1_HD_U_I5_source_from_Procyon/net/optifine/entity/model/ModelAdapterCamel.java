// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModelAdapterCamel extends ModelAdapter
{
    private static Map<String, String> mapParts;
    
    public ModelAdapterCamel() {
        super(bfn.l, "camel", 0.7f);
    }
    
    public fcb makeModel() {
        return (fcb)new fap(bakeModelLayer(fed.p));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fap)) {
            return null;
        }
        final fap modelCamel = (fap)model;
        if (ModelAdapterCamel.mapParts.containsKey(modelPart)) {
            final String name = ModelAdapterCamel.mapParts.get(modelPart);
            return modelCamel.a().getChildModelDeep(name);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        final String[] names = ModelAdapterCamel.mapParts.keySet().toArray(new String[0]);
        return names;
    }
    
    private static Map<String, String> makeMapParts() {
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("body", "body");
        map.put("hump", "hump");
        map.put("tail", "tail");
        map.put("head", "head");
        map.put("left_ear", "left_ear");
        map.put("right_ear", "right_ear");
        map.put("back_left_leg", "left_hind_leg");
        map.put("back_right_leg", "right_hind_leg");
        map.put("front_left_leg", "left_front_leg");
        map.put("front_right_leg", "right_front_leg");
        map.put("saddle", "saddle");
        map.put("reins", "reins");
        map.put("bridle", "bridle");
        return map;
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final foe render = new foe(renderManager.getContext(), fed.p);
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
    
    static {
        ModelAdapterCamel.mapParts = makeMapParts();
    }
}
