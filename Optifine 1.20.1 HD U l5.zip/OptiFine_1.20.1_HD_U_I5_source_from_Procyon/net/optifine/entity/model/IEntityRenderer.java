// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.util.Either;

public interface IEntityRenderer
{
    Either<bfn, czp> getType();
    
    void setType(final Either<bfn, czp> p0);
    
    acq getLocationTextureCustom();
    
    void setLocationTextureCustom(final acq p0);
}
