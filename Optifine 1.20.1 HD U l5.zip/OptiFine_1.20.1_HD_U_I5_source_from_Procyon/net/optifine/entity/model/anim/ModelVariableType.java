// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model.anim;

import net.optifine.Config;
import net.optifine.expr.ExpressionType;

public enum ModelVariableType
{
    POS_X("tx"), 
    POS_Y("ty"), 
    POS_Z("tz"), 
    ANGLE_X("rx"), 
    ANGLE_Y("ry"), 
    ANGLE_Z("rz"), 
    SCALE_X("sx"), 
    SCALE_Y("sy"), 
    SCALE_Z("sz"), 
    VISIBLE("visible", ExpressionType.BOOL), 
    VISIBLE_BOXES("visible_boxes", ExpressionType.BOOL);
    
    private String name;
    private ExpressionType type;
    public static ModelVariableType[] VALUES;
    
    private ModelVariableType(final String name) {
        this(name, ExpressionType.FLOAT);
    }
    
    private ModelVariableType(final String name, final ExpressionType type) {
        this.name = name;
        this.type = type;
    }
    
    public String getName() {
        return this.name;
    }
    
    public ExpressionType getType() {
        return this.type;
    }
    
    public float getFloat(final fee mr) {
        switch (ModelVariableType.ModelVariableType$1.$SwitchMap$net$optifine$entity$model$anim$ModelVariableType[this.ordinal()]) {
            case 1: {
                return mr.b;
            }
            case 2: {
                return mr.c;
            }
            case 3: {
                return mr.d;
            }
            case 4: {
                return mr.e;
            }
            case 5: {
                return mr.f;
            }
            case 6: {
                return mr.g;
            }
            case 7: {
                return mr.h;
            }
            case 8: {
                return mr.i;
            }
            case 9: {
                return mr.j;
            }
            default: {
                Config.warn(invokedynamic(makeConcatWithConstants:(Lnet/optifine/entity/model/anim/ModelVariableType;)Ljava/lang/String;, this));
                return 0.0f;
            }
        }
    }
    
    public void setFloat(final fee mr, final float val) {
        switch (ModelVariableType.ModelVariableType$1.$SwitchMap$net$optifine$entity$model$anim$ModelVariableType[this.ordinal()]) {
            case 1: {
                mr.b = val;
            }
            case 2: {
                mr.c = val;
            }
            case 3: {
                mr.d = val;
            }
            case 4: {
                mr.e = val;
            }
            case 5: {
                mr.f = val;
            }
            case 6: {
                mr.g = val;
            }
            case 7: {
                mr.h = val;
            }
            case 8: {
                mr.i = val;
            }
            case 9: {
                mr.j = val;
            }
            default: {
                Config.warn(invokedynamic(makeConcatWithConstants:(Lnet/optifine/entity/model/anim/ModelVariableType;)Ljava/lang/String;, this));
            }
        }
    }
    
    public boolean getBool(final fee mr) {
        switch (ModelVariableType.ModelVariableType$1.$SwitchMap$net$optifine$entity$model$anim$ModelVariableType[this.ordinal()]) {
            case 10: {
                return mr.k;
            }
            case 11: {
                return !mr.l;
            }
            default: {
                Config.warn(invokedynamic(makeConcatWithConstants:(Lnet/optifine/entity/model/anim/ModelVariableType;)Ljava/lang/String;, this));
                return false;
            }
        }
    }
    
    public void setBool(final fee mr, final boolean val) {
        switch (ModelVariableType.ModelVariableType$1.$SwitchMap$net$optifine$entity$model$anim$ModelVariableType[this.ordinal()]) {
            case 10: {
                mr.k = val;
            }
            case 11: {
                mr.l = !val;
            }
            default: {
                Config.warn(invokedynamic(makeConcatWithConstants:(Lnet/optifine/entity/model/anim/ModelVariableType;)Ljava/lang/String;, this));
            }
        }
    }
    
    public IModelVariable makeModelVariable(final String name, final fee mr) {
        if (this.type == ExpressionType.FLOAT) {
            return new ModelVariableFloat(name, mr, this);
        }
        if (this.type == ExpressionType.BOOL) {
            return new ModelVariableBool(name, mr, this);
        }
        Config.warn(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/ExpressionType;)Ljava/lang/String;, this.type));
        return null;
    }
    
    public static ModelVariableType parse(final String str) {
        for (int i = 0; i < ModelVariableType.VALUES.length; ++i) {
            final ModelVariableType var = ModelVariableType.VALUES[i];
            if (var.getName().equals(str)) {
                return var;
            }
        }
        return null;
    }
    
    private static /* synthetic */ ModelVariableType[] $values() {
        return new ModelVariableType[] { ModelVariableType.POS_X, ModelVariableType.POS_Y, ModelVariableType.POS_Z, ModelVariableType.ANGLE_X, ModelVariableType.ANGLE_Y, ModelVariableType.ANGLE_Z, ModelVariableType.SCALE_X, ModelVariableType.SCALE_Y, ModelVariableType.SCALE_Z, ModelVariableType.VISIBLE, ModelVariableType.VISIBLE_BOXES };
    }
    
    static {
        $VALUES = $values();
        ModelVariableType.VALUES = values();
    }
}
