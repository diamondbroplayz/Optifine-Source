// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model.anim;

import net.optifine.expr.IExpression;

public interface IModelVariable extends IExpression
{
    void setValue(final IExpression p0);
}
