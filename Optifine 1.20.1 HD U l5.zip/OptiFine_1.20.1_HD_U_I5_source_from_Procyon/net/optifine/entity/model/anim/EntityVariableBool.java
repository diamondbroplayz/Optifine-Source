// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model.anim;

import java.util.HashMap;

public class EntityVariableBool implements IModelVariableBool
{
    private String name;
    private fow renderManager;
    
    public EntityVariableBool(final String name) {
        this.name = name;
        this.renderManager = enn.N().an();
    }
    
    @Override
    public boolean eval() {
        return this.getValue();
    }
    
    @Override
    public boolean getValue() {
        final acb entityData = this.getEntityData();
        if (entityData == null) {
            return false;
        }
        if (entityData.modelVariables == null) {
            return false;
        }
        final Boolean val = entityData.modelVariables.get(this.name);
        return val != null && val;
    }
    
    @Override
    public void setValue(final boolean value) {
        final acb entityData = this.getEntityData();
        if (entityData == null) {
            return;
        }
        if (entityData.modelVariables == null) {
            entityData.modelVariables = new HashMap();
        }
        entityData.modelVariables.put(this.name, value);
    }
    
    private acb getEntityData() {
        final bfj entity = this.renderManager.getRenderedEntity();
        if (entity == null) {
            return null;
        }
        return entity.aj();
    }
}
