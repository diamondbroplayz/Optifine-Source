// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model.anim;

import net.optifine.expr.IExpression;
import net.optifine.expr.IExpressionBool;

public interface IModelVariableBool extends IExpressionBool, IModelVariable
{
    boolean getValue();
    
    void setValue(final boolean p0);
    
    default void setValue(final IExpression expr) {
        final boolean val = ((IExpressionBool)expr).eval();
        this.setValue(val);
    }
}
