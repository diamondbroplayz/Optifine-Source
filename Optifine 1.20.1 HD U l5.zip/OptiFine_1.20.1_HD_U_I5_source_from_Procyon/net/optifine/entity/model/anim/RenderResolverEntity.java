// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model.anim;

import net.optifine.expr.IExpression;

public class RenderResolverEntity implements IRenderResolver
{
    @Override
    public IExpression getParameter(final String name) {
        final RenderEntityParameterBool parBool = RenderEntityParameterBool.parse(name);
        if (parBool != null) {
            return parBool;
        }
        final RenderEntityParameterFloat parFloat = RenderEntityParameterFloat.parse(name);
        if (parFloat != null) {
            return parFloat;
        }
        return null;
    }
    
    @Override
    public boolean isTileEntity() {
        return false;
    }
}
