// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model.anim;

import java.util.HashMap;

public class EntityVariableFloat implements IModelVariableFloat
{
    private String name;
    private static fow renderManager;
    
    public EntityVariableFloat(final String name) {
        this.name = name;
    }
    
    @Override
    public float eval() {
        return this.getValue();
    }
    
    @Override
    public float getValue() {
        return getEntityValue(this.name);
    }
    
    public static float getEntityValue(final String key) {
        final acb entityData = getEntityData();
        if (entityData == null) {
            return 0.0f;
        }
        if (entityData.modelVariables == null) {
            return 0.0f;
        }
        final Float val = entityData.modelVariables.get(key);
        if (val == null) {
            return 0.0f;
        }
        return val;
    }
    
    @Override
    public void setValue(final float value) {
        setEntityValue(this.name, value);
    }
    
    public static void setEntityValue(final String key, final float value) {
        final acb entityData = getEntityData();
        if (entityData == null) {
            return;
        }
        if (entityData.modelVariables == null) {
            entityData.modelVariables = new HashMap();
        }
        entityData.modelVariables.put(key, value);
    }
    
    private static acb getEntityData() {
        final bfj entity = EntityVariableFloat.renderManager.getRenderedEntity();
        if (entity == null) {
            return null;
        }
        return entity.aj();
    }
    
    static {
        EntityVariableFloat.renderManager = enn.N().an();
    }
}
