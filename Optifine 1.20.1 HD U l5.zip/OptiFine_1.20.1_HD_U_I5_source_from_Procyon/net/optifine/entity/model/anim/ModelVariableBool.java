// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model.anim;

import net.optifine.expr.IExpressionBool;

public class ModelVariableBool implements IExpressionBool, IModelVariableBool
{
    private String name;
    private fee modelRenderer;
    private ModelVariableType enumModelVariable;
    
    public ModelVariableBool(final String name, final fee modelRenderer, final ModelVariableType enumModelVariable) {
        this.name = name;
        this.modelRenderer = modelRenderer;
        this.enumModelVariable = enumModelVariable;
    }
    
    @Override
    public boolean eval() {
        return this.getValue();
    }
    
    @Override
    public boolean getValue() {
        return this.enumModelVariable.getBool(this.modelRenderer);
    }
    
    @Override
    public void setValue(final boolean value) {
        this.enumModelVariable.setBool(this.modelRenderer, value);
    }
    
    @Override
    public String toString() {
        return this.name;
    }
}
