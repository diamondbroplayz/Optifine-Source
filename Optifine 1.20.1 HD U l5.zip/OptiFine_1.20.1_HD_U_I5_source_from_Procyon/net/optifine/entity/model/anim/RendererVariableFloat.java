// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model.anim;

public enum RendererVariableFloat implements IModelVariableFloat
{
    SHADOW_SIZE("shadow_size"), 
    SHADOW_OPACITY("shadow_opacity"), 
    LEASH_OFFSET_X("leash_offset_x"), 
    LEASH_OFFSET_Y("leash_offset_y"), 
    LEASH_OFFSET_Z("leash_offset_z"), 
    SHADOW_OFFSET_X("shadow_offset_x"), 
    SHADOW_OFFSET_Z("shadow_offset_z");
    
    private String name;
    private fow renderManager;
    private static final RendererVariableFloat[] VALUES;
    
    private RendererVariableFloat(final String name) {
        this.name = name;
        this.renderManager = enn.N().an();
    }
    
    @Override
    public float eval() {
        return this.getValue();
    }
    
    @Override
    public float getValue() {
        final fox renderer = this.renderManager.getEntityRenderer();
        if (renderer == null) {
            return 0.0f;
        }
        switch (RendererVariableFloat.RendererVariableFloat$1.$SwitchMap$net$optifine$entity$model$anim$RendererVariableFloat[this.ordinal()]) {
            case 1: {
                return renderer.d;
            }
            case 2: {
                return renderer.e;
            }
            case 3: {
                return renderer.shadowOffsetX;
            }
            case 4: {
                return renderer.shadowOffsetZ;
            }
            default: {
                if (renderer instanceof fqe) {
                    final fqe mobRenderer = (fqe)renderer;
                    switch (RendererVariableFloat.RendererVariableFloat$1.$SwitchMap$net$optifine$entity$model$anim$RendererVariableFloat[this.ordinal()]) {
                        case 5: {
                            return mobRenderer.leashOffsetX;
                        }
                        case 6: {
                            return mobRenderer.leashOffsetY;
                        }
                        case 7: {
                            return mobRenderer.leashOffsetZ;
                        }
                    }
                }
                return 0.0f;
            }
        }
    }
    
    @Override
    public void setValue(final float value) {
        final fox renderer = this.renderManager.getEntityRenderer();
        if (renderer == null) {
            return;
        }
        switch (RendererVariableFloat.RendererVariableFloat$1.$SwitchMap$net$optifine$entity$model$anim$RendererVariableFloat[this.ordinal()]) {
            case 1: {
                renderer.d = value;
            }
            case 2: {
                renderer.e = value;
            }
            case 3: {
                renderer.shadowOffsetX = value;
            }
            case 4: {
                renderer.shadowOffsetZ = value;
            }
            default: {
                if (renderer instanceof fqe) {
                    final fqe mobRenderer = (fqe)renderer;
                    switch (RendererVariableFloat.RendererVariableFloat$1.$SwitchMap$net$optifine$entity$model$anim$RendererVariableFloat[this.ordinal()]) {
                        case 5: {
                            mobRenderer.leashOffsetX = value;
                        }
                        case 6: {
                            mobRenderer.leashOffsetY = value;
                        }
                        case 7: {
                            mobRenderer.leashOffsetZ = value;
                        }
                    }
                }
            }
        }
    }
    
    public String getName() {
        return this.name;
    }
    
    public static RendererVariableFloat parse(final String str) {
        if (str == null) {
            return null;
        }
        for (int i = 0; i < RendererVariableFloat.VALUES.length; ++i) {
            final RendererVariableFloat type = RendererVariableFloat.VALUES[i];
            if (type.getName().equals(str)) {
                return type;
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    private static /* synthetic */ RendererVariableFloat[] $values() {
        return new RendererVariableFloat[] { RendererVariableFloat.SHADOW_SIZE, RendererVariableFloat.SHADOW_OPACITY, RendererVariableFloat.LEASH_OFFSET_X, RendererVariableFloat.LEASH_OFFSET_Y, RendererVariableFloat.LEASH_OFFSET_Z, RendererVariableFloat.SHADOW_OFFSET_X, RendererVariableFloat.SHADOW_OFFSET_Z };
    }
    
    static {
        $VALUES = $values();
        VALUES = values();
    }
}
