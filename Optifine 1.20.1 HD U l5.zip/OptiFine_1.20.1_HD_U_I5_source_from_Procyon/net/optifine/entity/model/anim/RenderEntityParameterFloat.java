// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model.anim;

import java.util.UUID;
import net.optifine.entity.model.CustomEntityModels;
import net.optifine.util.WorldUtils;
import net.optifine.Config;
import net.optifine.util.MathUtils;
import net.optifine.expr.IExpressionFloat;

public enum RenderEntityParameterFloat implements IExpressionFloat
{
    LIMB_SWING("limb_swing"), 
    LIMB_SWING_SPEED("limb_speed"), 
    AGE("age"), 
    HEAD_YAW("head_yaw"), 
    HEAD_PITCH("head_pitch"), 
    HEALTH("health"), 
    HURT_TIME("hurt_time"), 
    DEATH_TIME("death_time"), 
    IDLE_TIME("idle_time"), 
    MAX_HEALTH("max_health"), 
    MOVE_FORWARD("move_forward"), 
    MOVE_STRAFING("move_strafing"), 
    POS_X("pos_x", true), 
    POS_Y("pos_y", true), 
    POS_Z("pos_z", true), 
    ROT_X("rot_x"), 
    ROT_Y("rot_y"), 
    ID("id", true), 
    PLAYER_POS_X("player_pos_x", true), 
    PLAYER_POS_Y("player_pos_y", true), 
    PLAYER_POS_Z("player_pos_z", true), 
    PLAYER_ROT_X("player_rot_x", true), 
    PLAYER_ROT_Y("player_rot_y", true), 
    FRAME_TIME("frame_time", true), 
    ANGER_TIME("anger_time"), 
    ANGER_TIME_START("anger_time_start"), 
    SWING_PROGRESS("swing_progress"), 
    DIMENSION("dimension", true), 
    RULE_INDEX("rule_index", true);
    
    private String name;
    private boolean blockEntity;
    private fow renderManager;
    private static final RenderEntityParameterFloat[] VALUES;
    private static enn mc;
    private static String KEY_ANGER_TIME_MAX;
    
    private RenderEntityParameterFloat(final String name) {
        this(name, false);
    }
    
    private RenderEntityParameterFloat(final String name, final boolean blockEntity) {
        this.name = name;
        this.blockEntity = blockEntity;
        this.renderManager = enn.N().an();
    }
    
    public String getName() {
        return this.name;
    }
    
    public boolean isBlockEntity() {
        return this.blockEntity;
    }
    
    @Override
    public float eval() {
        switch (this) {
            case PLAYER_POS_X: {
                return apa.i(fjq.getRenderPartialTicks(), (float)RenderEntityParameterFloat.mc.t.J, (float)RenderEntityParameterFloat.mc.t.dn());
            }
            case PLAYER_POS_Y: {
                return apa.i(fjq.getRenderPartialTicks(), (float)RenderEntityParameterFloat.mc.t.K, (float)RenderEntityParameterFloat.mc.t.dp());
            }
            case PLAYER_POS_Z: {
                return apa.i(fjq.getRenderPartialTicks(), (float)RenderEntityParameterFloat.mc.t.L, (float)RenderEntityParameterFloat.mc.t.dt());
            }
            case PLAYER_ROT_X: {
                return MathUtils.toRad(apa.i(fjq.getRenderPartialTicks(), RenderEntityParameterFloat.mc.t.N, RenderEntityParameterFloat.mc.t.dA()));
            }
            case PLAYER_ROT_Y: {
                return MathUtils.toRad(apa.i(fjq.getRenderPartialTicks(), RenderEntityParameterFloat.mc.t.M, RenderEntityParameterFloat.mc.t.dy()));
            }
            case FRAME_TIME: {
                return Config.getLastFrameTimeMs() / 1000.0f;
            }
            case DIMENSION: {
                return (float)WorldUtils.getDimensionId((cmm)RenderEntityParameterFloat.mc.s);
            }
            case RULE_INDEX: {
                return (float)CustomEntityModels.getMatchingRuleIndex();
            }
            default: {
                final czn blockEntity = flt.tileEntityRendered;
                if (blockEntity != null) {
                    switch (this) {
                        case POS_X: {
                            return (float)blockEntity.p().u();
                        }
                        case POS_Y: {
                            return (float)blockEntity.p().v();
                        }
                        case POS_Z: {
                            return (float)blockEntity.p().w();
                        }
                        case ID: {
                            return this.toFloat(blockEntity.p());
                        }
                    }
                }
                final fox render = this.renderManager.getEntityRenderer();
                if (render == null) {
                    return 0.0f;
                }
                final bfj entity = this.renderManager.getRenderedEntity();
                if (entity == null) {
                    return 0.0f;
                }
                Label_0689: {
                    if (render instanceof fpz) {
                        final fpz rlb = (fpz)render;
                        switch (this) {
                            case LIMB_SWING: {
                                return rlb.renderLimbSwing;
                            }
                            case LIMB_SWING_SPEED: {
                                return rlb.renderLimbSwingAmount;
                            }
                            case AGE: {
                                return rlb.renderAgeInTicks;
                            }
                            case HEAD_YAW: {
                                return rlb.renderHeadYaw;
                            }
                            case HEAD_PITCH: {
                                return rlb.renderHeadPitch;
                            }
                            default: {
                                if (!(entity instanceof bfz)) {
                                    break;
                                }
                                final bfz livingEntity = (bfz)entity;
                                switch (this) {
                                    case HEALTH: {
                                        return livingEntity.er();
                                    }
                                    case HURT_TIME: {
                                        return (livingEntity.aL > 0) ? (livingEntity.aL - fjq.getRenderPartialTicks()) : 0.0f;
                                    }
                                    case DEATH_TIME: {
                                        return (livingEntity.aN > 0) ? (livingEntity.aN + fjq.getRenderPartialTicks()) : 0.0f;
                                    }
                                    case IDLE_TIME: {
                                        return (livingEntity.eh() > 0) ? (livingEntity.eh() + fjq.getRenderPartialTicks()) : 0.0f;
                                    }
                                    case MAX_HEALTH: {
                                        return livingEntity.eI();
                                    }
                                    case MOVE_FORWARD: {
                                        return livingEntity.bn;
                                    }
                                    case MOVE_STRAFING: {
                                        return livingEntity.bl;
                                    }
                                    case ANGER_TIME: {
                                        if (livingEntity instanceof bgg) {
                                            final bgg neutralMob = (bgg)livingEntity;
                                            float val = (float)neutralMob.a();
                                            final float valMax = EntityVariableFloat.getEntityValue(RenderEntityParameterFloat.KEY_ANGER_TIME_MAX);
                                            if (val > 0.0f) {
                                                if (val > valMax) {
                                                    EntityVariableFloat.setEntityValue(RenderEntityParameterFloat.KEY_ANGER_TIME_MAX, val);
                                                }
                                                if (val < valMax) {
                                                    val -= fjq.getRenderPartialTicks();
                                                }
                                            }
                                            else if (valMax > 0.0f) {
                                                EntityVariableFloat.setEntityValue(RenderEntityParameterFloat.KEY_ANGER_TIME_MAX, 0.0f);
                                            }
                                            return val;
                                        }
                                        return EntityVariableFloat.getEntityValue(RenderEntityParameterFloat.KEY_ANGER_TIME_MAX);
                                    }
                                    case ANGER_TIME_START: {
                                        return EntityVariableFloat.getEntityValue(RenderEntityParameterFloat.KEY_ANGER_TIME_MAX);
                                    }
                                    case SWING_PROGRESS: {
                                        return livingEntity.x(fjq.getRenderPartialTicks());
                                    }
                                    default: {
                                        break Label_0689;
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
                if (entity instanceof cah) {
                    final cah boat = (cah)entity;
                    switch (this) {
                        case LIMB_SWING: {
                            final float left = boat.a(0, fjq.getRenderPartialTicks());
                            final float right = boat.a(1, fjq.getRenderPartialTicks());
                            return Math.max(left, right);
                        }
                        case LIMB_SWING_SPEED: {
                            return 1.0f;
                        }
                    }
                }
                if (entity instanceof caf) {
                    final caf minecart = (caf)entity;
                    switch (this) {
                        case LIMB_SWING: {
                            final float posX = apa.i(fjq.getRenderPartialTicks(), (float)minecart.ab, (float)minecart.dn());
                            final float posZ = apa.i(fjq.getRenderPartialTicks(), (float)minecart.ad, (float)minecart.dt());
                            final dcb bs = enn.N().s.a_(minecart.di());
                            if (!bs.a(amw.N)) {
                                return 1.0f;
                            }
                            final ddf rs = (ddf)bs.c(((cpd)bs.b()).b());
                            switch (rs) {
                                case h: {
                                    return posX + posZ;
                                }
                                case g: {
                                    return -(posX - posZ);
                                }
                                case i: {
                                    return posX - posZ;
                                }
                                default: {
                                    return -(posX + posZ);
                                }
                            }
                            break;
                        }
                        case LIMB_SWING_SPEED: {
                            return 1.0f;
                        }
                    }
                }
                switch (this) {
                    case POS_X: {
                        return apa.i(fjq.getRenderPartialTicks(), (float)entity.J, (float)entity.dn());
                    }
                    case POS_Y: {
                        return apa.i(fjq.getRenderPartialTicks(), (float)entity.K, (float)entity.dp());
                    }
                    case POS_Z: {
                        return apa.i(fjq.getRenderPartialTicks(), (float)entity.L, (float)entity.dt());
                    }
                    case ROT_X: {
                        return MathUtils.toRad(apa.i(fjq.getRenderPartialTicks(), entity.N, entity.dA()));
                    }
                    case ROT_Y: {
                        if (entity instanceof bfz) {
                            return MathUtils.toRad(apa.i(fjq.getRenderPartialTicks(), ((bfz)entity).aW, ((bfz)entity).aV));
                        }
                        return MathUtils.toRad(apa.i(fjq.getRenderPartialTicks(), entity.M, entity.dy()));
                    }
                    case ID: {
                        return this.toFloat(entity.ct());
                    }
                    default: {
                        return 0.0f;
                    }
                }
                break;
            }
        }
    }
    
    private float toFloat(final UUID uuid) {
        final int i0 = Long.hashCode(uuid.getLeastSignificantBits());
        final int i2 = Long.hashCode(uuid.getMostSignificantBits());
        final float id = Float.intBitsToFloat(i0 ^ i2);
        return id;
    }
    
    private float toFloat(final gu pos) {
        final int hash = Config.getRandom(pos, 0);
        final float id = Float.intBitsToFloat(hash);
        return id;
    }
    
    public static RenderEntityParameterFloat parse(final String str) {
        if (str == null) {
            return null;
        }
        for (int i = 0; i < RenderEntityParameterFloat.VALUES.length; ++i) {
            final RenderEntityParameterFloat type = RenderEntityParameterFloat.VALUES[i];
            if (type.getName().equals(str)) {
                return type;
            }
        }
        return null;
    }
    
    private static /* synthetic */ RenderEntityParameterFloat[] $values() {
        return new RenderEntityParameterFloat[] { RenderEntityParameterFloat.LIMB_SWING, RenderEntityParameterFloat.LIMB_SWING_SPEED, RenderEntityParameterFloat.AGE, RenderEntityParameterFloat.HEAD_YAW, RenderEntityParameterFloat.HEAD_PITCH, RenderEntityParameterFloat.HEALTH, RenderEntityParameterFloat.HURT_TIME, RenderEntityParameterFloat.DEATH_TIME, RenderEntityParameterFloat.IDLE_TIME, RenderEntityParameterFloat.MAX_HEALTH, RenderEntityParameterFloat.MOVE_FORWARD, RenderEntityParameterFloat.MOVE_STRAFING, RenderEntityParameterFloat.POS_X, RenderEntityParameterFloat.POS_Y, RenderEntityParameterFloat.POS_Z, RenderEntityParameterFloat.ROT_X, RenderEntityParameterFloat.ROT_Y, RenderEntityParameterFloat.ID, RenderEntityParameterFloat.PLAYER_POS_X, RenderEntityParameterFloat.PLAYER_POS_Y, RenderEntityParameterFloat.PLAYER_POS_Z, RenderEntityParameterFloat.PLAYER_ROT_X, RenderEntityParameterFloat.PLAYER_ROT_Y, RenderEntityParameterFloat.FRAME_TIME, RenderEntityParameterFloat.ANGER_TIME, RenderEntityParameterFloat.ANGER_TIME_START, RenderEntityParameterFloat.SWING_PROGRESS, RenderEntityParameterFloat.DIMENSION, RenderEntityParameterFloat.RULE_INDEX };
    }
    
    static {
        $VALUES = $values();
        VALUES = values();
        RenderEntityParameterFloat.mc = enn.N();
        RenderEntityParameterFloat.KEY_ANGER_TIME_MAX = "ANGER_TIME_MAX";
    }
}
