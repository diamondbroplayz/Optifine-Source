// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterPig extends ModelAdapterQuadruped
{
    public ModelAdapterPig() {
        super(bfn.av, "pig", 0.7f);
    }
    
    public fcb makeModel() {
        return (fcb)new fch(bakeModelLayer(fed.aC));
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fqm render = new fqm(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
