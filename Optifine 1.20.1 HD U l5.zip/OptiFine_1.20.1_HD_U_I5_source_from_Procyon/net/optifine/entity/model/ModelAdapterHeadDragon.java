// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.reflect.Reflector;

public class ModelAdapterHeadDragon extends ModelAdapterHead
{
    public ModelAdapterHeadDragon() {
        super("head_dragon", (fec)null, cwp.b.g);
    }
    
    public fcb makeModel() {
        return (fcb)new fdy(bakeModelLayer(fed.K));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdy)) {
            return null;
        }
        final fdy modelDragonHead = (fdy)model;
        if (modelPart.equals("head")) {
            return (fee)Reflector.getFieldValue(modelDragonHead, Reflector.ModelDragonHead_head);
        }
        if (modelPart.equals("jaw")) {
            return (fee)Reflector.getFieldValue(modelDragonHead, Reflector.ModelDragonHead_jaw);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "head", "jaw" };
    }
}
