// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.function.Function;

public class CustomEntityModel extends fcb
{
    public CustomEntityModel(final Function<acq, fkf> renderTypeIn) {
        super((Function)renderTypeIn);
    }
    
    public void a(final eij matrixStackIn, final ein bufferIn, final int packedLightIn, final int packedOverlayIn, final float red, final float green, final float blue, final float alpha) {
    }
}
