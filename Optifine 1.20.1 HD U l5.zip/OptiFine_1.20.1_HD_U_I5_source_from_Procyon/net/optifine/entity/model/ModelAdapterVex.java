// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModelAdapterVex extends ModelAdapter
{
    private static Map<String, String> mapParts;
    
    public ModelAdapterVex() {
        super(bfn.be, "vex", 0.3f);
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdo)) {
            return null;
        }
        final fdo modelVex = (fdo)model;
        if (ModelAdapterVex.mapParts.containsKey(modelPart)) {
            final String name = ModelAdapterVex.mapParts.get(modelPart);
            return modelVex.a().getChildModelDeep(name);
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        final String[] names = ModelAdapterVex.mapParts.keySet().toArray(new String[0]);
        return names;
    }
    
    private static Map<String, String> makeMapParts() {
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("body", "body");
        map.put("head", "head");
        map.put("right_arm", "right_arm");
        map.put("left_arm", "left_arm");
        map.put("right_wing", "right_wing");
        map.put("left_wing", "left_wing");
        return map;
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdo(ModelAdapter.bakeModelLayer(fed.bI));
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frr render = new frr(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
    
    static {
        ModelAdapterVex.mapParts = makeMapParts();
    }
}
