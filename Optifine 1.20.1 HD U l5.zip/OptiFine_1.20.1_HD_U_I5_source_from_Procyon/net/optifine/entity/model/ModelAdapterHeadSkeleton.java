// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterHeadSkeleton extends ModelAdapterHead
{
    public ModelAdapterHeadSkeleton() {
        super("head_skeleton", fed.bl, cwp.b.a);
    }
}
