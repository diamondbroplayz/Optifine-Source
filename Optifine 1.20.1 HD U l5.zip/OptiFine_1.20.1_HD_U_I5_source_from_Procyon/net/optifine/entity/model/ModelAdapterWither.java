// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterWither extends ModelAdapter
{
    public ModelAdapterWither() {
        super(bfn.bk, "wither", 0.5f);
    }
    
    public ModelAdapterWither(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdu(ModelAdapter.bakeModelLayer(fed.bO));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdu)) {
            return null;
        }
        final fdu modelWither = (fdu)model;
        if (modelPart.equals("body1")) {
            return modelWither.a().getChildModelDeep("shoulders");
        }
        if (modelPart.equals("body2")) {
            return modelWither.a().getChildModelDeep("ribcage");
        }
        if (modelPart.equals("body3")) {
            return modelWither.a().getChildModelDeep("tail");
        }
        if (modelPart.equals("head1")) {
            return modelWither.a().getChildModelDeep("center_head");
        }
        if (modelPart.equals("head2")) {
            return modelWither.a().getChildModelDeep("right_head");
        }
        if (modelPart.equals("head3")) {
            return modelWither.a().getChildModelDeep("left_head");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body1", "body2", "body3", "head1", "head2", "head3" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frx render = new frx(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
