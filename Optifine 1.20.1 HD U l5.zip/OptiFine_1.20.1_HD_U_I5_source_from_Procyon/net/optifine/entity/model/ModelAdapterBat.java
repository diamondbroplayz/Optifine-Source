// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

public class ModelAdapterBat extends ModelAdapter
{
    public ModelAdapterBat() {
        super(bfn.g, "bat", 0.25f);
    }
    
    public fcb makeModel() {
        return (fcb)new fak(bakeModelLayer(fed.g));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fak)) {
            return null;
        }
        final fak modelBat = (fak)model;
        if (modelPart.equals("head")) {
            return modelBat.a().getChildModelDeep("head");
        }
        if (modelPart.equals("body")) {
            return modelBat.a().getChildModelDeep("body");
        }
        if (modelPart.equals("right_wing")) {
            return modelBat.a().getChildModelDeep("right_wing");
        }
        if (modelPart.equals("left_wing")) {
            return modelBat.a().getChildModelDeep("left_wing");
        }
        if (modelPart.equals("outer_right_wing")) {
            return modelBat.a().getChildModelDeep("right_wing_tip");
        }
        if (modelPart.equals("outer_left_wing")) {
            return modelBat.a().getChildModelDeep("left_wing_tip");
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "head", "body", "right_wing", "left_wing", "outer_right_wing", "outer_left_wing" };
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final foa render = new foa(renderManager.getContext());
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
