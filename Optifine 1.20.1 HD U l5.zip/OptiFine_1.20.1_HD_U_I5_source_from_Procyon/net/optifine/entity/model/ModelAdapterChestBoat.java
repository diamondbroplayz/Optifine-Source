// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.util.ArrayUtils;
import com.google.common.collect.ImmutableList;

public class ModelAdapterChestBoat extends ModelAdapterBoat
{
    public ModelAdapterChestBoat() {
        super(bfn.o, "chest_boat", 0.5f);
    }
    
    public fcb makeModel() {
        return (fcb)new far(bakeModelLayer(fed.d(cah.b.a)));
    }
    
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof far)) {
            return null;
        }
        final far modelChestBoat = (far)model;
        final ImmutableList<fee> parts = (ImmutableList<fee>)modelChestBoat.b();
        if (parts != null) {
            if (modelPart.equals("chest_base")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 7);
            }
            if (modelPart.equals("chest_lid")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 8);
            }
            if (modelPart.equals("chest_knob")) {
                return ModelRendererUtils.getModelRenderer((ImmutableList)parts, 9);
            }
        }
        return super.getModelRenderer((fcb)modelChestBoat, modelPart);
    }
    
    @Override
    public String[] getModelRendererNames() {
        String[] names = super.getModelRendererNames();
        names = (String[])ArrayUtils.addObjectsToArray(names, new String[] { "chest_base", "chest_lid", "chest_knob" });
        return names;
    }
    
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final fod renderer = new fod(renderManager.getContext(), true);
        rendererCache.put(bfn.o, index, (fox)renderer);
        return ModelAdapterBoat.makeEntityRender(modelBase, shadowSize, renderer);
    }
}
