// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.entity.model;

import net.optifine.Config;
import net.optifine.util.StrUtils;

public class ModelAdapterSquid extends ModelAdapter
{
    public ModelAdapterSquid() {
        super(bfn.aT, "squid", 0.7f);
    }
    
    protected ModelAdapterSquid(final bfn entityType, final String name, final float shadowSize) {
        super(entityType, name, shadowSize);
    }
    
    @Override
    public fcb makeModel() {
        return (fcb)new fdh(ModelAdapter.bakeModelLayer(fed.bs));
    }
    
    @Override
    public fee getModelRenderer(final fcb model, final String modelPart) {
        if (!(model instanceof fdh)) {
            return null;
        }
        final fdh modelSquid = (fdh)model;
        if (modelPart.equals("body")) {
            return modelSquid.a().getChildModelDeep("body");
        }
        final String PREFIX_TENTACLE = "tentacle";
        if (modelPart.startsWith(PREFIX_TENTACLE)) {
            final String numStr = StrUtils.removePrefix(modelPart, PREFIX_TENTACLE);
            final int index = Config.parseInt(numStr, -1);
            final int indexPart = index - 1;
            return modelSquid.a().getChildModelDeep(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, indexPart));
        }
        return null;
    }
    
    @Override
    public String[] getModelRendererNames() {
        return new String[] { "body", "tentacle1", "tentacle2", "tentacle3", "tentacle4", "tentacle5", "tentacle6", "tentacle7", "tentacle8" };
    }
    
    @Override
    public IEntityRenderer makeEntityRender(final fcb modelBase, final float shadowSize, final RendererCache rendererCache, final int index) {
        final fow renderManager = enn.N().an();
        final frf render = new frf(renderManager.getContext(), (fdh)modelBase);
        render.f = (fbf)modelBase;
        render.d = shadowSize;
        return (IEntityRenderer)render;
    }
}
