// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

import net.optifine.Log;
import java.lang.reflect.Field;

public class FieldLocatorType implements IFieldLocator
{
    private ReflectorClass reflectorClass;
    private Class targetFieldType;
    private int targetFieldIndex;
    
    public FieldLocatorType(final ReflectorClass reflectorClass, final Class targetFieldType) {
        this(reflectorClass, targetFieldType, 0);
    }
    
    public FieldLocatorType(final ReflectorClass reflectorClass, final Class targetFieldType, final int targetFieldIndex) {
        this.reflectorClass = null;
        this.targetFieldType = null;
        this.reflectorClass = reflectorClass;
        this.targetFieldType = targetFieldType;
        this.targetFieldIndex = targetFieldIndex;
    }
    
    @Override
    public Field getField() {
        final Class cls = this.reflectorClass.getTargetClass();
        if (cls == null) {
            return null;
        }
        try {
            final Field[] fileds = cls.getDeclaredFields();
            int fieldIndex = 0;
            for (int i = 0; i < fileds.length; ++i) {
                final Field field = fileds[i];
                if (field.getType() == this.targetFieldType) {
                    if (fieldIndex == this.targetFieldIndex) {
                        field.setAccessible(true);
                        return field;
                    }
                    ++fieldIndex;
                }
            }
            Log.log(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/Class;I)Ljava/lang/String;, cls.getName(), this.targetFieldType, this.targetFieldIndex));
            return null;
        }
        catch (SecurityException e) {
            e.printStackTrace();
            return null;
        }
        catch (Throwable e2) {
            e2.printStackTrace();
            return null;
        }
    }
}
