// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

import net.optifine.Log;
import java.util.List;
import java.util.Collections;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import java.lang.reflect.Field;

public class FieldLocatorTypes implements IFieldLocator
{
    private Field field;
    
    public FieldLocatorTypes(final Class cls, final Class[] preTypes, final Class type, final Class[] postTypes, final String errorName) {
        this.field = null;
        final Field[] fs = cls.getDeclaredFields();
        final List<Class> types = new ArrayList<Class>();
        for (int i = 0; i < fs.length; ++i) {
            final Field field = fs[i];
            types.add(field.getType());
        }
        final List<Class> typesMatch = new ArrayList<Class>();
        typesMatch.addAll(Arrays.asList((Class[])preTypes));
        typesMatch.add(type);
        typesMatch.addAll(Arrays.asList((Class[])postTypes));
        final int index = Collections.indexOfSubList(types, typesMatch);
        if (index < 0) {
            Log.log(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, errorName));
            return;
        }
        final int index2 = Collections.indexOfSubList(types.subList(index + 1, types.size()), typesMatch);
        if (index2 >= 0) {
            Log.log(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, errorName));
            return;
        }
        final int indexField = index + preTypes.length;
        this.field = fs[indexField];
    }
    
    @Override
    public Field getField() {
        return this.field;
    }
}
