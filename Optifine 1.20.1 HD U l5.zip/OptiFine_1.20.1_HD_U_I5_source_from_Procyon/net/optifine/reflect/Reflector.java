// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

import java.util.function.Supplier;
import java.util.Optional;
import java.util.List;
import org.joml.Matrix4f;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.Event;
import com.google.common.collect.ImmutableMap;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import java.lang.reflect.InvocationTargetException;
import net.optifine.util.ArrayUtils;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import net.optifine.Log;
import java.lang.reflect.Method;
import org.apache.logging.log4j.Logger;

public class Reflector
{
    private static final Logger LOGGER;
    private static boolean logForge;
    public static ReflectorClass BrandingControl;
    public static ReflectorMethod BrandingControl_getBrandings;
    public static ReflectorMethod BrandingControl_getClientBranding;
    public static ReflectorMethod BrandingControl_forEachLine;
    public static ReflectorMethod BrandingControl_forEachAboveCopyrightLine;
    public static ReflectorClass IClientBlockExtensions;
    public static ReflectorMethod IClientBlockExtensions_ofBS;
    public static ReflectorClass IClientItemExtensions;
    public static ReflectorMethod IClientItemExtensions_ofIS;
    public static ReflectorMethod IClientItemExtensions_ofI;
    public static ReflectorMethod IClientItemExtensions_getFont;
    public static ReflectorClass IClientItemExtensions_FontContext;
    public static ReflectorField IClientItemExtensions_FontContext_SELECTED_ITEM_NAME;
    public static ReflectorClass CapabilityProvider;
    public static ReflectorMethod CapabilityProvider_gatherCapabilities;
    public static ReflectorClass ClientModLoader;
    public static ReflectorMethod ClientModLoader_isLoading;
    public static ReflectorClass ChunkDataEvent_Save;
    public static ReflectorConstructor ChunkDataEvent_Save_Constructor;
    public static ReflectorClass ChunkEvent_Load;
    public static ReflectorConstructor ChunkEvent_Load_Constructor;
    public static ReflectorClass ChunkEvent_Unload;
    public static ReflectorConstructor ChunkEvent_Unload_Constructor;
    public static ReflectorClass ColorResolverManager;
    public static ReflectorMethod ColorResolverManager_registerBlockTintCaches;
    public static ReflectorClass CrashReportExtender;
    public static ReflectorMethod CrashReportExtender_addCrashReportHeader;
    public static ReflectorMethod CrashReportExtender_extendSystemReport;
    public static ReflectorMethod CrashReportExtender_generateEnhancedStackTraceT;
    public static ReflectorMethod CrashReportExtender_generateEnhancedStackTraceSTE;
    public static ReflectorClass EntityRenderersEvent_AddLayers;
    public static ReflectorConstructor EntityRenderersEvent_AddLayers_Constructor;
    public static ReflectorClass EntityRenderersEvent_CreateSkullModels;
    public static ReflectorConstructor EntityRenderersEvent_CreateSkullModels_Constructor;
    public static ReflectorClass EntityLeaveLevelEvent;
    public static ReflectorConstructor EntityLeaveLevelEvent_Constructor;
    public static ReflectorClass ViewportEvent_ComputeCameraAngles;
    public static ReflectorMethod ViewportEvent_ComputeCameraAngles_getYaw;
    public static ReflectorMethod ViewportEvent_ComputeCameraAngles_getPitch;
    public static ReflectorMethod ViewportEvent_ComputeCameraAngles_getRoll;
    public static ReflectorClass EntityJoinLevelEvent;
    public static ReflectorConstructor EntityJoinLevelEvent_Constructor;
    public static ReflectorClass Event;
    public static ReflectorMethod Event_isCanceled;
    public static ReflectorMethod Event_getResult;
    public static ReflectorClass EventBus;
    public static ReflectorMethod EventBus_post;
    public static ReflectorClass Event_Result;
    public static ReflectorField Event_Result_DENY;
    public static ReflectorField Event_Result_ALLOW;
    public static ReflectorField Event_Result_DEFAULT;
    public static ReflectorClass FluidType;
    public static ReflectorMethod FluidType_isAir;
    public static ReflectorClass ForgeModelBlockRenderer;
    public static ReflectorConstructor ForgeModelBlockRenderer_Constructor;
    public static ReflectorClass ForgeBlockModelShapes;
    public static ReflectorMethod ForgeBlockModelShapes_getTexture3;
    public static ReflectorClass ForgeBlockElementFace;
    public static ReflectorMethod ForgeBlockElementFace_getFaceData;
    public static ReflectorClass IForgeBlockState;
    public static ReflectorMethod IForgeBlockState_getLightEmission;
    public static ReflectorMethod IForgeBlockState_getSoundType3;
    public static ReflectorMethod IForgeBlockState_getStateAtViewpoint;
    public static ReflectorMethod IForgeBlockState_shouldDisplayFluidOverlay;
    public static ReflectorClass IForgeEntity;
    public static ReflectorMethod IForgeEntity_canUpdate;
    public static ReflectorMethod IForgeEntity_getEyeInFluidType;
    public static ReflectorMethod IForgeEntity_getParts;
    public static ReflectorMethod IForgeEntity_hasCustomOutlineRendering;
    public static ReflectorMethod IForgeEntity_isMultipartEntity;
    public static ReflectorMethod IForgeEntity_onAddedToWorld;
    public static ReflectorMethod IForgeEntity_onRemovedFromWorld;
    public static ReflectorMethod IForgeEntity_shouldRiderSit;
    public static ReflectorClass IForgePlayer;
    public static ReflectorMethod IForgePlayer_getEntityReach;
    public static ReflectorMethod IForgePlayer_getBlockReach;
    public static ReflectorClass ForgeChunkHolder;
    public static ReflectorField ForgeChunkHolder_currentlyLoading;
    public static ReflectorClass ForgeEventFactory;
    public static ReflectorMethod ForgeEventFactory_canEntityDespawn;
    public static ReflectorMethod ForgeEventFactory_fireChunkTicketLevelUpdated;
    public static ReflectorMethod ForgeEventFactory_fireChunkWatch;
    public static ReflectorMethod ForgeEventFactory_fireChunkUnWatch;
    public static ReflectorMethod ForgeEventFactory_getMaxSpawnPackSize;
    public static ReflectorMethod ForgeEventFactory_getMobGriefingEvent;
    public static ReflectorMethod ForgeEventFactory_onPlaySoundAtEntity;
    public static ReflectorMethod ForgeEventFactory_onPlaySoundAtPosition;
    public static ReflectorClass ForgeHooks;
    public static ReflectorMethod ForgeHooks_onDifficultyChange;
    public static ReflectorMethod ForgeHooks_onLivingAttack;
    public static ReflectorMethod ForgeHooks_onLivingChangeTarget;
    public static ReflectorMethod ForgeHooks_onLivingDeath;
    public static ReflectorMethod ForgeHooks_onLivingDrops;
    public static ReflectorMethod ForgeHooks_onLivingFall;
    public static ReflectorMethod ForgeHooks_onLivingHurt;
    public static ReflectorMethod ForgeHooks_onLivingJump;
    public static ReflectorClass ForgeHooksClient;
    public static ReflectorMethod ForgeHooksClient_calculateFaceWithoutAO;
    public static ReflectorMethod ForgeHooksClient_onCustomizeBossEventProgress;
    public static ReflectorMethod ForgeHooksClient_onRenderTooltipColor;
    public static ReflectorMethod ForgeHooksClient_dispatchRenderStageS;
    public static ReflectorMethod ForgeHooksClient_dispatchRenderStageRT;
    public static ReflectorMethod ForgeHooksClient_drawScreen;
    public static ReflectorMethod ForgeHooksClient_fillNormal;
    public static ReflectorMethod ForgeHooksClient_gatherTooltipComponents6;
    public static ReflectorMethod ForgeHooksClient_gatherTooltipComponents7;
    public static ReflectorMethod ForgeHooksClient_onKeyInput;
    public static ReflectorMethod ForgeHooksClient_getFogColor;
    public static ReflectorMethod ForgeHooksClient_handleCameraTransforms;
    public static ReflectorMethod ForgeHooksClient_getArmorModel;
    public static ReflectorMethod ForgeHooksClient_getArmorTexture;
    public static ReflectorMethod ForgeHooksClient_getFluidSprites;
    public static ReflectorMethod ForgeHooksClient_getFieldOfViewModifier;
    public static ReflectorMethod ForgeHooksClient_getFieldOfView;
    public static ReflectorMethod ForgeHooksClient_getGuiFarPlane;
    public static ReflectorMethod ForgeHooksClient_getShaderImportLocation;
    public static ReflectorMethod ForgeHooksClient_isNameplateInRenderDistance;
    public static ReflectorMethod ForgeHooksClient_loadEntityShader;
    public static ReflectorMethod ForgeHooksClient_loadTextureAtlasSprite;
    public static ReflectorMethod ForgeHooksClient_loadSpriteContents;
    public static ReflectorMethod ForgeHooksClient_makeParticleRenderTypeComparator;
    public static ReflectorMethod ForgeHooksClient_onCameraSetup;
    public static ReflectorMethod ForgeHooksClient_onDrawHighlight;
    public static ReflectorMethod ForgeHooksClient_onFogRender;
    public static ReflectorMethod ForgeHooksClient_onRegisterAdditionalModels;
    public static ReflectorMethod ForgeHooksClient_onRenderTooltipPre;
    public static ReflectorMethod ForgeHooksClient_onScreenCharTypedPre;
    public static ReflectorMethod ForgeHooksClient_onScreenCharTypedPost;
    public static ReflectorMethod ForgeHooksClient_onScreenKeyPressedPre;
    public static ReflectorMethod ForgeHooksClient_onScreenKeyPressedPost;
    public static ReflectorMethod ForgeHooksClient_onScreenKeyReleasedPre;
    public static ReflectorMethod ForgeHooksClient_onScreenKeyReleasedPost;
    public static ReflectorMethod ForgeHooksClient_onScreenshot;
    public static ReflectorMethod ForgeHooksClient_onTextureStitchedPost;
    public static ReflectorMethod ForgeHooksClient_renderBlockOverlay;
    public static ReflectorMethod ForgeHooksClient_renderFireOverlay;
    public static ReflectorMethod ForgeHooksClient_renderWaterOverlay;
    public static ReflectorMethod ForgeHooksClient_renderMainMenu;
    public static ReflectorMethod ForgeHooksClient_renderSpecificFirstPersonHand;
    public static ReflectorMethod ForgeHooksClient_shouldCauseReequipAnimation;
    public static ReflectorClass ForgeConfig;
    public static ReflectorField ForgeConfig_CLIENT;
    public static ReflectorClass ForgeConfig_Client;
    public static ReflectorField ForgeConfig_Client_forgeLightPipelineEnabled;
    public static ReflectorField ForgeConfig_Client_useCombinedDepthStencilAttachment;
    public static ReflectorClass ForgeConfigSpec;
    public static ReflectorField ForgeConfigSpec_childConfig;
    public static ReflectorClass ForgeConfigSpec_ConfigValue;
    public static ReflectorField ForgeConfigSpec_ConfigValue_defaultSupplier;
    public static ReflectorField ForgeConfigSpec_ConfigValue_spec;
    public static ReflectorMethod ForgeConfigSpec_ConfigValue_get;
    public static ReflectorClass ForgeIChunk;
    public static ReflectorMethod ForgeIChunk_getWorldForge;
    public static ReflectorClass IForgeItem;
    public static ReflectorMethod IForgeItem_getEquipmentSlot;
    public static ReflectorMethod IForgeItem_isDamageable1;
    public static ReflectorMethod IForgeItem_onEntitySwing;
    public static ReflectorMethod IForgeItem_shouldCauseReequipAnimation;
    public static ReflectorClass IForgeItemStack;
    public static ReflectorMethod IForgeItemStack_canDisableShield;
    public static ReflectorMethod IForgeItemStack_getEquipmentSlot;
    public static ReflectorMethod IForgeItemStack_getShareTag;
    public static ReflectorMethod IForgeItemStack_getHighlightTip;
    public static ReflectorMethod IForgeItemStack_readShareTag;
    public static ReflectorClass ForgeItemTags;
    public static ReflectorMethod ForgeItemTags_create;
    public static ReflectorClass ForgeI18n;
    public static ReflectorMethod ForgeI18n_loadLanguageData;
    public static ReflectorClass ForgeKeyBinding;
    public static ReflectorMethod ForgeKeyBinding_setKeyConflictContext;
    public static ReflectorMethod ForgeKeyBinding_setKeyModifierAndCode;
    public static ReflectorMethod ForgeKeyBinding_getKeyModifier;
    public static ReflectorClass ForgeMapDecoration;
    public static ReflectorMethod ForgeMapDecoration_render;
    public static ReflectorClass ForgeSnapshotsMod;
    public static ReflectorMethod ForgeSnapshotsMod_processOptions;
    public static ReflectorClass ForgeRarity;
    public static ReflectorMethod ForgeRarity_getStyleModifier;
    public static ReflectorClass ForgeTicket;
    public static ReflectorField ForgeTicket_forceTicks;
    public static ReflectorMethod ForgeTicket_isForceTicks;
    public static ReflectorClass IForgeBlockEntity;
    public static ReflectorMethod IForgeBlockEntity_getRenderBoundingBox;
    public static ReflectorMethod IForgeBlockEntity_hasCustomOutlineRendering;
    public static ReflectorClass IForgeDimensionSpecialEffects;
    public static ReflectorMethod IForgeDimensionSpecialEffects_adjustLightmapColors;
    public static ReflectorMethod IForgeDimensionSpecialEffects_renderClouds;
    public static ReflectorMethod IForgeDimensionSpecialEffects_renderSky;
    public static ReflectorMethod IForgeDimensionSpecialEffects_tickRain;
    public static ReflectorMethod IForgeDimensionSpecialEffects_renderSnowAndRain;
    public static ReflectorClass ForgeVersion;
    public static ReflectorMethod ForgeVersion_getVersion;
    public static ReflectorMethod ForgeVersion_getSpec;
    public static ReflectorClass ImmediateWindowHandler;
    public static ReflectorMethod ImmediateWindowHandler_positionWindow;
    public static ReflectorMethod ImmediateWindowHandler_setupMinecraftWindow;
    public static ReflectorMethod ImmediateWindowHandler_updateFBSize;
    public static ReflectorClass ItemDecoratorHandler;
    public static ReflectorMethod ItemDecoratorHandler_of;
    public static ReflectorMethod ItemDecoratorHandler_render;
    public static ReflectorClass ForgeItemModelShaper;
    public static ReflectorConstructor ForgeItemModelShaper_Constructor;
    public static ReflectorClass GeometryLoaderManager;
    public static ReflectorMethod GeometryLoaderManager_init;
    public static ReflectorClass KeyConflictContext;
    public static ReflectorField KeyConflictContext_IN_GAME;
    public static ReflectorClass KeyModifier;
    public static ReflectorMethod KeyModifier_valueFromString;
    public static ReflectorField KeyModifier_NONE;
    public static ReflectorClass Launch;
    public static ReflectorField Launch_blackboard;
    public static ReflectorClass MinecraftForge;
    public static ReflectorField MinecraftForge_EVENT_BUS;
    public static ReflectorClass ModContainer;
    public static ReflectorMethod ModContainer_getModId;
    public static ReflectorClass ModList;
    public static ReflectorField ModList_mods;
    public static ReflectorMethod ModList_get;
    public static ReflectorClass ModListScreen;
    public static ReflectorConstructor ModListScreen_Constructor;
    public static ReflectorClass ModLoader;
    public static ReflectorMethod ModLoader_get;
    public static ReflectorMethod ModLoader_postEvent;
    public static ReflectorClass TitleScreenModUpdateIndicator;
    public static ReflectorMethod TitleScreenModUpdateIndicator_init;
    public static ReflectorClass PartEntity;
    public static ReflectorClass PlayLevelSoundEvent;
    public static ReflectorMethod PlayLevelSoundEvent_getSound;
    public static ReflectorMethod PlayLevelSoundEvent_getSource;
    public static ReflectorMethod PlayLevelSoundEvent_getNewVolume;
    public static ReflectorMethod PlayLevelSoundEvent_getNewPitch;
    public static ReflectorClass QuadBakingVertexConsumer;
    public static ReflectorField QuadBakingVertexConsumer_QUAD_DATA_SIZE;
    public static ReflectorClass QuadTransformers;
    public static ReflectorMethod QuadTransformers_applyingLightmap;
    public static ReflectorMethod QuadTransformers_applyingColor;
    public static ReflectorClass IQuadTransformer;
    public static ReflectorField IQuadTransformer_STRIDE;
    public static ReflectorMethod IQuadTransformer_processInPlace;
    public static ReflectorClass RegisterShadersEvent;
    public static ReflectorConstructor RegisterShadersEvent_Constructor;
    public static ReflectorClass RenderBlockScreenEffectEvent_OverlayType;
    public static ReflectorField RenderBlockScreenEffectEvent_OverlayType_BLOCK;
    public static ReflectorClass CustomizeGuiOverlayEvent_BossEventProgress;
    public static ReflectorMethod CustomizeGuiOverlayEvent_BossEventProgress_getIncrement;
    public static ReflectorClass RenderItemInFrameEvent;
    public static ReflectorConstructor RenderItemInFrameEvent_Constructor;
    public static ReflectorClass RenderLevelStageEvent_Stage;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_SKY;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_SOLID_BLOCKS;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_CUTOUT_MIPPED_BLOCKS_BLOCKS;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_CUTOUT_BLOCKS;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_ENTITIES;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_BLOCK_ENTITIES;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_TRANSLUCENT_BLOCKS;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_TRIPWIRE_BLOCKS;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_PARTICLES;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_WEATHER;
    public static ReflectorField RenderLevelStageEvent_Stage_AFTER_LEVEL;
    public static ReflectorClass RenderLivingEvent_Pre;
    public static ReflectorConstructor RenderLivingEvent_Pre_Constructor;
    public static ReflectorClass RenderLivingEvent_Post;
    public static ReflectorConstructor RenderLivingEvent_Post_Constructor;
    public static ReflectorClass RenderNameTagEvent;
    public static ReflectorConstructor RenderNameTagEvent_Constructor;
    public static ReflectorMethod RenderNameTagEvent_getContent;
    public static ReflectorClass RenderTooltipEvent;
    public static ReflectorMethod RenderTooltipEvent_getFont;
    public static ReflectorMethod RenderTooltipEvent_getX;
    public static ReflectorMethod RenderTooltipEvent_getY;
    public static ReflectorClass RenderTooltipEvent_Color;
    public static ReflectorMethod RenderTooltipEvent_Color_getBackgroundStart;
    public static ReflectorMethod RenderTooltipEvent_Color_getBackgroundEnd;
    public static ReflectorMethod RenderTooltipEvent_Color_getBorderStart;
    public static ReflectorMethod RenderTooltipEvent_Color_getBorderEnd;
    public static ReflectorClass ScreenshotEvent;
    public static ReflectorMethod ScreenshotEvent_getCancelMessage;
    public static ReflectorMethod ScreenshotEvent_getScreenshotFile;
    public static ReflectorMethod ScreenshotEvent_getResultMessage;
    public static ReflectorClass ServerLifecycleHooks;
    public static ReflectorMethod ServerLifecycleHooks_handleServerAboutToStart;
    public static ReflectorMethod ServerLifecycleHooks_handleServerStarting;
    public static ReflectorClass TerrainParticle;
    public static ReflectorMethod TerrainParticle_updateSprite;
    public static ReflectorClass TooltipRenderUtil;
    public static ReflectorMethod TooltipRenderUtil_renderTooltipBackground10;
    public static ReflectorClass LevelEvent_Load;
    public static ReflectorConstructor LevelEvent_Load_Constructor;
    private static boolean logVanilla;
    public static ReflectorClass AbstractArrow;
    public static ReflectorField AbstractArrow_inGround;
    public static ReflectorClass EntityItem;
    public static ReflectorField EntityItem_ITEM;
    public static ReflectorClass EnderDragonRenderer;
    public static ReflectorField EnderDragonRenderer_model;
    public static ReflectorClass GuiEnchantment;
    public static ReflectorField GuiEnchantment_bookModel;
    public static ReflectorClass ItemOverride;
    public static ReflectorField ItemOverride_listResourceValues;
    public static ReflectorClass LayerLlamaDecor;
    public static ReflectorField LayerLlamaDecor_model;
    public static ReflectorClass Minecraft;
    public static ReflectorField Minecraft_debugFPS;
    public static ReflectorField Minecraft_fontResourceManager;
    public static ReflectorClass ModelArmorStand;
    public static ReflectorFields ModelArmorStand_ModelRenderers;
    public static ReflectorClass ModelBee;
    public static ReflectorFields ModelBee_ModelRenderers;
    public static ReflectorClass ModelBlaze;
    public static ReflectorField ModelBlaze_blazeHead;
    public static ReflectorField ModelBlaze_blazeSticks;
    public static ReflectorClass ModelBoar;
    public static ReflectorFields ModelBoar_ModelRenderers;
    public static ReflectorClass ModelBook;
    public static ReflectorField ModelBook_root;
    public static ReflectorClass ModelChicken;
    public static ReflectorFields ModelChicken_ModelRenderers;
    public static ReflectorClass ModelDragon;
    public static ReflectorFields ModelDragon_ModelRenderers;
    public static ReflectorClass RenderEnderCrystal;
    public static ReflectorFields RenderEnderCrystal_modelRenderers;
    public static ReflectorClass ModelEvokerFangs;
    public static ReflectorFields ModelEvokerFangs_ModelRenderers;
    public static ReflectorClass ModelGuardian;
    public static ReflectorField ModelGuardian_spines;
    public static ReflectorField ModelGuardian_tail;
    public static ReflectorClass ModelDragonHead;
    public static ReflectorField ModelDragonHead_head;
    public static ReflectorField ModelDragonHead_jaw;
    public static ReflectorClass ModelHorse;
    public static ReflectorFields ModelHorse_ModelRenderers;
    public static ReflectorClass ModelHorseChests;
    public static ReflectorFields ModelHorseChests_ModelRenderers;
    public static ReflectorClass ModelIllager;
    public static ReflectorFields ModelIllager_ModelRenderers;
    public static ReflectorClass ModelIronGolem;
    public static ReflectorFields ModelIronGolem_ModelRenderers;
    public static ReflectorClass ModelAxolotl;
    public static ReflectorFields ModelAxolotl_ModelRenderers;
    public static ReflectorClass ModelFox;
    public static ReflectorFields ModelFox_ModelRenderers;
    public static ReflectorClass ModelLeashKnot;
    public static ReflectorField ModelLeashKnot_knotRenderer;
    public static ReflectorClass RenderLeashKnot;
    public static ReflectorField RenderLeashKnot_leashKnotModel;
    public static ReflectorClass ModelLlama;
    public static ReflectorFields ModelLlama_ModelRenderers;
    public static ReflectorClass ModelOcelot;
    public static ReflectorFields ModelOcelot_ModelRenderers;
    public static ReflectorClass ModelPhantom;
    public static ReflectorFields ModelPhantom_ModelRenderers;
    public static ReflectorClass ModelPiglin;
    public static ReflectorFields ModelPiglin_ModelRenderers;
    public static ReflectorClass ModelPiglinHead;
    public static ReflectorFields ModelPiglinHead_ModelRenderers;
    public static ReflectorClass ModelQuadruped;
    public static ReflectorFields ModelQuadruped_ModelRenderers;
    public static ReflectorClass ModelRabbit;
    public static ReflectorFields ModelRabbit_ModelRenderers;
    public static ReflectorClass ModelShulker;
    public static ReflectorFields ModelShulker_ModelRenderers;
    public static ReflectorClass ModelSkull;
    public static ReflectorField ModelSkull_head;
    public static ReflectorClass ModelTadpole;
    public static ReflectorFields ModelTadpole_ModelRenderers;
    public static ReflectorClass ModelTrident;
    public static ReflectorField ModelTrident_root;
    public static ReflectorClass ModelTurtle;
    public static ReflectorField ModelTurtle_body2;
    public static ReflectorClass ModelVex;
    public static ReflectorField ModelVex_leftWing;
    public static ReflectorField ModelVex_rightWing;
    public static ReflectorClass ModelWolf;
    public static ReflectorFields ModelWolf_ModelRenderers;
    public static ReflectorClass OptiFineResourceLocator;
    public static ReflectorMethod OptiFineResourceLocator_getOptiFineResourceStream;
    public static ReflectorClass RenderBoat;
    public static ReflectorField RenderBoat_boatResources;
    public static ReflectorClass RenderEvokerFangs;
    public static ReflectorField RenderEvokerFangs_model;
    public static ReflectorClass RenderLlamaSpit;
    public static ReflectorField RenderLlamaSpit_model;
    public static ReflectorClass RenderPufferfish;
    public static ReflectorField RenderPufferfish_modelSmall;
    public static ReflectorField RenderPufferfish_modelMedium;
    public static ReflectorField RenderPufferfish_modelBig;
    public static ReflectorClass RenderMinecart;
    public static ReflectorField RenderMinecart_modelMinecart;
    public static ReflectorClass RenderShulkerBullet;
    public static ReflectorField RenderShulkerBullet_model;
    public static ReflectorClass RenderTrident;
    public static ReflectorField RenderTrident_modelTrident;
    public static ReflectorClass RenderTropicalFish;
    public static ReflectorField RenderTropicalFish_modelA;
    public static ReflectorField RenderTropicalFish_modelB;
    public static ReflectorClass TropicalFishPatternLayer;
    public static ReflectorField TropicalFishPatternLayer_modelA;
    public static ReflectorField TropicalFishPatternLayer_modelB;
    public static ReflectorClass RenderWitherSkull;
    public static ReflectorField RenderWitherSkull_model;
    public static ReflectorClass SimpleBakedModel;
    public static ReflectorField SimpleBakedModel_generalQuads;
    public static ReflectorField SimpleBakedModel_faceQuads;
    public static ReflectorClass TileEntityBannerRenderer;
    public static ReflectorFields TileEntityBannerRenderer_modelRenderers;
    public static ReflectorClass TileEntityBedRenderer;
    public static ReflectorField TileEntityBedRenderer_headModel;
    public static ReflectorField TileEntityBedRenderer_footModel;
    public static ReflectorClass TileEntityBellRenderer;
    public static ReflectorField TileEntityBellRenderer_modelRenderer;
    public static ReflectorClass TileEntityBeacon;
    public static ReflectorField TileEntityBeacon_customName;
    public static ReflectorField TileEntityBeacon_levels;
    public static ReflectorClass TileEntityChestRenderer;
    public static ReflectorFields TileEntityChestRenderer_modelRenderers;
    public static ReflectorClass TileEntityConduitRenderer;
    public static ReflectorFields TileEntityConduitRenderer_modelRenderers;
    public static ReflectorClass TileEntityDecoratedPotRenderer;
    public static ReflectorFields TileEntityDecoratedPotRenderer_modelRenderers;
    public static ReflectorClass TileEntityEnchantmentTableRenderer;
    public static ReflectorField TileEntityEnchantmentTableRenderer_modelBook;
    public static ReflectorClass TileEntityHangingSignRenderer;
    public static ReflectorField TileEntityHangingSignRenderer_hangingSignModels;
    public static ReflectorClass TileEntityLecternRenderer;
    public static ReflectorField TileEntityLecternRenderer_modelBook;
    public static ReflectorClass TileEntityShulkerBoxRenderer;
    public static ReflectorField TileEntityShulkerBoxRenderer_model;
    public static ReflectorClass TileEntitySignRenderer;
    public static ReflectorField TileEntitySignRenderer_signModels;
    
    public static void callVoid(final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method m = refMethod.getTargetMethod();
            if (m == null) {
                return;
            }
            m.invoke(null, params);
        }
        catch (Throwable e) {
            handleException(e, null, refMethod, params);
        }
    }
    
    public static boolean callBoolean(final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return false;
            }
            final Boolean retVal = (Boolean)method.invoke(null, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, null, refMethod, params);
            return false;
        }
    }
    
    public static int callInt(final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return 0;
            }
            final Integer retVal = (Integer)method.invoke(null, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, null, refMethod, params);
            return 0;
        }
    }
    
    public static long callLong(final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return 0L;
            }
            final Long retVal = (Long)method.invoke(null, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, null, refMethod, params);
            return 0L;
        }
    }
    
    public static float callFloat(final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return 0.0f;
            }
            final Float retVal = (Float)method.invoke(null, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, null, refMethod, params);
            return 0.0f;
        }
    }
    
    public static double callDouble(final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return 0.0;
            }
            final Double retVal = (Double)method.invoke(null, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, null, refMethod, params);
            return 0.0;
        }
    }
    
    public static String callString(final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return null;
            }
            final String retVal = (String)method.invoke(null, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, null, refMethod, params);
            return null;
        }
    }
    
    public static Object call(final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return null;
            }
            final Object retVal = method.invoke(null, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, null, refMethod, params);
            return null;
        }
    }
    
    public static void callVoid(final Object obj, final ReflectorMethod refMethod, final Object... params) {
        try {
            if (obj == null) {
                return;
            }
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return;
            }
            method.invoke(obj, params);
        }
        catch (Throwable e) {
            handleException(e, obj, refMethod, params);
        }
    }
    
    public static boolean callBoolean(final Object obj, final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return false;
            }
            final Boolean retVal = (Boolean)method.invoke(obj, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, obj, refMethod, params);
            return false;
        }
    }
    
    public static int callInt(final Object obj, final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return 0;
            }
            final Integer retVal = (Integer)method.invoke(obj, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, obj, refMethod, params);
            return 0;
        }
    }
    
    public static long callLong(final Object obj, final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return 0L;
            }
            final Long retVal = (Long)method.invoke(obj, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, obj, refMethod, params);
            return 0L;
        }
    }
    
    public static float callFloat(final Object obj, final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return 0.0f;
            }
            final Float retVal = (Float)method.invoke(obj, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, obj, refMethod, params);
            return 0.0f;
        }
    }
    
    public static double callDouble(final Object obj, final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return 0.0;
            }
            final Double retVal = (Double)method.invoke(obj, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, obj, refMethod, params);
            return 0.0;
        }
    }
    
    public static String callString(final Object obj, final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return null;
            }
            final String retVal = (String)method.invoke(obj, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, obj, refMethod, params);
            return null;
        }
    }
    
    public static Object call(final Object obj, final ReflectorMethod refMethod, final Object... params) {
        try {
            final Method method = refMethod.getTargetMethod();
            if (method == null) {
                return null;
            }
            final Object retVal = method.invoke(obj, params);
            return retVal;
        }
        catch (Throwable e) {
            handleException(e, obj, refMethod, params);
            return null;
        }
    }
    
    public static Object getFieldValue(final ReflectorField refField) {
        return getFieldValue(null, refField);
    }
    
    public static Object getFieldValue(final Object obj, final ReflectorField refField) {
        try {
            final Field field = refField.getTargetField();
            if (field == null) {
                return null;
            }
            final Object value = field.get(obj);
            return value;
        }
        catch (Throwable e) {
            Log.error("", e);
            return null;
        }
    }
    
    public static boolean getFieldValueBoolean(final Object obj, final ReflectorField refField, final boolean def) {
        try {
            final Field field = refField.getTargetField();
            if (field == null) {
                return def;
            }
            final boolean value = field.getBoolean(obj);
            return value;
        }
        catch (Throwable e) {
            Log.error("", e);
            return def;
        }
    }
    
    public static Object getFieldValue(final ReflectorFields refFields, final int index) {
        final ReflectorField refField = refFields.getReflectorField(index);
        if (refField == null) {
            return null;
        }
        return getFieldValue(refField);
    }
    
    public static Object getFieldValue(final Object obj, final ReflectorFields refFields, final int index) {
        final ReflectorField refField = refFields.getReflectorField(index);
        if (refField == null) {
            return null;
        }
        return getFieldValue(obj, refField);
    }
    
    public static float getFieldValueFloat(final Object obj, final ReflectorField refField, final float def) {
        try {
            final Field field = refField.getTargetField();
            if (field == null) {
                return def;
            }
            final float value = field.getFloat(obj);
            return value;
        }
        catch (Throwable e) {
            Log.error("", e);
            return def;
        }
    }
    
    public static int getFieldValueInt(final ReflectorField refField, final int def) {
        return getFieldValueInt(null, refField, def);
    }
    
    public static int getFieldValueInt(final Object obj, final ReflectorField refField, final int def) {
        try {
            final Field field = refField.getTargetField();
            if (field == null) {
                return def;
            }
            final int value = field.getInt(obj);
            return value;
        }
        catch (Throwable e) {
            Log.error("", e);
            return def;
        }
    }
    
    public static long getFieldValueLong(final Object obj, final ReflectorField refField, final long def) {
        try {
            final Field field = refField.getTargetField();
            if (field == null) {
                return def;
            }
            final long value = field.getLong(obj);
            return value;
        }
        catch (Throwable e) {
            Log.error("", e);
            return def;
        }
    }
    
    public static boolean setFieldValue(final ReflectorField refField, final Object value) {
        return setFieldValue(null, refField, value);
    }
    
    public static boolean setFieldValue(final Object obj, final ReflectorFields refFields, final int index, final Object value) {
        final ReflectorField refField = refFields.getReflectorField(index);
        if (refField == null) {
            return false;
        }
        setFieldValue(obj, refField, value);
        return true;
    }
    
    public static boolean setFieldValue(final Object obj, final ReflectorField refField, final Object value) {
        try {
            final Field field = refField.getTargetField();
            if (field == null) {
                return false;
            }
            field.set(obj, value);
            return true;
        }
        catch (Throwable e) {
            Log.error("", e);
            return false;
        }
    }
    
    public static boolean setFieldValueInt(final ReflectorField refField, final int value) {
        return setFieldValueInt(null, refField, value);
    }
    
    public static boolean setFieldValueInt(final Object obj, final ReflectorField refField, final int value) {
        try {
            final Field field = refField.getTargetField();
            if (field == null) {
                return false;
            }
            field.setInt(obj, value);
            return true;
        }
        catch (Throwable e) {
            Log.error("", e);
            return false;
        }
    }
    
    public static boolean postForgeBusEvent(final ReflectorConstructor constr, final Object... params) {
        final Object event = newInstance(constr, params);
        return event != null && postForgeBusEvent(event);
    }
    
    public static boolean postForgeBusEvent(final Object event) {
        if (event == null) {
            return false;
        }
        final Object eventBus = getFieldValue(Reflector.MinecraftForge_EVENT_BUS);
        if (eventBus == null) {
            return false;
        }
        final Object ret = call(eventBus, Reflector.EventBus_post, event);
        if (!(ret instanceof Boolean)) {
            return false;
        }
        final Boolean retBool = (Boolean)ret;
        return retBool;
    }
    
    public static Object newInstance(final ReflectorConstructor constr, final Object... params) {
        final Constructor c = constr.getTargetConstructor();
        if (c == null) {
            return null;
        }
        try {
            final Object obj = c.newInstance(params);
            return obj;
        }
        catch (Throwable e) {
            handleException(e, constr, params);
            return null;
        }
    }
    
    public static boolean matchesTypes(final Class[] pTypes, final Class[] cTypes) {
        if (pTypes.length != cTypes.length) {
            return false;
        }
        for (int i = 0; i < cTypes.length; ++i) {
            final Class pType = pTypes[i];
            final Class cType = cTypes[i];
            if (pType != cType) {
                return false;
            }
        }
        return true;
    }
    
    private static void dbgCall(final boolean isStatic, final String callType, final ReflectorMethod refMethod, final Object[] params, final Object retVal) {
        final String className = refMethod.getTargetMethod().getDeclaringClass().getName();
        final String methodName = refMethod.getTargetMethod().getName();
        String staticStr = "";
        if (isStatic) {
            staticStr = " static";
        }
        Log.dbg(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;, callType, staticStr, className, methodName, ArrayUtils.arrayToString(params), retVal));
    }
    
    private static void dbgCallVoid(final boolean isStatic, final String callType, final ReflectorMethod refMethod, final Object[] params) {
        final String className = refMethod.getTargetMethod().getDeclaringClass().getName();
        final String methodName = refMethod.getTargetMethod().getName();
        String staticStr = "";
        if (isStatic) {
            staticStr = " static";
        }
        Log.dbg(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, callType, staticStr, className, methodName, ArrayUtils.arrayToString(params)));
    }
    
    private static void dbgFieldValue(final boolean isStatic, final String accessType, final ReflectorField refField, final Object val) {
        final String className = refField.getTargetField().getDeclaringClass().getName();
        final String fieldName = refField.getTargetField().getName();
        String staticStr = "";
        if (isStatic) {
            staticStr = " static";
        }
        Log.dbg(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;, accessType, staticStr, className, fieldName, val));
    }
    
    private static void handleException(final Throwable e, final Object obj, final ReflectorMethod refMethod, final Object[] params) {
        if (!(e instanceof InvocationTargetException)) {
            Log.warn("*** Exception outside of method ***");
            Log.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/reflect/Method;)Ljava/lang/String;, refMethod.getTargetMethod()));
            refMethod.deactivate();
            if (e instanceof IllegalArgumentException) {
                Log.warn("*** IllegalArgumentException ***");
                Log.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/reflect/Method;)Ljava/lang/String;, refMethod.getTargetMethod()));
                Log.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;)Ljava/lang/String;, obj));
                Log.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, ArrayUtils.arrayToString(getClasses(params))));
                Log.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, ArrayUtils.arrayToString(params)));
            }
            Log.warn("", e);
            return;
        }
        final Throwable cause = e.getCause();
        if (cause instanceof RuntimeException) {
            final RuntimeException causeRuntime = (RuntimeException)cause;
            throw causeRuntime;
        }
        Log.error("", e);
    }
    
    private static void handleException(final Throwable e, final ReflectorConstructor refConstr, final Object[] params) {
        if (e instanceof InvocationTargetException) {
            Log.error("", e);
            return;
        }
        Log.warn("*** Exception outside of constructor ***");
        Log.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/reflect/Constructor;)Ljava/lang/String;, refConstr.getTargetConstructor()));
        refConstr.deactivate();
        if (e instanceof IllegalArgumentException) {
            Log.warn("*** IllegalArgumentException ***");
            Log.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/reflect/Constructor;)Ljava/lang/String;, refConstr.getTargetConstructor()));
            Log.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, ArrayUtils.arrayToString(getClasses(params))));
            Log.warn(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, ArrayUtils.arrayToString(params)));
        }
        Log.warn("", e);
    }
    
    private static Object[] getClasses(final Object[] objs) {
        if (objs == null) {
            return new Class[0];
        }
        final Class[] classes = new Class[objs.length];
        for (int i = 0; i < classes.length; ++i) {
            final Object obj = objs[i];
            if (obj != null) {
                classes[i] = obj.getClass();
            }
        }
        return classes;
    }
    
    private static ReflectorField[] getReflectorFields(final ReflectorClass parentClass, final Class fieldType, final int count) {
        final ReflectorField[] rfs = new ReflectorField[count];
        for (int i = 0; i < rfs.length; ++i) {
            rfs[i] = new ReflectorField(parentClass, fieldType, i);
        }
        return rfs;
    }
    
    private static boolean registerResolvable(final String str) {
        final String msg = str;
        final IResolvable ir = new IResolvable(str) {
            @Override
            public void resolve() {
                // 
                // This method could not be decompiled.
                // 
                // Original Bytecode:
                // 
                //     1: getfield        net/optifine/reflect/Reflector$1.val$str:Ljava/lang/String;
                //     4: invokedynamic   BootstrapMethod #0, makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;
                //     9: invokeinterface org/apache/logging/log4j/Logger.info:(Ljava/lang/String;)V
                //    14: return         
                //    15: nop            
                //    16: nop            
                //    17: nop            
                // 
                // The error that occurred was:
                // 
                // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
                //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
                //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
                //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
                //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
                //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
                //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
                //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:776)
                //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
                //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
                //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformCall(AstMethodBodyBuilder.java:1164)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:1009)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:294)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
        };
        ReflectorResolver.register(ir);
        return true;
    }
    
    static {
        LOGGER = LogManager.getLogger();
        Reflector.logForge = registerResolvable("*** Reflector Forge ***");
        Reflector.BrandingControl = new ReflectorClass("net.minecraftforge.internal.BrandingControl");
        Reflector.BrandingControl_getBrandings = new ReflectorMethod(Reflector.BrandingControl, "getBrandings");
        Reflector.BrandingControl_getClientBranding = new ReflectorMethod(Reflector.BrandingControl, "getClientBranding");
        Reflector.BrandingControl_forEachLine = new ReflectorMethod(Reflector.BrandingControl, "forEachLine");
        Reflector.BrandingControl_forEachAboveCopyrightLine = new ReflectorMethod(Reflector.BrandingControl, "forEachAboveCopyrightLine");
        Reflector.IClientBlockExtensions = new ReflectorClass("net.minecraftforge.client.extensions.common.IClientBlockExtensions");
        Reflector.IClientBlockExtensions_ofBS = Reflector.IClientBlockExtensions.makeMethod("of", new Class[] { dcb.class });
        Reflector.IClientItemExtensions = new ReflectorClass("net.minecraftforge.client.extensions.common.IClientItemExtensions");
        Reflector.IClientItemExtensions_ofIS = Reflector.IClientItemExtensions.makeMethod("of", new Class[] { cfz.class });
        Reflector.IClientItemExtensions_ofI = Reflector.IClientItemExtensions.makeMethod("of", new Class[] { cfu.class });
        Reflector.IClientItemExtensions_getFont = Reflector.IClientItemExtensions.makeMethod("getFont");
        Reflector.IClientItemExtensions_FontContext = new ReflectorClass("net.minecraftforge.client.extensions.common.IClientItemExtensions$FontContext");
        Reflector.IClientItemExtensions_FontContext_SELECTED_ITEM_NAME = Reflector.IClientItemExtensions_FontContext.makeField("SELECTED_ITEM_NAME");
        Reflector.CapabilityProvider = new ReflectorClass("net.minecraftforge.common.capabilities.CapabilityProvider");
        Reflector.CapabilityProvider_gatherCapabilities = new ReflectorMethod(Reflector.CapabilityProvider, "gatherCapabilities", new Class[0]);
        Reflector.ClientModLoader = new ReflectorClass("net.minecraftforge.client.loading.ClientModLoader");
        Reflector.ClientModLoader_isLoading = new ReflectorMethod(Reflector.ClientModLoader, "isLoading");
        Reflector.ChunkDataEvent_Save = new ReflectorClass("net.minecraftforge.event.level.ChunkDataEvent$Save");
        Reflector.ChunkDataEvent_Save_Constructor = new ReflectorConstructor(Reflector.ChunkDataEvent_Save, new Class[] { ddx.class, cmn.class, qr.class });
        Reflector.ChunkEvent_Load = new ReflectorClass("net.minecraftforge.event.level.ChunkEvent$Load");
        Reflector.ChunkEvent_Load_Constructor = new ReflectorConstructor(Reflector.ChunkEvent_Load, new Class[] { ddx.class, Boolean.TYPE });
        Reflector.ChunkEvent_Unload = new ReflectorClass("net.minecraftforge.event.level.ChunkEvent$Unload");
        Reflector.ChunkEvent_Unload_Constructor = new ReflectorConstructor(Reflector.ChunkEvent_Unload, new Class[] { ddx.class });
        Reflector.ColorResolverManager = new ReflectorClass("net.minecraftforge.client.ColorResolverManager");
        Reflector.ColorResolverManager_registerBlockTintCaches = Reflector.ColorResolverManager.makeMethod("registerBlockTintCaches");
        Reflector.CrashReportExtender = new ReflectorClass("net.minecraftforge.logging.CrashReportExtender");
        Reflector.CrashReportExtender_addCrashReportHeader = new ReflectorMethod(Reflector.CrashReportExtender, "addCrashReportHeader");
        Reflector.CrashReportExtender_extendSystemReport = new ReflectorMethod(Reflector.CrashReportExtender, "extendSystemReport");
        Reflector.CrashReportExtender_generateEnhancedStackTraceT = new ReflectorMethod(Reflector.CrashReportExtender, "generateEnhancedStackTrace", new Class[] { Throwable.class });
        Reflector.CrashReportExtender_generateEnhancedStackTraceSTE = new ReflectorMethod(Reflector.CrashReportExtender, "generateEnhancedStackTrace", new Class[] { StackTraceElement[].class });
        Reflector.EntityRenderersEvent_AddLayers = new ReflectorClass("net.minecraftforge.client.event.EntityRenderersEvent$AddLayers");
        Reflector.EntityRenderersEvent_AddLayers_Constructor = Reflector.EntityRenderersEvent_AddLayers.makeConstructor(new Class[] { Map.class, Map.class, foy.a.class });
        Reflector.EntityRenderersEvent_CreateSkullModels = new ReflectorClass("net.minecraftforge.client.event.EntityRenderersEvent$CreateSkullModels");
        Reflector.EntityRenderersEvent_CreateSkullModels_Constructor = Reflector.EntityRenderersEvent_CreateSkullModels.makeConstructor(new Class[] { ImmutableMap.Builder.class, fea.class });
        Reflector.EntityLeaveLevelEvent = new ReflectorClass("net.minecraftforge.event.entity.EntityLeaveLevelEvent");
        Reflector.EntityLeaveLevelEvent_Constructor = new ReflectorConstructor(Reflector.EntityLeaveLevelEvent, new Class[] { bfj.class, cmm.class });
        Reflector.ViewportEvent_ComputeCameraAngles = new ReflectorClass("net.minecraftforge.client.event.ViewportEvent$ComputeCameraAngles");
        Reflector.ViewportEvent_ComputeCameraAngles_getYaw = new ReflectorMethod(Reflector.ViewportEvent_ComputeCameraAngles, "getYaw");
        Reflector.ViewportEvent_ComputeCameraAngles_getPitch = new ReflectorMethod(Reflector.ViewportEvent_ComputeCameraAngles, "getPitch");
        Reflector.ViewportEvent_ComputeCameraAngles_getRoll = new ReflectorMethod(Reflector.ViewportEvent_ComputeCameraAngles, "getRoll");
        Reflector.EntityJoinLevelEvent = new ReflectorClass("net.minecraftforge.event.entity.EntityJoinLevelEvent");
        Reflector.EntityJoinLevelEvent_Constructor = new ReflectorConstructor(Reflector.EntityJoinLevelEvent, new Class[] { bfj.class, cmm.class });
        Reflector.Event = new ReflectorClass("net.minecraftforge.eventbus.api.Event");
        Reflector.Event_isCanceled = new ReflectorMethod(Reflector.Event, "isCanceled");
        Reflector.Event_getResult = new ReflectorMethod(Reflector.Event, "getResult");
        Reflector.EventBus = new ReflectorClass("net.minecraftforge.eventbus.api.IEventBus");
        Reflector.EventBus_post = new ReflectorMethod(Reflector.EventBus, "post", new Class[] { Event.class });
        Reflector.Event_Result = new ReflectorClass("net.minecraftforge.eventbus.api.Event$Result");
        Reflector.Event_Result_DENY = new ReflectorField(Reflector.Event_Result, "DENY");
        Reflector.Event_Result_ALLOW = new ReflectorField(Reflector.Event_Result, "ALLOW");
        Reflector.Event_Result_DEFAULT = new ReflectorField(Reflector.Event_Result, "DEFAULT");
        Reflector.FluidType = new ReflectorClass("net.minecraftforge.fluids.FluidType");
        Reflector.FluidType_isAir = Reflector.FluidType.makeMethod("isAir");
        Reflector.ForgeModelBlockRenderer = new ReflectorClass("net.minecraftforge.client.model.lighting.ForgeModelBlockRenderer");
        Reflector.ForgeModelBlockRenderer_Constructor = new ReflectorConstructor(Reflector.ForgeModelBlockRenderer, new Class[] { eoo.class });
        Reflector.ForgeBlockModelShapes = new ReflectorClass(fkn.class);
        Reflector.ForgeBlockModelShapes_getTexture3 = new ReflectorMethod(Reflector.ForgeBlockModelShapes, "getTexture", new Class[] { dcb.class, cmm.class, gu.class });
        Reflector.ForgeBlockElementFace = new ReflectorClass(fkt.class);
        Reflector.ForgeBlockElementFace_getFaceData = Reflector.ForgeBlockElementFace.makeMethod("getFaceData");
        Reflector.IForgeBlockState = new ReflectorClass("net.minecraftforge.common.extensions.IForgeBlockState");
        Reflector.IForgeBlockState_getLightEmission = new ReflectorMethod(Reflector.IForgeBlockState, "getLightEmission", new Class[] { cls.class, gu.class });
        Reflector.IForgeBlockState_getSoundType3 = new ReflectorMethod(Reflector.IForgeBlockState, "getSoundType", new Class[] { cmp.class, gu.class, bfj.class });
        Reflector.IForgeBlockState_getStateAtViewpoint = new ReflectorMethod(Reflector.IForgeBlockState, "getStateAtViewpoint");
        Reflector.IForgeBlockState_shouldDisplayFluidOverlay = new ReflectorMethod(Reflector.IForgeBlockState, "shouldDisplayFluidOverlay");
        Reflector.IForgeEntity = new ReflectorClass("net.minecraftforge.common.extensions.IForgeEntity");
        Reflector.IForgeEntity_canUpdate = new ReflectorMethod(Reflector.IForgeEntity, "canUpdate", new Class[0]);
        Reflector.IForgeEntity_getEyeInFluidType = new ReflectorMethod(Reflector.IForgeEntity, "getEyeInFluidType");
        Reflector.IForgeEntity_getParts = new ReflectorMethod(Reflector.IForgeEntity, "getParts");
        Reflector.IForgeEntity_hasCustomOutlineRendering = new ReflectorMethod(Reflector.IForgeEntity, "hasCustomOutlineRendering");
        Reflector.IForgeEntity_isMultipartEntity = new ReflectorMethod(Reflector.IForgeEntity, "isMultipartEntity");
        Reflector.IForgeEntity_onAddedToWorld = new ReflectorMethod(Reflector.IForgeEntity, "onAddedToWorld");
        Reflector.IForgeEntity_onRemovedFromWorld = new ReflectorMethod(Reflector.IForgeEntity, "onRemovedFromWorld");
        Reflector.IForgeEntity_shouldRiderSit = new ReflectorMethod(Reflector.IForgeEntity, "shouldRiderSit");
        Reflector.IForgePlayer = new ReflectorClass("net.minecraftforge.common.extensions.IForgePlayer");
        Reflector.IForgePlayer_getEntityReach = Reflector.IForgePlayer.makeMethod("getEntityReach");
        Reflector.IForgePlayer_getBlockReach = Reflector.IForgePlayer.makeMethod("getBlockReach");
        Reflector.ForgeChunkHolder = new ReflectorClass(ahp.class);
        Reflector.ForgeChunkHolder_currentlyLoading = new ReflectorField(Reflector.ForgeChunkHolder, "currentlyLoading");
        Reflector.ForgeEventFactory = new ReflectorClass("net.minecraftforge.event.ForgeEventFactory");
        Reflector.ForgeEventFactory_canEntityDespawn = new ReflectorMethod(Reflector.ForgeEventFactory, "canEntityDespawn");
        Reflector.ForgeEventFactory_fireChunkTicketLevelUpdated = new ReflectorMethod(Reflector.ForgeEventFactory, "fireChunkTicketLevelUpdated");
        Reflector.ForgeEventFactory_fireChunkWatch = new ReflectorMethod(Reflector.ForgeEventFactory, "fireChunkWatch");
        Reflector.ForgeEventFactory_fireChunkUnWatch = new ReflectorMethod(Reflector.ForgeEventFactory, "fireChunkUnWatch");
        Reflector.ForgeEventFactory_getMaxSpawnPackSize = new ReflectorMethod(Reflector.ForgeEventFactory, "getMaxSpawnPackSize");
        Reflector.ForgeEventFactory_getMobGriefingEvent = new ReflectorMethod(Reflector.ForgeEventFactory, "getMobGriefingEvent");
        Reflector.ForgeEventFactory_onPlaySoundAtEntity = new ReflectorMethod(Reflector.ForgeEventFactory, "onPlaySoundAtEntity");
        Reflector.ForgeEventFactory_onPlaySoundAtPosition = new ReflectorMethod(Reflector.ForgeEventFactory, "onPlaySoundAtPosition");
        Reflector.ForgeHooks = new ReflectorClass("net.minecraftforge.common.ForgeHooks");
        Reflector.ForgeHooks_onDifficultyChange = new ReflectorMethod(Reflector.ForgeHooks, "onDifficultyChange");
        Reflector.ForgeHooks_onLivingAttack = new ReflectorMethod(Reflector.ForgeHooks, "onLivingAttack");
        Reflector.ForgeHooks_onLivingChangeTarget = new ReflectorMethod(Reflector.ForgeHooks, "onLivingChangeTarget");
        Reflector.ForgeHooks_onLivingDeath = new ReflectorMethod(Reflector.ForgeHooks, "onLivingDeath");
        Reflector.ForgeHooks_onLivingDrops = new ReflectorMethod(Reflector.ForgeHooks, "onLivingDrops");
        Reflector.ForgeHooks_onLivingFall = new ReflectorMethod(Reflector.ForgeHooks, "onLivingFall");
        Reflector.ForgeHooks_onLivingHurt = new ReflectorMethod(Reflector.ForgeHooks, "onLivingHurt");
        Reflector.ForgeHooks_onLivingJump = new ReflectorMethod(Reflector.ForgeHooks, "onLivingJump");
        Reflector.ForgeHooksClient = new ReflectorClass("net.minecraftforge.client.ForgeHooksClient");
        Reflector.ForgeHooksClient_calculateFaceWithoutAO = new ReflectorMethod(Reflector.ForgeHooksClient, "calculateFaceWithoutAO");
        Reflector.ForgeHooksClient_onCustomizeBossEventProgress = new ReflectorMethod(Reflector.ForgeHooksClient, "onCustomizeBossEventProgress");
        Reflector.ForgeHooksClient_onRenderTooltipColor = new ReflectorMethod(Reflector.ForgeHooksClient, "onRenderTooltipColor");
        Reflector.ForgeHooksClient_dispatchRenderStageS = new ReflectorMethod(Reflector.ForgeHooksClient, "dispatchRenderStage", new Class[] { RenderLevelStageEvent.Stage.class, fjv.class, eij.class, Matrix4f.class, Integer.TYPE, emz.class, fmw.class });
        Reflector.ForgeHooksClient_dispatchRenderStageRT = new ReflectorMethod(Reflector.ForgeHooksClient, "dispatchRenderStage", new Class[] { fkf.class, fjv.class, eij.class, Matrix4f.class, Integer.TYPE, emz.class, fmw.class });
        Reflector.ForgeHooksClient_drawScreen = new ReflectorMethod(Reflector.ForgeHooksClient, "drawScreen");
        Reflector.ForgeHooksClient_fillNormal = new ReflectorMethod(Reflector.ForgeHooksClient, "fillNormal");
        Reflector.ForgeHooksClient_gatherTooltipComponents6 = new ReflectorMethod(Reflector.ForgeHooksClient, "gatherTooltipComponents", new Class[] { cfz.class, List.class, Integer.TYPE, Integer.TYPE, Integer.TYPE, eov.class });
        Reflector.ForgeHooksClient_gatherTooltipComponents7 = new ReflectorMethod(Reflector.ForgeHooksClient, "gatherTooltipComponents", new Class[] { cfz.class, List.class, Optional.class, Integer.TYPE, Integer.TYPE, Integer.TYPE, eov.class });
        Reflector.ForgeHooksClient_onKeyInput = new ReflectorMethod(Reflector.ForgeHooksClient, "onKeyInput");
        Reflector.ForgeHooksClient_getFogColor = new ReflectorMethod(Reflector.ForgeHooksClient, "getFogColor");
        Reflector.ForgeHooksClient_handleCameraTransforms = new ReflectorMethod(Reflector.ForgeHooksClient, "handleCameraTransforms");
        Reflector.ForgeHooksClient_getArmorModel = new ReflectorMethod(Reflector.ForgeHooksClient, "getArmorModel");
        Reflector.ForgeHooksClient_getArmorTexture = new ReflectorMethod(Reflector.ForgeHooksClient, "getArmorTexture");
        Reflector.ForgeHooksClient_getFluidSprites = new ReflectorMethod(Reflector.ForgeHooksClient, "getFluidSprites");
        Reflector.ForgeHooksClient_getFieldOfViewModifier = new ReflectorMethod(Reflector.ForgeHooksClient, "getFieldOfViewModifier");
        Reflector.ForgeHooksClient_getFieldOfView = new ReflectorMethod(Reflector.ForgeHooksClient, "getFieldOfView");
        Reflector.ForgeHooksClient_getGuiFarPlane = new ReflectorMethod(Reflector.ForgeHooksClient, "getGuiFarPlane");
        Reflector.ForgeHooksClient_getShaderImportLocation = new ReflectorMethod(Reflector.ForgeHooksClient, "getShaderImportLocation");
        Reflector.ForgeHooksClient_isNameplateInRenderDistance = new ReflectorMethod(Reflector.ForgeHooksClient, "isNameplateInRenderDistance");
        Reflector.ForgeHooksClient_loadEntityShader = new ReflectorMethod(Reflector.ForgeHooksClient, "loadEntityShader");
        Reflector.ForgeHooksClient_loadTextureAtlasSprite = new ReflectorMethod(Reflector.ForgeHooksClient, "loadTextureAtlasSprite");
        Reflector.ForgeHooksClient_loadSpriteContents = new ReflectorMethod(Reflector.ForgeHooksClient, "loadSpriteContents");
        Reflector.ForgeHooksClient_makeParticleRenderTypeComparator = new ReflectorMethod(Reflector.ForgeHooksClient, "makeParticleRenderTypeComparator");
        Reflector.ForgeHooksClient_onCameraSetup = new ReflectorMethod(Reflector.ForgeHooksClient, "onCameraSetup");
        Reflector.ForgeHooksClient_onDrawHighlight = new ReflectorMethod(Reflector.ForgeHooksClient, "onDrawHighlight");
        Reflector.ForgeHooksClient_onFogRender = new ReflectorMethod(Reflector.ForgeHooksClient, "onFogRender");
        Reflector.ForgeHooksClient_onRegisterAdditionalModels = new ReflectorMethod(Reflector.ForgeHooksClient, "onRegisterAdditionalModels");
        Reflector.ForgeHooksClient_onRenderTooltipPre = new ReflectorMethod(Reflector.ForgeHooksClient, "onRenderTooltipPre");
        Reflector.ForgeHooksClient_onScreenCharTypedPre = new ReflectorMethod(Reflector.ForgeHooksClient, "onScreenCharTypedPre");
        Reflector.ForgeHooksClient_onScreenCharTypedPost = new ReflectorMethod(Reflector.ForgeHooksClient, "onScreenCharTypedPost");
        Reflector.ForgeHooksClient_onScreenKeyPressedPre = new ReflectorMethod(Reflector.ForgeHooksClient, "onScreenKeyPressedPre");
        Reflector.ForgeHooksClient_onScreenKeyPressedPost = new ReflectorMethod(Reflector.ForgeHooksClient, "onScreenKeyPressedPost");
        Reflector.ForgeHooksClient_onScreenKeyReleasedPre = new ReflectorMethod(Reflector.ForgeHooksClient, "onScreenKeyReleasedPre");
        Reflector.ForgeHooksClient_onScreenKeyReleasedPost = new ReflectorMethod(Reflector.ForgeHooksClient, "onScreenKeyReleasedPost");
        Reflector.ForgeHooksClient_onScreenshot = new ReflectorMethod(Reflector.ForgeHooksClient, "onScreenshot");
        Reflector.ForgeHooksClient_onTextureStitchedPost = new ReflectorMethod(Reflector.ForgeHooksClient, "onTextureStitchedPost");
        Reflector.ForgeHooksClient_renderBlockOverlay = new ReflectorMethod(Reflector.ForgeHooksClient, "renderBlockOverlay");
        Reflector.ForgeHooksClient_renderFireOverlay = new ReflectorMethod(Reflector.ForgeHooksClient, "renderFireOverlay");
        Reflector.ForgeHooksClient_renderWaterOverlay = new ReflectorMethod(Reflector.ForgeHooksClient, "renderWaterOverlay");
        Reflector.ForgeHooksClient_renderMainMenu = new ReflectorMethod(Reflector.ForgeHooksClient, "renderMainMenu");
        Reflector.ForgeHooksClient_renderSpecificFirstPersonHand = new ReflectorMethod(Reflector.ForgeHooksClient, "renderSpecificFirstPersonHand");
        Reflector.ForgeHooksClient_shouldCauseReequipAnimation = new ReflectorMethod(Reflector.ForgeHooksClient, "shouldCauseReequipAnimation");
        Reflector.ForgeConfig = new ReflectorClass("net.minecraftforge.common.ForgeConfig");
        Reflector.ForgeConfig_CLIENT = new ReflectorField(Reflector.ForgeConfig, "CLIENT");
        Reflector.ForgeConfig_Client = new ReflectorClass("net.minecraftforge.common.ForgeConfig$Client");
        Reflector.ForgeConfig_Client_forgeLightPipelineEnabled = new ReflectorField(Reflector.ForgeConfig_Client, "experimentalForgeLightPipelineEnabled");
        Reflector.ForgeConfig_Client_useCombinedDepthStencilAttachment = new ReflectorField(Reflector.ForgeConfig_Client, "useCombinedDepthStencilAttachment");
        Reflector.ForgeConfigSpec = new ReflectorClass("net.minecraftforge.common.ForgeConfigSpec");
        Reflector.ForgeConfigSpec_childConfig = new ReflectorField(Reflector.ForgeConfigSpec, "childConfig");
        Reflector.ForgeConfigSpec_ConfigValue = new ReflectorClass("net.minecraftforge.common.ForgeConfigSpec$ConfigValue");
        Reflector.ForgeConfigSpec_ConfigValue_defaultSupplier = new ReflectorField(Reflector.ForgeConfigSpec_ConfigValue, "defaultSupplier");
        Reflector.ForgeConfigSpec_ConfigValue_spec = new ReflectorField(Reflector.ForgeConfigSpec_ConfigValue, "spec");
        Reflector.ForgeConfigSpec_ConfigValue_get = new ReflectorMethod(Reflector.ForgeConfigSpec_ConfigValue, "get");
        Reflector.ForgeIChunk = new ReflectorClass(ddx.class);
        Reflector.ForgeIChunk_getWorldForge = new ReflectorMethod(Reflector.ForgeIChunk, "getWorldForge");
        Reflector.IForgeItem = new ReflectorClass("net.minecraftforge.common.extensions.IForgeItem");
        Reflector.IForgeItem_getEquipmentSlot = new ReflectorMethod(Reflector.IForgeItem, "getEquipmentSlot");
        Reflector.IForgeItem_isDamageable1 = new ReflectorMethod(Reflector.IForgeItem, "isDamageable", new Class[] { cfz.class });
        Reflector.IForgeItem_onEntitySwing = new ReflectorMethod(Reflector.IForgeItem, "onEntitySwing");
        Reflector.IForgeItem_shouldCauseReequipAnimation = new ReflectorMethod(Reflector.IForgeItem, "shouldCauseReequipAnimation");
        Reflector.IForgeItemStack = new ReflectorClass("net.minecraftforge.common.extensions.IForgeItemStack");
        Reflector.IForgeItemStack_canDisableShield = new ReflectorMethod(Reflector.IForgeItemStack, "canDisableShield");
        Reflector.IForgeItemStack_getEquipmentSlot = new ReflectorMethod(Reflector.IForgeItemStack, "getEquipmentSlot");
        Reflector.IForgeItemStack_getShareTag = new ReflectorMethod(Reflector.IForgeItemStack, "getShareTag");
        Reflector.IForgeItemStack_getHighlightTip = new ReflectorMethod(Reflector.IForgeItemStack, "getHighlightTip");
        Reflector.IForgeItemStack_readShareTag = new ReflectorMethod(Reflector.IForgeItemStack, "readShareTag");
        Reflector.ForgeItemTags = new ReflectorClass(ane.class);
        Reflector.ForgeItemTags_create = Reflector.ForgeItemTags.makeMethod("create", new Class[] { acq.class });
        Reflector.ForgeI18n = new ReflectorClass("net.minecraftforge.common.ForgeI18n");
        Reflector.ForgeI18n_loadLanguageData = new ReflectorMethod(Reflector.ForgeI18n, "loadLanguageData");
        Reflector.ForgeKeyBinding = new ReflectorClass(enl.class);
        Reflector.ForgeKeyBinding_setKeyConflictContext = new ReflectorMethod(Reflector.ForgeKeyBinding, "setKeyConflictContext");
        Reflector.ForgeKeyBinding_setKeyModifierAndCode = new ReflectorMethod(Reflector.ForgeKeyBinding, "setKeyModifierAndCode");
        Reflector.ForgeKeyBinding_getKeyModifier = new ReflectorMethod(Reflector.ForgeKeyBinding, "getKeyModifier");
        Reflector.ForgeMapDecoration = new ReflectorClass(dyl.class);
        Reflector.ForgeMapDecoration_render = Reflector.ForgeMapDecoration.makeMethod("render");
        Reflector.ForgeSnapshotsMod = new ReflectorClass("net.minecraftforge.forge.snapshots.ForgeSnapshotsMod");
        Reflector.ForgeSnapshotsMod_processOptions = Reflector.ForgeSnapshotsMod.makeMethod("processOptions");
        Reflector.ForgeRarity = new ReflectorClass(cgq.class);
        Reflector.ForgeRarity_getStyleModifier = Reflector.ForgeRarity.makeMethod("getStyleModifier");
        Reflector.ForgeTicket = new ReflectorClass(aij.class);
        Reflector.ForgeTicket_forceTicks = Reflector.ForgeTicket.makeField("forceTicks");
        Reflector.ForgeTicket_isForceTicks = Reflector.ForgeTicket.makeMethod("isForceTicks");
        Reflector.IForgeBlockEntity = new ReflectorClass("net.minecraftforge.common.extensions.IForgeBlockEntity");
        Reflector.IForgeBlockEntity_getRenderBoundingBox = new ReflectorMethod(Reflector.IForgeBlockEntity, "getRenderBoundingBox");
        Reflector.IForgeBlockEntity_hasCustomOutlineRendering = new ReflectorMethod(Reflector.IForgeBlockEntity, "hasCustomOutlineRendering");
        Reflector.IForgeDimensionSpecialEffects = new ReflectorClass("net.minecraftforge.client.extensions.IForgeDimensionSpecialEffects");
        Reflector.IForgeDimensionSpecialEffects_adjustLightmapColors = Reflector.IForgeDimensionSpecialEffects.makeMethod("adjustLightmapColors");
        Reflector.IForgeDimensionSpecialEffects_renderClouds = Reflector.IForgeDimensionSpecialEffects.makeMethod("renderClouds");
        Reflector.IForgeDimensionSpecialEffects_renderSky = Reflector.IForgeDimensionSpecialEffects.makeMethod("renderSky");
        Reflector.IForgeDimensionSpecialEffects_tickRain = Reflector.IForgeDimensionSpecialEffects.makeMethod("tickRain");
        Reflector.IForgeDimensionSpecialEffects_renderSnowAndRain = Reflector.IForgeDimensionSpecialEffects.makeMethod("renderSnowAndRain");
        Reflector.ForgeVersion = new ReflectorClass("net.minecraftforge.versions.forge.ForgeVersion");
        Reflector.ForgeVersion_getVersion = Reflector.ForgeVersion.makeMethod("getVersion");
        Reflector.ForgeVersion_getSpec = Reflector.ForgeVersion.makeMethod("getSpec");
        Reflector.ImmediateWindowHandler = new ReflectorClass("net.minecraftforge.fml.loading.ImmediateWindowHandler");
        Reflector.ImmediateWindowHandler_positionWindow = Reflector.ImmediateWindowHandler.makeMethod("positionWindow");
        Reflector.ImmediateWindowHandler_setupMinecraftWindow = Reflector.ImmediateWindowHandler.makeMethod("setupMinecraftWindow");
        Reflector.ImmediateWindowHandler_updateFBSize = Reflector.ImmediateWindowHandler.makeMethod("updateFBSize");
        Reflector.ItemDecoratorHandler = new ReflectorClass("net.minecraftforge.client.ItemDecoratorHandler");
        Reflector.ItemDecoratorHandler_of = Reflector.ItemDecoratorHandler.makeMethod("of", new Class[] { cfz.class });
        Reflector.ItemDecoratorHandler_render = Reflector.ItemDecoratorHandler.makeMethod("render");
        Reflector.ForgeItemModelShaper = new ReflectorClass("net.minecraftforge.client.model.ForgeItemModelShaper");
        Reflector.ForgeItemModelShaper_Constructor = new ReflectorConstructor(Reflector.ForgeItemModelShaper, new Class[] { fwx.class });
        Reflector.GeometryLoaderManager = new ReflectorClass("net.minecraftforge.client.model.geometry.GeometryLoaderManager");
        Reflector.GeometryLoaderManager_init = Reflector.GeometryLoaderManager.makeMethod("init");
        Reflector.KeyConflictContext = new ReflectorClass("net.minecraftforge.client.settings.KeyConflictContext");
        Reflector.KeyConflictContext_IN_GAME = new ReflectorField(Reflector.KeyConflictContext, "IN_GAME");
        Reflector.KeyModifier = new ReflectorClass("net.minecraftforge.client.settings.KeyModifier");
        Reflector.KeyModifier_valueFromString = new ReflectorMethod(Reflector.KeyModifier, "valueFromString");
        Reflector.KeyModifier_NONE = new ReflectorField(Reflector.KeyModifier, "NONE");
        Reflector.Launch = new ReflectorClass("net.minecraft.launchwrapper.Launch");
        Reflector.Launch_blackboard = new ReflectorField(Reflector.Launch, "blackboard");
        Reflector.MinecraftForge = new ReflectorClass("net.minecraftforge.common.MinecraftForge");
        Reflector.MinecraftForge_EVENT_BUS = new ReflectorField(Reflector.MinecraftForge, "EVENT_BUS");
        Reflector.ModContainer = new ReflectorClass("net.minecraftforge.fml.ModContainer");
        Reflector.ModContainer_getModId = new ReflectorMethod(Reflector.ModContainer, "getModId");
        Reflector.ModList = new ReflectorClass("net.minecraftforge.fml.ModList");
        Reflector.ModList_mods = Reflector.ModList.makeField("mods");
        Reflector.ModList_get = Reflector.ModList.makeMethod("get");
        Reflector.ModListScreen = new ReflectorClass("net.minecraftforge.client.gui.ModListScreen");
        Reflector.ModListScreen_Constructor = new ReflectorConstructor(Reflector.ModListScreen, new Class[] { euq.class });
        Reflector.ModLoader = new ReflectorClass("net.minecraftforge.fml.ModLoader");
        Reflector.ModLoader_get = Reflector.ModLoader.makeMethod("get");
        Reflector.ModLoader_postEvent = Reflector.ModLoader.makeMethod("postEvent");
        Reflector.TitleScreenModUpdateIndicator = new ReflectorClass("net.minecraftforge.client.gui.TitleScreenModUpdateIndicator");
        Reflector.TitleScreenModUpdateIndicator_init = Reflector.TitleScreenModUpdateIndicator.makeMethod("init", new Class[] { euw.class, epi.class });
        Reflector.PartEntity = new ReflectorClass("net.minecraftforge.entity.PartEntity");
        Reflector.PlayLevelSoundEvent = new ReflectorClass("net.minecraftforge.event.PlayLevelSoundEvent");
        Reflector.PlayLevelSoundEvent_getSound = new ReflectorMethod(Reflector.PlayLevelSoundEvent, "getSound");
        Reflector.PlayLevelSoundEvent_getSource = new ReflectorMethod(Reflector.PlayLevelSoundEvent, "getSource");
        Reflector.PlayLevelSoundEvent_getNewVolume = new ReflectorMethod(Reflector.PlayLevelSoundEvent, "getNewVolume");
        Reflector.PlayLevelSoundEvent_getNewPitch = new ReflectorMethod(Reflector.PlayLevelSoundEvent, "getNewPitch");
        Reflector.QuadBakingVertexConsumer = new ReflectorClass("net.minecraftforge.client.model.pipeline.QuadBakingVertexConsumer");
        Reflector.QuadBakingVertexConsumer_QUAD_DATA_SIZE = Reflector.QuadBakingVertexConsumer.makeField("QUAD_DATA_SIZE");
        Reflector.QuadTransformers = new ReflectorClass("net.minecraftforge.client.model.QuadTransformers");
        Reflector.QuadTransformers_applyingLightmap = Reflector.QuadTransformers.makeMethod("applyingLightmap", new Class[] { Integer.TYPE, Integer.TYPE });
        Reflector.QuadTransformers_applyingColor = Reflector.QuadTransformers.makeMethod("applyingColor", new Class[] { Integer.TYPE });
        Reflector.IQuadTransformer = new ReflectorClass("net.minecraftforge.client.model.IQuadTransformer");
        Reflector.IQuadTransformer_STRIDE = Reflector.IQuadTransformer.makeField("STRIDE");
        Reflector.IQuadTransformer_processInPlace = Reflector.IQuadTransformer.makeMethod("processInPlace", new Class[] { fkr.class });
        Reflector.RegisterShadersEvent = new ReflectorClass("net.minecraftforge.client.event.RegisterShadersEvent");
        Reflector.RegisterShadersEvent_Constructor = Reflector.RegisterShadersEvent.makeConstructor(new Class[] { ala.class, List.class });
        Reflector.RenderBlockScreenEffectEvent_OverlayType = new ReflectorClass("net.minecraftforge.client.event.RenderBlockScreenEffectEvent$OverlayType");
        Reflector.RenderBlockScreenEffectEvent_OverlayType_BLOCK = new ReflectorField(Reflector.RenderBlockScreenEffectEvent_OverlayType, "BLOCK");
        Reflector.CustomizeGuiOverlayEvent_BossEventProgress = new ReflectorClass("net.minecraftforge.client.event.CustomizeGuiOverlayEvent$BossEventProgress");
        Reflector.CustomizeGuiOverlayEvent_BossEventProgress_getIncrement = Reflector.CustomizeGuiOverlayEvent_BossEventProgress.makeMethod("getIncrement");
        Reflector.RenderItemInFrameEvent = new ReflectorClass("net.minecraftforge.client.event.RenderItemInFrameEvent");
        Reflector.RenderItemInFrameEvent_Constructor = new ReflectorConstructor(Reflector.RenderItemInFrameEvent, new Class[] { bva.class, fpv.class, eij.class, fjx.class, Integer.TYPE });
        Reflector.RenderLevelStageEvent_Stage = new ReflectorClass(RenderLevelStageEvent.Stage.class);
        Reflector.RenderLevelStageEvent_Stage_AFTER_SKY = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_SKY");
        Reflector.RenderLevelStageEvent_Stage_AFTER_SOLID_BLOCKS = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_SOLID_BLOCKS");
        Reflector.RenderLevelStageEvent_Stage_AFTER_CUTOUT_MIPPED_BLOCKS_BLOCKS = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_CUTOUT_MIPPED_BLOCKS_BLOCKS");
        Reflector.RenderLevelStageEvent_Stage_AFTER_CUTOUT_BLOCKS = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_CUTOUT_BLOCKS");
        Reflector.RenderLevelStageEvent_Stage_AFTER_ENTITIES = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_ENTITIES");
        Reflector.RenderLevelStageEvent_Stage_AFTER_BLOCK_ENTITIES = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_BLOCK_ENTITIES");
        Reflector.RenderLevelStageEvent_Stage_AFTER_TRANSLUCENT_BLOCKS = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_TRANSLUCENT_BLOCKS");
        Reflector.RenderLevelStageEvent_Stage_AFTER_TRIPWIRE_BLOCKS = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_TRIPWIRE_BLOCKS");
        Reflector.RenderLevelStageEvent_Stage_AFTER_PARTICLES = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_PARTICLES");
        Reflector.RenderLevelStageEvent_Stage_AFTER_WEATHER = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_WEATHER");
        Reflector.RenderLevelStageEvent_Stage_AFTER_LEVEL = Reflector.RenderLevelStageEvent_Stage.makeField("AFTER_LEVEL");
        Reflector.RenderLivingEvent_Pre = new ReflectorClass("net.minecraftforge.client.event.RenderLivingEvent$Pre");
        Reflector.RenderLivingEvent_Pre_Constructor = new ReflectorConstructor(Reflector.RenderLivingEvent_Pre, new Class[] { bfz.class, fpz.class, Float.TYPE, eij.class, fjx.class, Integer.TYPE });
        Reflector.RenderLivingEvent_Post = new ReflectorClass("net.minecraftforge.client.event.RenderLivingEvent$Post");
        Reflector.RenderLivingEvent_Post_Constructor = new ReflectorConstructor(Reflector.RenderLivingEvent_Post, new Class[] { bfz.class, fpz.class, Float.TYPE, eij.class, fjx.class, Integer.TYPE });
        Reflector.RenderNameTagEvent = new ReflectorClass("net.minecraftforge.client.event.RenderNameTagEvent");
        Reflector.RenderNameTagEvent_Constructor = new ReflectorConstructor(Reflector.RenderNameTagEvent, new Class[] { bfj.class, sw.class, fox.class, eij.class, fjx.class, Integer.TYPE, Float.TYPE });
        Reflector.RenderNameTagEvent_getContent = new ReflectorMethod(Reflector.RenderNameTagEvent, "getContent");
        Reflector.RenderTooltipEvent = new ReflectorClass("net.minecraftforge.client.event.RenderTooltipEvent");
        Reflector.RenderTooltipEvent_getFont = Reflector.RenderTooltipEvent.makeMethod("getFont");
        Reflector.RenderTooltipEvent_getX = Reflector.RenderTooltipEvent.makeMethod("getX");
        Reflector.RenderTooltipEvent_getY = Reflector.RenderTooltipEvent.makeMethod("getY");
        Reflector.RenderTooltipEvent_Color = new ReflectorClass("net.minecraftforge.client.event.RenderTooltipEvent$Color");
        Reflector.RenderTooltipEvent_Color_getBackgroundStart = Reflector.RenderTooltipEvent_Color.makeMethod("getBackgroundStart");
        Reflector.RenderTooltipEvent_Color_getBackgroundEnd = Reflector.RenderTooltipEvent_Color.makeMethod("getBackgroundEnd");
        Reflector.RenderTooltipEvent_Color_getBorderStart = Reflector.RenderTooltipEvent_Color.makeMethod("getBorderStart");
        Reflector.RenderTooltipEvent_Color_getBorderEnd = Reflector.RenderTooltipEvent_Color.makeMethod("getBorderEnd");
        Reflector.ScreenshotEvent = new ReflectorClass("net.minecraftforge.client.event.ScreenshotEvent");
        Reflector.ScreenshotEvent_getCancelMessage = new ReflectorMethod(Reflector.ScreenshotEvent, "getCancelMessage");
        Reflector.ScreenshotEvent_getScreenshotFile = new ReflectorMethod(Reflector.ScreenshotEvent, "getScreenshotFile");
        Reflector.ScreenshotEvent_getResultMessage = new ReflectorMethod(Reflector.ScreenshotEvent, "getResultMessage");
        Reflector.ServerLifecycleHooks = new ReflectorClass("net.minecraftforge.server.ServerLifecycleHooks");
        Reflector.ServerLifecycleHooks_handleServerAboutToStart = new ReflectorMethod(Reflector.ServerLifecycleHooks, "handleServerAboutToStart");
        Reflector.ServerLifecycleHooks_handleServerStarting = new ReflectorMethod(Reflector.ServerLifecycleHooks, "handleServerStarting");
        Reflector.TerrainParticle = new ReflectorClass(fil.class);
        Reflector.TerrainParticle_updateSprite = Reflector.TerrainParticle.makeMethod("updateSprite");
        Reflector.TooltipRenderUtil = new ReflectorClass(exl.class);
        Reflector.TooltipRenderUtil_renderTooltipBackground10 = Reflector.TooltipRenderUtil.makeMethod("renderTooltipBackground");
        Reflector.LevelEvent_Load = new ReflectorClass("net.minecraftforge.event.level.LevelEvent$Load");
        Reflector.LevelEvent_Load_Constructor = new ReflectorConstructor(Reflector.LevelEvent_Load, new Class[] { cmn.class });
        Reflector.logVanilla = registerResolvable("*** Reflector Vanilla ***");
        Reflector.AbstractArrow = new ReflectorClass(byu.class);
        Reflector.AbstractArrow_inGround = new ReflectorField(new FieldLocatorTypes(byu.class, new Class[] { dcb.class }, Boolean.TYPE, new Class[] { Integer.TYPE }, "AbstractArrow.inGround"));
        Reflector.EntityItem = new ReflectorClass(bvh.class);
        Reflector.EntityItem_ITEM = new ReflectorField(Reflector.EntityItem, aby.class);
        Reflector.EnderDragonRenderer = new ReflectorClass(fot.class);
        Reflector.EnderDragonRenderer_model = new ReflectorField(Reflector.EnderDragonRenderer, fot.a.class);
        Reflector.GuiEnchantment = new ReflectorClass(ewi.class);
        Reflector.GuiEnchantment_bookModel = new ReflectorField(Reflector.GuiEnchantment, fao.class);
        Reflector.ItemOverride = new ReflectorClass(fla.class);
        Reflector.ItemOverride_listResourceValues = new ReflectorField(Reflector.ItemOverride, List.class);
        Reflector.LayerLlamaDecor = new ReflectorClass(fta.class);
        Reflector.LayerLlamaDecor_model = new ReflectorField(Reflector.LayerLlamaDecor, fby.class);
        Reflector.Minecraft = new ReflectorClass(enn.class);
        Reflector.Minecraft_debugFPS = new ReflectorField(new FieldLocatorTypes(enn.class, new Class[] { Supplier.class }, Integer.TYPE, new Class[] { String.class }, "debugFPS"));
        Reflector.Minecraft_fontResourceManager = new ReflectorField(Reflector.Minecraft, erm.class);
        Reflector.ModelArmorStand = new ReflectorClass(fai.class);
        Reflector.ModelArmorStand_ModelRenderers = new ReflectorFields(Reflector.ModelArmorStand, fee.class, 4);
        Reflector.ModelBee = new ReflectorClass(fal.class);
        Reflector.ModelBee_ModelRenderers = new ReflectorFields(Reflector.ModelBee, fee.class, 2);
        Reflector.ModelBlaze = new ReflectorClass(fam.class);
        Reflector.ModelBlaze_blazeHead = new ReflectorField(Reflector.ModelBlaze, fee.class);
        Reflector.ModelBlaze_blazeSticks = new ReflectorField(Reflector.ModelBlaze, fee[].class);
        Reflector.ModelBoar = new ReflectorClass(fbp.class);
        Reflector.ModelBoar_ModelRenderers = new ReflectorFields(Reflector.ModelBoar, fee.class, 9);
        Reflector.ModelBook = new ReflectorClass(fao.class);
        Reflector.ModelBook_root = new ReflectorField(Reflector.ModelBook, fee.class);
        Reflector.ModelChicken = new ReflectorClass(fau.class);
        Reflector.ModelChicken_ModelRenderers = new ReflectorFields(Reflector.ModelChicken, fee.class, 8);
        Reflector.ModelDragon = new ReflectorClass(fot.a.class);
        Reflector.ModelDragon_ModelRenderers = new ReflectorFields(Reflector.ModelDragon, fee.class, 20);
        Reflector.RenderEnderCrystal = new ReflectorClass(fos.class);
        Reflector.RenderEnderCrystal_modelRenderers = new ReflectorFields(Reflector.RenderEnderCrystal, fee.class, 3);
        Reflector.ModelEvokerFangs = new ReflectorClass(fbg.class);
        Reflector.ModelEvokerFangs_ModelRenderers = new ReflectorFields(Reflector.ModelEvokerFangs, fee.class, 3);
        Reflector.ModelGuardian = new ReflectorClass(fbm.class);
        Reflector.ModelGuardian_spines = new ReflectorField(Reflector.ModelGuardian, fee[].class, 0);
        Reflector.ModelGuardian_tail = new ReflectorField(Reflector.ModelGuardian, fee[].class, 1);
        Reflector.ModelDragonHead = new ReflectorClass(fdy.class);
        Reflector.ModelDragonHead_head = new ReflectorField(Reflector.ModelDragonHead, fee.class, 0);
        Reflector.ModelDragonHead_jaw = new ReflectorField(Reflector.ModelDragonHead, fee.class, 1);
        Reflector.ModelHorse = new ReflectorClass(fbq.class);
        Reflector.ModelHorse_ModelRenderers = new ReflectorFields(Reflector.ModelHorse, fee.class, 11);
        Reflector.ModelHorseChests = new ReflectorClass(fat.class);
        Reflector.ModelHorseChests_ModelRenderers = new ReflectorFields(Reflector.ModelHorseChests, fee.class, 2);
        Reflector.ModelIllager = new ReflectorClass(fbt.class);
        Reflector.ModelIllager_ModelRenderers = new ReflectorFields(Reflector.ModelIllager, fee.class, 8);
        Reflector.ModelIronGolem = new ReflectorClass(fbu.class);
        Reflector.ModelIronGolem_ModelRenderers = new ReflectorFields(Reflector.ModelIronGolem, fee.class, 6);
        Reflector.ModelAxolotl = new ReflectorClass(faj.class);
        Reflector.ModelAxolotl_ModelRenderers = new ReflectorFields(Reflector.ModelAxolotl, fee.class, 10);
        Reflector.ModelFox = new ReflectorClass(fbh.class);
        Reflector.ModelFox_ModelRenderers = new ReflectorFields(Reflector.ModelFox, fee.class, 7);
        Reflector.ModelLeashKnot = new ReflectorClass(fbw.class);
        Reflector.ModelLeashKnot_knotRenderer = new ReflectorField(Reflector.ModelLeashKnot, fee.class);
        Reflector.RenderLeashKnot = new ReflectorClass(fpx.class);
        Reflector.RenderLeashKnot_leashKnotModel = new ReflectorField(Reflector.RenderLeashKnot, fbw.class);
        Reflector.ModelLlama = new ReflectorClass(fby.class);
        Reflector.ModelLlama_ModelRenderers = new ReflectorFields(Reflector.ModelLlama, fee.class, 8);
        Reflector.ModelOcelot = new ReflectorClass(fcd.class);
        Reflector.ModelOcelot_ModelRenderers = new ReflectorFields(Reflector.ModelOcelot, fee.class, 8);
        Reflector.ModelPhantom = new ReflectorClass(fcg.class);
        Reflector.ModelPhantom_ModelRenderers = new ReflectorFields(Reflector.ModelPhantom, fee.class, 7);
        Reflector.ModelPiglin = new ReflectorClass(fcj.class);
        Reflector.ModelPiglin_ModelRenderers = new ReflectorFields(Reflector.ModelPiglin, fee.class, 2);
        Reflector.ModelPiglinHead = new ReflectorClass(fci.class);
        Reflector.ModelPiglinHead_ModelRenderers = new ReflectorFields(Reflector.ModelPiglinHead, fee.class, 3);
        Reflector.ModelQuadruped = new ReflectorClass(fcp.class);
        Reflector.ModelQuadruped_ModelRenderers = new ReflectorFields(Reflector.ModelQuadruped, fee.class, 6);
        Reflector.ModelRabbit = new ReflectorClass(fcq.class);
        Reflector.ModelRabbit_ModelRenderers = new ReflectorFields(Reflector.ModelRabbit, fee.class, 12);
        Reflector.ModelShulker = new ReflectorClass(fcy.class);
        Reflector.ModelShulker_ModelRenderers = new ReflectorFields(Reflector.ModelShulker, fee.class, 3);
        Reflector.ModelSkull = new ReflectorClass(fdb.class);
        Reflector.ModelSkull_head = new ReflectorField(Reflector.ModelSkull, fee.class, 1);
        Reflector.ModelTadpole = new ReflectorClass(fdj.class);
        Reflector.ModelTadpole_ModelRenderers = new ReflectorFields(Reflector.ModelTadpole, fee.class, 2);
        Reflector.ModelTrident = new ReflectorClass(fdk.class);
        Reflector.ModelTrident_root = new ReflectorField(Reflector.ModelTrident, fee.class);
        Reflector.ModelTurtle = new ReflectorClass(fdn.class);
        Reflector.ModelTurtle_body2 = new ReflectorField(Reflector.ModelTurtle, fee.class, 0);
        Reflector.ModelVex = new ReflectorClass(fdo.class);
        Reflector.ModelVex_leftWing = new ReflectorField(Reflector.ModelVex, fee.class, 0);
        Reflector.ModelVex_rightWing = new ReflectorField(Reflector.ModelVex, fee.class, 1);
        Reflector.ModelWolf = new ReflectorClass(fdv.class);
        Reflector.ModelWolf_ModelRenderers = new ReflectorFields(Reflector.ModelWolf, fee.class, 10);
        Reflector.OptiFineResourceLocator = ReflectorForge.getReflectorClassOptiFineResourceLocator();
        Reflector.OptiFineResourceLocator_getOptiFineResourceStream = new ReflectorMethod(Reflector.OptiFineResourceLocator, "getOptiFineResourceStream");
        Reflector.RenderBoat = new ReflectorClass(fod.class);
        Reflector.RenderBoat_boatResources = new ReflectorField(Reflector.RenderBoat, Map.class);
        Reflector.RenderEvokerFangs = new ReflectorClass(fpa.class);
        Reflector.RenderEvokerFangs_model = new ReflectorField(Reflector.RenderEvokerFangs, fbg.class);
        Reflector.RenderLlamaSpit = new ReflectorClass(fqb.class);
        Reflector.RenderLlamaSpit_model = new ReflectorField(Reflector.RenderLlamaSpit, fbz.class);
        Reflector.RenderPufferfish = new ReflectorClass(fqq.class);
        Reflector.RenderPufferfish_modelSmall = new ReflectorField(Reflector.RenderPufferfish, fbf.class, 0);
        Reflector.RenderPufferfish_modelMedium = new ReflectorField(Reflector.RenderPufferfish, fbf.class, 1);
        Reflector.RenderPufferfish_modelBig = new ReflectorField(Reflector.RenderPufferfish, fbf.class, 2);
        Reflector.RenderMinecart = new ReflectorClass(fqd.class);
        Reflector.RenderMinecart_modelMinecart = new ReflectorField(Reflector.RenderMinecart, fbf.class);
        Reflector.RenderShulkerBullet = new ReflectorClass(fqw.class);
        Reflector.RenderShulkerBullet_model = new ReflectorField(Reflector.RenderShulkerBullet, fcx.class);
        Reflector.RenderTrident = new ReflectorClass(frk.class);
        Reflector.RenderTrident_modelTrident = new ReflectorField(Reflector.RenderTrident, fdk.class);
        Reflector.RenderTropicalFish = new ReflectorClass(fro.class);
        Reflector.RenderTropicalFish_modelA = new ReflectorField(Reflector.RenderTropicalFish, fax.class, 0);
        Reflector.RenderTropicalFish_modelB = new ReflectorField(Reflector.RenderTropicalFish, fax.class, 1);
        Reflector.TropicalFishPatternLayer = new ReflectorClass(ftq.class);
        Reflector.TropicalFishPatternLayer_modelA = new ReflectorField(Reflector.TropicalFishPatternLayer, fdl.class);
        Reflector.TropicalFishPatternLayer_modelB = new ReflectorField(Reflector.TropicalFishPatternLayer, fdm.class);
        Reflector.RenderWitherSkull = new ReflectorClass(frz.class);
        Reflector.RenderWitherSkull_model = new ReflectorField(Reflector.RenderWitherSkull, fdb.class);
        Reflector.SimpleBakedModel = new ReflectorClass(fxb.class);
        Reflector.SimpleBakedModel_generalQuads = Reflector.SimpleBakedModel.makeField(List.class);
        Reflector.SimpleBakedModel_faceQuads = Reflector.SimpleBakedModel.makeField(Map.class);
        Reflector.TileEntityBannerRenderer = new ReflectorClass(flp.class);
        Reflector.TileEntityBannerRenderer_modelRenderers = new ReflectorFields(Reflector.TileEntityBannerRenderer, fee.class, 3);
        Reflector.TileEntityBedRenderer = new ReflectorClass(flr.class);
        Reflector.TileEntityBedRenderer_headModel = new ReflectorField(Reflector.TileEntityBedRenderer, fee.class, 0);
        Reflector.TileEntityBedRenderer_footModel = new ReflectorField(Reflector.TileEntityBedRenderer, fee.class, 1);
        Reflector.TileEntityBellRenderer = new ReflectorClass(fls.class);
        Reflector.TileEntityBellRenderer_modelRenderer = new ReflectorField(Reflector.TileEntityBellRenderer, fee.class);
        Reflector.TileEntityBeacon = new ReflectorClass(czi.class);
        Reflector.TileEntityBeacon_customName = new ReflectorField(Reflector.TileEntityBeacon, sw.class);
        Reflector.TileEntityBeacon_levels = new ReflectorField(new FieldLocatorTypes(czi.class, new Class[] { List.class }, Integer.TYPE, new Class[] { Integer.TYPE }, "BeaconBlockEntity.levels"));
        Reflector.TileEntityChestRenderer = new ReflectorClass(fma.class);
        Reflector.TileEntityChestRenderer_modelRenderers = new ReflectorFields(Reflector.TileEntityChestRenderer, fee.class, 9);
        Reflector.TileEntityConduitRenderer = new ReflectorClass(fmb.class);
        Reflector.TileEntityConduitRenderer_modelRenderers = new ReflectorFields(Reflector.TileEntityConduitRenderer, fee.class, 4);
        Reflector.TileEntityDecoratedPotRenderer = new ReflectorClass(fmc.class);
        Reflector.TileEntityDecoratedPotRenderer_modelRenderers = new ReflectorFields(Reflector.TileEntityDecoratedPotRenderer, fee.class, 7);
        Reflector.TileEntityEnchantmentTableRenderer = new ReflectorClass(fmd.class);
        Reflector.TileEntityEnchantmentTableRenderer_modelBook = new ReflectorField(Reflector.TileEntityEnchantmentTableRenderer, fao.class);
        Reflector.TileEntityHangingSignRenderer = new ReflectorClass(fme.class);
        Reflector.TileEntityHangingSignRenderer_hangingSignModels = new ReflectorField(Reflector.TileEntityHangingSignRenderer, Map.class);
        Reflector.TileEntityLecternRenderer = new ReflectorClass(fmf.class);
        Reflector.TileEntityLecternRenderer_modelBook = new ReflectorField(Reflector.TileEntityLecternRenderer, fao.class);
        Reflector.TileEntityShulkerBoxRenderer = new ReflectorClass(fmh.class);
        Reflector.TileEntityShulkerBoxRenderer_model = new ReflectorField(Reflector.TileEntityShulkerBoxRenderer, fcy.class);
        Reflector.TileEntitySignRenderer = new ReflectorClass(fmi.class);
        Reflector.TileEntitySignRenderer_signModels = new ReflectorField(Reflector.TileEntitySignRenderer, Map.class);
    }
}
