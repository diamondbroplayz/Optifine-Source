// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.lang.reflect.Field;

public class ReflectorRaw
{
    private ReflectorRaw() {
    }
    
    public static Field getField(final Class cls, final Class fieldType) {
        try {
            final Field[] fileds = cls.getDeclaredFields();
            for (int i = 0; i < fileds.length; ++i) {
                final Field field = fileds[i];
                if (field.getType() == fieldType) {
                    field.setAccessible(true);
                    return field;
                }
            }
            return null;
        }
        catch (Exception e) {
            return null;
        }
    }
    
    public static Field[] getFields(final Class cls, final Class fieldType) {
        try {
            final Field[] fields = cls.getDeclaredFields();
            return getFields(fields, fieldType);
        }
        catch (Exception e) {
            return null;
        }
    }
    
    public static Field[] getFields(final Field[] fields, final Class fieldType) {
        try {
            final List list = new ArrayList();
            for (int i = 0; i < fields.length; ++i) {
                final Field field = fields[i];
                if (field.getType() == fieldType) {
                    field.setAccessible(true);
                    list.add(field);
                }
            }
            final Field[] fs = list.toArray(new Field[list.size()]);
            return fs;
        }
        catch (Exception e) {
            return null;
        }
    }
    
    public static Field[] getFieldsAfter(final Class cls, final Field field, final Class fieldType) {
        try {
            final Field[] fields = cls.getDeclaredFields();
            final List<Field> list = Arrays.asList(fields);
            final int posStart = list.indexOf(field);
            if (posStart < 0) {
                return new Field[0];
            }
            final List<Field> listAfter = list.subList(posStart + 1, list.size());
            final Field[] fieldsAfter = listAfter.toArray(new Field[listAfter.size()]);
            return getFields(fieldsAfter, fieldType);
        }
        catch (Exception e) {
            return null;
        }
    }
    
    public static Field[] getFields(final Object obj, final Field[] fields, final Class fieldType, final Object value) {
        try {
            final List<Field> list = new ArrayList<Field>();
            for (int i = 0; i < fields.length; ++i) {
                final Field field = fields[i];
                if (field.getType() == fieldType) {
                    final boolean staticField = Modifier.isStatic(field.getModifiers());
                    if (obj != null || staticField) {
                        if (obj == null || !staticField) {
                            field.setAccessible(true);
                            final Object fieldVal = field.get(obj);
                            if (fieldVal == value) {
                                list.add(field);
                            }
                            else if (fieldVal != null && value != null && fieldVal.equals(value)) {
                                list.add(field);
                            }
                        }
                    }
                }
            }
            final Field[] fs = list.toArray(new Field[list.size()]);
            return fs;
        }
        catch (Exception e) {
            return null;
        }
    }
    
    public static Field getField(final Class cls, final Class fieldType, final int index) {
        final Field[] fields = getFields(cls, fieldType);
        if (index < 0 || index >= fields.length) {
            return null;
        }
        return fields[index];
    }
    
    public static Field getFieldAfter(final Class cls, final Field field, final Class fieldType, final int index) {
        final Field[] fields = getFieldsAfter(cls, field, fieldType);
        if (index < 0 || index >= fields.length) {
            return null;
        }
        return fields[index];
    }
    
    public static Object getFieldValue(final Object obj, final Class cls, final Class fieldType) {
        final ReflectorField field = getReflectorField(cls, fieldType);
        if (field == null) {
            return null;
        }
        if (!field.exists()) {
            return null;
        }
        return Reflector.getFieldValue(obj, field);
    }
    
    public static Object getFieldValue(final Object obj, final Class cls, final Class fieldType, final int index) {
        final ReflectorField field = getReflectorField(cls, fieldType, index);
        if (field == null) {
            return null;
        }
        if (!field.exists()) {
            return null;
        }
        return Reflector.getFieldValue(obj, field);
    }
    
    public static boolean setFieldValue(final Object obj, final Class cls, final Class fieldType, final Object value) {
        final ReflectorField field = getReflectorField(cls, fieldType);
        return field != null && field.exists() && Reflector.setFieldValue(obj, field, value);
    }
    
    public static boolean setFieldValue(final Object obj, final Class cls, final Class fieldType, final int index, final Object value) {
        final ReflectorField field = getReflectorField(cls, fieldType, index);
        return field != null && field.exists() && Reflector.setFieldValue(obj, field, value);
    }
    
    public static ReflectorField getReflectorField(final Class cls, final Class fieldType) {
        final Field field = getField(cls, fieldType);
        if (field == null) {
            return null;
        }
        final ReflectorClass rc = new ReflectorClass(cls);
        return new ReflectorField(rc, field.getName());
    }
    
    public static ReflectorField getReflectorField(final Class cls, final Class fieldType, final int index) {
        final Field field = getField(cls, fieldType, index);
        if (field == null) {
            return null;
        }
        final ReflectorClass rc = new ReflectorClass(cls);
        return new ReflectorField(rc, field.getName());
    }
}
