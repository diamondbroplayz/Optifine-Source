// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

import java.lang.reflect.Field;

public interface IFieldLocator
{
    Field getField();
}
