// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

public class ReflectorFields
{
    private ReflectorClass reflectorClass;
    private Class fieldType;
    private int fieldCount;
    private ReflectorField[] reflectorFields;
    
    public ReflectorFields(final ReflectorClass reflectorClass, final Class fieldType, final int fieldCount) {
        this.reflectorClass = reflectorClass;
        this.fieldType = fieldType;
        this.fieldCount = fieldCount;
        if (!reflectorClass.exists()) {
            return;
        }
        if (fieldType == null) {
            return;
        }
        this.reflectorFields = new ReflectorField[fieldCount];
        for (int i = 0; i < this.reflectorFields.length; ++i) {
            this.reflectorFields[i] = new ReflectorField(reflectorClass, fieldType, i);
        }
    }
    
    public ReflectorClass getReflectorClass() {
        return this.reflectorClass;
    }
    
    public Class getFieldType() {
        return this.fieldType;
    }
    
    public int getFieldCount() {
        return this.fieldCount;
    }
    
    public ReflectorField getReflectorField(final int index) {
        if (index < 0 || index >= this.reflectorFields.length) {
            return null;
        }
        return this.reflectorFields[index];
    }
    
    public Object getValue(final Object obj, final int index) {
        return Reflector.getFieldValue(obj, this, index);
    }
    
    public void setValue(final Object obj, final int index, final Object val) {
        Reflector.setFieldValue(obj, this, index, val);
    }
    
    public boolean exists() {
        if (this.reflectorFields == null) {
            return false;
        }
        for (int i = 0; i < this.reflectorFields.length; ++i) {
            final ReflectorField reflectorField = this.reflectorFields[i];
            if (!reflectorField.exists()) {
                return false;
            }
        }
        return true;
    }
}
