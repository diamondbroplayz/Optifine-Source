// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

import net.optifine.Log;

public class ReflectorClass implements IResolvable
{
    private String targetClassName;
    private boolean checked;
    private Class targetClass;
    
    public ReflectorClass(final String targetClassName) {
        this.targetClassName = null;
        this.checked = false;
        this.targetClass = null;
        this.targetClassName = targetClassName;
        ReflectorResolver.register(this);
    }
    
    public ReflectorClass(final Class targetClass) {
        this.targetClassName = null;
        this.checked = false;
        this.targetClass = null;
        this.targetClass = targetClass;
        this.targetClassName = targetClass.getName();
        this.checked = true;
    }
    
    public Class getTargetClass() {
        if (this.checked) {
            return this.targetClass;
        }
        this.checked = true;
        try {
            this.targetClass = Class.forName(this.targetClassName);
        }
        catch (ClassNotFoundException e2) {
            Log.log(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.targetClassName));
        }
        catch (Throwable e) {
            e.printStackTrace();
        }
        return this.targetClass;
    }
    
    public boolean exists() {
        return this.getTargetClass() != null;
    }
    
    public String getTargetClassName() {
        return this.targetClassName;
    }
    
    public boolean isInstance(final Object obj) {
        return this.getTargetClass() != null && this.getTargetClass().isInstance(obj);
    }
    
    public ReflectorField makeField(final String name) {
        return new ReflectorField(this, name);
    }
    
    public ReflectorField makeField(final Class type) {
        return new ReflectorField(this, type);
    }
    
    public ReflectorField makeField(final IFieldLocator loc) {
        return new ReflectorField(loc);
    }
    
    public ReflectorField makeFieldTypes(final Class preType, final Class type, final Class postTypes, final String errorName) {
        if (this.getTargetClass() == null) {
            return null;
        }
        return new ReflectorField(new FieldLocatorTypes(this.getTargetClass(), new Class[] { preType }, type, new Class[] { postTypes }, errorName));
    }
    
    public ReflectorMethod makeMethod(final String name) {
        return new ReflectorMethod(this, name);
    }
    
    public ReflectorMethod makeMethod(final String name, final Class[] paramTypes) {
        return new ReflectorMethod(this, name, paramTypes);
    }
    
    public ReflectorConstructor makeConstructor(final Class[] paramTypes) {
        return new ReflectorConstructor(this, paramTypes);
    }
    
    @Override
    public void resolve() {
        final Class cls = this.getTargetClass();
    }
}
