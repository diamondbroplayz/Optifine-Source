// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

import net.optifine.Log;
import net.optifine.util.ArrayUtils;
import java.lang.reflect.Constructor;

public class ReflectorConstructor implements IResolvable
{
    private ReflectorClass reflectorClass;
    private Class[] parameterTypes;
    private boolean checked;
    private Constructor targetConstructor;
    
    public ReflectorConstructor(final ReflectorClass reflectorClass, final Class[] parameterTypes) {
        this.reflectorClass = null;
        this.parameterTypes = null;
        this.checked = false;
        this.targetConstructor = null;
        this.reflectorClass = reflectorClass;
        this.parameterTypes = parameterTypes;
        ReflectorResolver.register(this);
    }
    
    public Constructor getTargetConstructor() {
        if (this.checked) {
            return this.targetConstructor;
        }
        this.checked = true;
        final Class cls = this.reflectorClass.getTargetClass();
        if (cls == null) {
            return null;
        }
        try {
            this.targetConstructor = findConstructor(cls, this.parameterTypes);
            if (this.targetConstructor == null) {
                Log.dbg(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, cls.getName(), ArrayUtils.arrayToString(this.parameterTypes)));
            }
            if (this.targetConstructor != null) {
                this.targetConstructor.setAccessible(true);
            }
        }
        catch (Throwable e) {
            e.printStackTrace();
        }
        return this.targetConstructor;
    }
    
    private static Constructor findConstructor(final Class cls, final Class[] paramTypes) {
        final Constructor[] cs = cls.getDeclaredConstructors();
        for (int i = 0; i < cs.length; ++i) {
            final Constructor c = cs[i];
            final Class[] types = c.getParameterTypes();
            if (Reflector.matchesTypes(paramTypes, types)) {
                return c;
            }
        }
        return null;
    }
    
    public boolean exists() {
        if (this.checked) {
            return this.targetConstructor != null;
        }
        return this.getTargetConstructor() != null;
    }
    
    public void deactivate() {
        this.checked = true;
        this.targetConstructor = null;
    }
    
    public Object newInstance(final Object... params) {
        return Reflector.newInstance(this, params);
    }
    
    @Override
    public void resolve() {
        final Constructor c = this.getTargetConstructor();
    }
}
