// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

import net.optifine.Log;
import java.lang.reflect.Field;

public class FieldLocatorName implements IFieldLocator
{
    private ReflectorClass reflectorClass;
    private String targetFieldName;
    
    public FieldLocatorName(final ReflectorClass reflectorClass, final String targetFieldName) {
        this.reflectorClass = null;
        this.targetFieldName = null;
        this.reflectorClass = reflectorClass;
        this.targetFieldName = targetFieldName;
    }
    
    @Override
    public Field getField() {
        final Class cls = this.reflectorClass.getTargetClass();
        if (cls == null) {
            return null;
        }
        try {
            final Field targetField = this.getDeclaredField(cls, this.targetFieldName);
            targetField.setAccessible(true);
            return targetField;
        }
        catch (NoSuchFieldException e3) {
            Log.log(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, cls.getName(), this.targetFieldName));
            return null;
        }
        catch (SecurityException e) {
            e.printStackTrace();
            return null;
        }
        catch (Throwable e2) {
            e2.printStackTrace();
            return null;
        }
    }
    
    private Field getDeclaredField(final Class cls, final String name) throws NoSuchFieldException {
        final Field[] fields = cls.getDeclaredFields();
        for (int i = 0; i < fields.length; ++i) {
            final Field field = fields[i];
            if (field.getName().equals(name)) {
                return field;
            }
        }
        if (cls == Object.class) {
            throw new NoSuchFieldException(name);
        }
        return this.getDeclaredField(cls.getSuperclass(), name);
    }
}
