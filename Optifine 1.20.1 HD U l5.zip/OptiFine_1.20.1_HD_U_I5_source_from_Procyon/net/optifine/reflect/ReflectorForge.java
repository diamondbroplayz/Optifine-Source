// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.reflect;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import net.optifine.Log;
import java.util.function.Supplier;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import net.optifine.util.StrUtils;
import java.io.InputStream;
import java.util.Map;

public class ReflectorForge
{
    public static Object EVENT_RESULT_ALLOW;
    public static Object EVENT_RESULT_DENY;
    public static Object EVENT_RESULT_DEFAULT;
    public static final boolean FORGE_ENTITY_CAN_UPDATE;
    
    public static void putLaunchBlackboard(final String key, final Object value) {
        final Map blackboard = (Map)Reflector.getFieldValue(Reflector.Launch_blackboard);
        if (blackboard == null) {
            return;
        }
        blackboard.put(key, value);
    }
    
    public static InputStream getOptiFineResourceStream(String path) {
        if (!Reflector.OptiFineResourceLocator.exists()) {
            return null;
        }
        path = StrUtils.removePrefix(path, "/");
        final InputStream in = (InputStream)Reflector.call(Reflector.OptiFineResourceLocator_getOptiFineResourceStream, path);
        return in;
    }
    
    public static ReflectorClass getReflectorClassOptiFineResourceLocator() {
        final String className = "optifine.OptiFineResourceLocator";
        final Object ofrlClass = System.getProperties().get(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, className));
        if (ofrlClass instanceof Class) {
            final Class cls = (Class)ofrlClass;
            return new ReflectorClass(cls);
        }
        return new ReflectorClass(className);
    }
    
    public static boolean calculateFaceWithoutAO(final clp getter, final dcb state, final gu pos, final fkr quad, final boolean isFaceCubic, final float[] brightness, final int[] lightmap) {
        if (quad.hasAmbientOcclusion()) {
            return false;
        }
        final gu lightmapPos = isFaceCubic ? pos.a(quad.e()) : pos;
        final int n = 0;
        final int n2 = 1;
        final int n3 = 2;
        final int n4 = 3;
        final float a = getter.a(quad.e(), quad.f());
        brightness[n3] = (brightness[n4] = a);
        brightness[n] = (brightness[n2] = a);
        final int n5 = 0;
        final int n6 = 1;
        final int n7 = 2;
        final int n8 = 3;
        final int a2 = fjv.a(getter, state, lightmapPos);
        lightmap[n7] = (lightmap[n8] = a2);
        lightmap[n5] = (lightmap[n6] = a2);
        return true;
    }
    
    public static dyo getMapData(final cfz stack, final cmm world) {
        if (Reflector.ForgeHooksClient.exists()) {
            final cgg cgg = (cgg)stack.d();
            return cgg.a(stack, world);
        }
        return cgg.a(stack, world);
    }
    
    public static String[] getForgeModIds() {
        if (!Reflector.ModList.exists()) {
            return new String[0];
        }
        final Object modList = Reflector.ModList_get.call(new Object[0]);
        final List listMods = (List)Reflector.getFieldValue(modList, Reflector.ModList_mods);
        if (listMods == null) {
            return new String[0];
        }
        final List<String> listModIds = new ArrayList<String>();
        for (final Object modContainer : listMods) {
            if (!Reflector.ModContainer.isInstance(modContainer)) {
                continue;
            }
            final String modId = Reflector.callString(modContainer, Reflector.ModContainer_getModId, new Object[0]);
            if (modId == null) {
                continue;
            }
            if (modId.equals("minecraft")) {
                continue;
            }
            if (modId.equals("forge")) {
                continue;
            }
            listModIds.add(modId);
        }
        final String[] modIds = listModIds.toArray(new String[listModIds.size()]);
        return modIds;
    }
    
    public static boolean canDisableShield(final cfz itemstack, final cfz itemstack1, final byo entityplayer, final bgb entityLiving) {
        if (Reflector.IForgeItemStack_canDisableShield.exists()) {
            return Reflector.callBoolean(itemstack, Reflector.IForgeItemStack_canDisableShield, itemstack1, entityplayer, entityLiving);
        }
        return itemstack.d() instanceof cdo;
    }
    
    public static epi makeButtonMods(final euw guiMainMenu, final int yIn, final int rowHeightIn) {
        if (!Reflector.ModListScreen_Constructor.exists()) {
            return null;
        }
        final epi modButton = epi.a((sw)sw.c("fml.menu.mods"), ReflectorForge::lambda$makeButtonMods$0).a(guiMainMenu.g / 2 - 100, yIn + rowHeightIn * 2).b(98, 20).a();
        return modButton;
    }
    
    public static void setForgeLightPipelineEnabled(final boolean value) {
        if (Reflector.ForgeConfig_Client_forgeLightPipelineEnabled.exists()) {
            setConfigClientBoolean(Reflector.ForgeConfig_Client_forgeLightPipelineEnabled, value);
        }
    }
    
    public static boolean getForgeUseCombinedDepthStencilAttachment() {
        return Reflector.ForgeConfig_Client_useCombinedDepthStencilAttachment.exists() && getConfigClientBoolean(Reflector.ForgeConfig_Client_useCombinedDepthStencilAttachment, false);
    }
    
    public static boolean getConfigClientBoolean(final ReflectorField configField, final boolean def) {
        if (!configField.exists()) {
            return def;
        }
        final Object client = Reflector.ForgeConfig_CLIENT.getValue();
        if (client == null) {
            return def;
        }
        final Object configValue = Reflector.getFieldValue(client, configField);
        if (configValue == null) {
            return def;
        }
        final boolean value = Reflector.callBoolean(configValue, Reflector.ForgeConfigSpec_ConfigValue_get, new Object[0]);
        return value;
    }
    
    private static void setConfigClientBoolean(final ReflectorField clientField, final boolean value) {
        if (!clientField.exists()) {
            return;
        }
        final Object client = Reflector.ForgeConfig_CLIENT.getValue();
        if (client == null) {
            return;
        }
        final Object configValue = Reflector.getFieldValue(client, clientField);
        if (configValue == null) {
            return;
        }
        final Supplier<Boolean> bs = new Supplier<Boolean>(value) {
            @Override
            public Boolean get() {
                // 
                // This method could not be decompiled.
                // 
                // Could not show original bytecode, likely due to the same error.
                // 
                // The error that occurred was:
                // 
                // com.strobel.assembler.metadata.MethodBodyParseException: An error occurred while parsing the bytecode of method 'net/optifine/reflect/ReflectorForge$1.get:()Ljava/lang/Boolean;'.
                //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:66)
                //     at com.strobel.assembler.metadata.MethodDefinition.tryLoadBody(MethodDefinition.java:729)
                //     at com.strobel.assembler.metadata.MethodDefinition.getBody(MethodDefinition.java:83)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:202)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformCall(AstMethodBodyBuilder.java:1164)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:1009)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:294)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // Caused by: java.lang.IllegalArgumentException: Argument 'index' must be in the range [0, 45], but value was: 47104.
                //     at com.strobel.core.VerifyArgument.inRange(VerifyArgument.java:347)
                //     at com.strobel.assembler.ir.ConstantPool.get(ConstantPool.java:78)
                //     at com.strobel.assembler.metadata.ClassFileReader$Scope.lookupConstant(ClassFileReader.java:1313)
                //     at com.strobel.assembler.metadata.MethodReader.readBodyCore(MethodReader.java:293)
                //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:62)
                //     ... 31 more
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
        };
        Reflector.setFieldValue(configValue, Reflector.ForgeConfigSpec_ConfigValue_defaultSupplier, bs);
        final Object spec = Reflector.getFieldValue(configValue, Reflector.ForgeConfigSpec_ConfigValue_spec);
        if (spec != null) {
            Reflector.setFieldValue(spec, Reflector.ForgeConfigSpec_childConfig, null);
        }
        Log.dbg(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Z)Ljava/lang/String;, clientField.getTargetField().getName(), value));
    }
    
    public static boolean canUpdate(final bfj entity) {
        return !ReflectorForge.FORGE_ENTITY_CAN_UPDATE || Reflector.callBoolean(entity, Reflector.IForgeEntity_canUpdate, new Object[0]);
    }
    
    public static boolean isDamageable(final cfu item, final cfz stack) {
        if (Reflector.IForgeItem_isDamageable1.exists()) {
            return Reflector.callBoolean(item, Reflector.IForgeItem_isDamageable1, stack);
        }
        return item.o();
    }
    
    public static void fillNormal(final int[] faceData, final ha facing) {
        final Vector3f v1 = getVertexPos(faceData, 3);
        final Vector3f t1 = getVertexPos(faceData, 1);
        final Vector3f v2 = getVertexPos(faceData, 2);
        final Vector3f t2 = getVertexPos(faceData, 0);
        v1.sub((Vector3fc)t1);
        v2.sub((Vector3fc)t2);
        v2.cross((Vector3fc)v1);
        v2.normalize();
        final int x = (byte)Math.round(v2.x() * 127.0f) & 0xFF;
        final int y = (byte)Math.round(v2.y() * 127.0f) & 0xFF;
        final int z = (byte)Math.round(v2.z() * 127.0f) & 0xFF;
        final int normal = x | y << 8 | z << 16;
        final int step = faceData.length / 4;
        for (int i = 0; i < 4; ++i) {
            faceData[i * step + 7] = normal;
        }
    }
    
    private static Vector3f getVertexPos(final int[] data, final int vertex) {
        final int step = data.length / 4;
        final int idx = vertex * step;
        final float x = Float.intBitsToFloat(data[idx]);
        final float y = Float.intBitsToFloat(data[idx + 1]);
        final float z = Float.intBitsToFloat(data[idx + 2]);
        return new Vector3f(x, y, z);
    }
    
    public static void postModLoaderEvent(final ReflectorConstructor constr, final Object... params) {
        final Object event = Reflector.newInstance(constr, params);
        if (event == null) {
            return;
        }
        postModLoaderEvent(event);
    }
    
    public static void postModLoaderEvent(final Object event) {
        if (event == null) {
            return;
        }
        final Object modLoader = Reflector.ModLoader_get.call(new Object[0]);
        if (modLoader == null) {
            return;
        }
        Reflector.callVoid(modLoader, Reflector.ModLoader_postEvent, event);
    }
    
    public static void dispatchRenderStageS(final ReflectorField stageField, final fjv levelRenderer, final eij matrixStack, final Matrix4f matrix, final int ticks, final emz camera, final fmw frustum) {
        if (!Reflector.ForgeHooksClient_dispatchRenderStageS.exists()) {
            return;
        }
        if (!stageField.exists()) {
            return;
        }
        final Object stage = stageField.getValue();
        Reflector.ForgeHooksClient_dispatchRenderStageS.call(stage, levelRenderer, matrixStack, matrix, ticks, camera, frustum);
    }
    
    static {
        ReflectorForge.EVENT_RESULT_ALLOW = Reflector.getFieldValue(Reflector.Event_Result_ALLOW);
        ReflectorForge.EVENT_RESULT_DENY = Reflector.getFieldValue(Reflector.Event_Result_DENY);
        ReflectorForge.EVENT_RESULT_DEFAULT = Reflector.getFieldValue(Reflector.Event_Result_DEFAULT);
        FORGE_ENTITY_CAN_UPDATE = Reflector.IForgeEntity_canUpdate.exists();
    }
}
