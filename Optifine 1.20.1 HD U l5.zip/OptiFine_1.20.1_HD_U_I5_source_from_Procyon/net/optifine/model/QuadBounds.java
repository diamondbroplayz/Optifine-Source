// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.model;

public class QuadBounds
{
    private float minX;
    private float minY;
    private float minZ;
    private float maxX;
    private float maxY;
    private float maxZ;
    
    public QuadBounds(final int[] vertexData) {
        this.minX = Float.MAX_VALUE;
        this.minY = Float.MAX_VALUE;
        this.minZ = Float.MAX_VALUE;
        this.maxX = -3.4028235E38f;
        this.maxY = -3.4028235E38f;
        this.maxZ = -3.4028235E38f;
        final int step = vertexData.length / 4;
        for (int i = 0; i < 4; ++i) {
            final int pos = i * step;
            final float x = Float.intBitsToFloat(vertexData[pos + 0]);
            final float y = Float.intBitsToFloat(vertexData[pos + 1]);
            final float z = Float.intBitsToFloat(vertexData[pos + 2]);
            if (this.minX > x) {
                this.minX = x;
            }
            if (this.minY > y) {
                this.minY = y;
            }
            if (this.minZ > z) {
                this.minZ = z;
            }
            if (this.maxX < x) {
                this.maxX = x;
            }
            if (this.maxY < y) {
                this.maxY = y;
            }
            if (this.maxZ < z) {
                this.maxZ = z;
            }
        }
    }
    
    public float getMinX() {
        return this.minX;
    }
    
    public float getMinY() {
        return this.minY;
    }
    
    public float getMinZ() {
        return this.minZ;
    }
    
    public float getMaxX() {
        return this.maxX;
    }
    
    public float getMaxY() {
        return this.maxY;
    }
    
    public float getMaxZ() {
        return this.maxZ;
    }
    
    public boolean isFaceQuad(final ha face) {
        float min = 0.0f;
        float max = 0.0f;
        float val = 0.0f;
        switch (face) {
            case a: {
                min = this.getMinY();
                max = this.getMaxY();
                val = 0.0f;
                break;
            }
            case b: {
                min = this.getMinY();
                max = this.getMaxY();
                val = 1.0f;
                break;
            }
            case c: {
                min = this.getMinZ();
                max = this.getMaxZ();
                val = 0.0f;
                break;
            }
            case d: {
                min = this.getMinZ();
                max = this.getMaxZ();
                val = 1.0f;
                break;
            }
            case e: {
                min = this.getMinX();
                max = this.getMaxX();
                val = 0.0f;
                break;
            }
            case f: {
                min = this.getMinX();
                max = this.getMaxX();
                val = 1.0f;
                break;
            }
            default: {
                return false;
            }
        }
        return min == val && max == val;
    }
    
    public boolean isFullQuad(final ha face) {
        float min1 = 0.0f;
        float max1 = 0.0f;
        float min2 = 0.0f;
        float max2 = 0.0f;
        switch (face) {
            case a:
            case b: {
                min1 = this.getMinX();
                max1 = this.getMaxX();
                min2 = this.getMinZ();
                max2 = this.getMaxZ();
                break;
            }
            case c:
            case d: {
                min1 = this.getMinX();
                max1 = this.getMaxX();
                min2 = this.getMinY();
                max2 = this.getMaxY();
                break;
            }
            case e:
            case f: {
                min1 = this.getMinY();
                max1 = this.getMaxY();
                min2 = this.getMinZ();
                max2 = this.getMaxZ();
                break;
            }
            default: {
                return false;
            }
        }
        return min1 == 0.0f && max1 == 1.0f && min2 == 0.0f && max2 == 1.0f;
    }
}
