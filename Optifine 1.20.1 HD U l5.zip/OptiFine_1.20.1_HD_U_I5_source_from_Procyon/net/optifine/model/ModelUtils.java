// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.model;

import net.optifine.util.RandomUtils;
import net.optifine.reflect.Reflector;
import java.util.Map;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashMap;
import net.minecraft.client.renderer.block.model.BakedQuad;
import java.util.Iterator;
import java.util.List;
import net.optifine.Config;

public class ModelUtils
{
    private static final apf RANDOM;
    
    public static void dbgModel(final fwr model) {
        if (model == null) {
            return;
        }
        Config.dbg(invokedynamic(makeConcatWithConstants:(Lfwr;ZZZLfuv;)Ljava/lang/String;, model, model.a(), model.b(), model.d(), model.e()));
        final ha[] faces = ha.p;
        for (int i = 0; i < faces.length; ++i) {
            final ha face = faces[i];
            final List faceQuads = model.a((dcb)null, face, ModelUtils.RANDOM);
            dbgQuads(face.c(), faceQuads, "  ");
        }
        final List generalQuads = model.a((dcb)null, (ha)null, ModelUtils.RANDOM);
        dbgQuads("General", generalQuads, "  ");
    }
    
    private static void dbgQuads(final String name, final List quads, final String prefix) {
        for (final fkr quad : quads) {
            dbgQuad(name, quad, prefix);
        }
    }
    
    public static void dbgQuad(final String name, final fkr quad, final String prefix) {
        Config.dbg(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lha;ILfuv;)Ljava/lang/String;, prefix, quad.getClass().getName(), name, quad.e(), quad.d(), quad.a()));
        dbgVertexData(quad.b(), invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, prefix));
    }
    
    public static void dbgVertexData(final int[] vd, final String prefix) {
        final int step = vd.length / 4;
        Config.dbg(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;II)Ljava/lang/String;, prefix, vd.length, step));
        for (int i = 0; i < 4; ++i) {
            final int pos = i * step;
            final float x = Float.intBitsToFloat(vd[pos + 0]);
            final float y = Float.intBitsToFloat(vd[pos + 1]);
            final float z = Float.intBitsToFloat(vd[pos + 2]);
            final int col = vd[pos + 3];
            final float u = Float.intBitsToFloat(vd[pos + 4]);
            final float v = Float.intBitsToFloat(vd[pos + 5]);
            Config.dbg(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;IFFFIFF)Ljava/lang/String;, prefix, i, x, y, z, col, u, v));
        }
    }
    
    public static fwr duplicateModel(final fwr model) {
        final List<fkr> generalQuads2 = (List<fkr>)duplicateQuadList(model.a((dcb)null, (ha)null, ModelUtils.RANDOM));
        final ha[] faces = ha.p;
        final Map<ha, List<fkr>> faceQuads2 = new HashMap<ha, List<fkr>>();
        for (int i = 0; i < faces.length; ++i) {
            final ha face = faces[i];
            final List quads = model.a((dcb)null, face, ModelUtils.RANDOM);
            final List quads2 = duplicateQuadList(quads);
            faceQuads2.put(face, quads2);
        }
        final List<fkr> generalQuads2Copy = new ArrayList<fkr>(generalQuads2);
        final Map<ha, List<fkr>> faceQuads2Copy = new HashMap<ha, List<fkr>>(faceQuads2);
        final fxb model2 = new fxb((List)generalQuads2Copy, (Map)faceQuads2Copy, model.a(), model.b(), true, model.e(), model.f(), model.g());
        Reflector.SimpleBakedModel_generalQuads.setValue(model2, generalQuads2);
        Reflector.SimpleBakedModel_faceQuads.setValue(model2, faceQuads2);
        return (fwr)model2;
    }
    
    public static List duplicateQuadList(final List<fkr> list) {
        final List<fkr> list2 = new ArrayList<fkr>();
        for (final fkr quad : list) {
            final fkr quad2 = duplicateQuad(quad);
            list2.add(quad2);
        }
        return list2;
    }
    
    public static fkr duplicateQuad(final fkr quad) {
        final fkr quad2 = new fkr((int[])quad.b().clone(), quad.d(), quad.e(), quad.a(), quad.f());
        return quad2;
    }
    
    static {
        ModelUtils.RANDOM = RandomUtils.makeThreadSafeRandomSource(0);
    }
}
