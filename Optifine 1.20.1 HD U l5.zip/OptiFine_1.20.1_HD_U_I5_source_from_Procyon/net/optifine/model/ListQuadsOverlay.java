// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.model;

import java.util.Arrays;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.client.renderer.block.model.BakedQuad;
import java.util.ArrayList;
import java.util.List;

public class ListQuadsOverlay
{
    private List<fkr> listQuads;
    private List<dcb> listBlockStates;
    private List<fkr> listQuadsSingle;
    
    public ListQuadsOverlay() {
        this.listQuads = new ArrayList<BakedQuad>();
        this.listBlockStates = new ArrayList<BlockState>();
        this.listQuadsSingle = Arrays.asList((BakedQuad[])new fkr[1]);
    }
    
    public void addQuad(final fkr quad, final dcb blockState) {
        if (quad == null) {
            return;
        }
        this.listQuads.add((BakedQuad)quad);
        this.listBlockStates.add((BlockState)blockState);
    }
    
    public int size() {
        return this.listQuads.size();
    }
    
    public fkr getQuad(final int index) {
        return (fkr)this.listQuads.get(index);
    }
    
    public dcb getBlockState(final int index) {
        if (index < 0 || index >= this.listBlockStates.size()) {
            return cpo.a.n();
        }
        return (dcb)this.listBlockStates.get(index);
    }
    
    public List<fkr> getListQuadsSingle(final fkr quad) {
        this.listQuadsSingle.set(0, (BakedQuad)quad);
        return (List<fkr>)this.listQuadsSingle;
    }
    
    public void clear() {
        this.listQuads.clear();
        this.listBlockStates.clear();
    }
}
