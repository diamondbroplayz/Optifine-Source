// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.model;

import com.google.common.collect.ImmutableList;
import net.optifine.NaturalTextures;
import net.optifine.ConnectedTextures;
import net.optifine.render.RenderTypes;
import net.optifine.BetterGrass;
import net.optifine.Config;
import net.optifine.SmartLeaves;
import net.optifine.render.RenderEnv;
import java.util.List;

public class BlockModelCustomizer
{
    private static final List<fkr> NO_QUADS;
    
    public static fwr getRenderModel(fwr modelIn, final dcb stateIn, final RenderEnv renderEnv) {
        if (renderEnv.isSmartLeaves()) {
            modelIn = SmartLeaves.getLeavesModel(modelIn, stateIn);
        }
        return modelIn;
    }
    
    public static List<fkr> getRenderQuads(List<fkr> quads, final clp worldIn, final dcb stateIn, final gu posIn, final ha enumfacing, final fkf layer, final long rand, final RenderEnv renderEnv) {
        if (enumfacing != null) {
            if (renderEnv.isSmartLeaves() && SmartLeaves.isSameLeaves(worldIn.a_(posIn.a(enumfacing)), stateIn)) {
                return BlockModelCustomizer.NO_QUADS;
            }
            if (!renderEnv.isBreakingAnimation(quads) && Config.isBetterGrass()) {
                quads = (List<fkr>)BetterGrass.getFaceQuads((cls)worldIn, stateIn, posIn, enumfacing, quads);
            }
        }
        final List<fkr> quadsNew = (List<fkr>)renderEnv.getListQuadsCustomizer();
        quadsNew.clear();
        for (int i = 0; i < quads.size(); ++i) {
            final fkr quad = quads.get(i);
            final fkr[] quadArr = getRenderQuads(quad, worldIn, stateIn, posIn, enumfacing, rand, renderEnv);
            if (i == 0 && quads.size() == 1 && quadArr.length == 1 && quadArr[0] == quad && quad.getQuadEmissive() == null) {
                return quads;
            }
            for (int q = 0; q < quadArr.length; ++q) {
                final fkr quadSingle = quadArr[q];
                quadsNew.add(quadSingle);
                if (quadSingle.getQuadEmissive() != null) {
                    renderEnv.getListQuadsOverlay(getEmissiveLayer(layer)).addQuad(quadSingle.getQuadEmissive(), stateIn);
                    renderEnv.setOverlaysRendered(true);
                }
            }
        }
        return quadsNew;
    }
    
    private static fkf getEmissiveLayer(final fkf layer) {
        if (layer == null || layer == RenderTypes.SOLID) {
            return RenderTypes.CUTOUT_MIPPED;
        }
        return layer;
    }
    
    private static fkr[] getRenderQuads(fkr quad, final clp worldIn, final dcb stateIn, final gu posIn, final ha enumfacing, final long rand, final RenderEnv renderEnv) {
        if (renderEnv.isBreakingAnimation(quad)) {
            return renderEnv.getArrayQuadsCtm(quad);
        }
        final fkr quadOriginal = quad;
        if (Config.isConnectedTextures()) {
            final fkr[] quads = ConnectedTextures.getConnectedTexture(worldIn, stateIn, posIn, quad, renderEnv);
            if (quads.length != 1 || quads[0] != quad) {
                return quads;
            }
        }
        if (Config.isNaturalTextures()) {
            quad = NaturalTextures.getNaturalTexture(stateIn, posIn, quad);
            if (quad != quadOriginal) {
                return renderEnv.getArrayQuadsCtm(quad);
            }
        }
        return renderEnv.getArrayQuadsCtm(quad);
    }
    
    static {
        NO_QUADS = (List)ImmutableList.of();
    }
}
