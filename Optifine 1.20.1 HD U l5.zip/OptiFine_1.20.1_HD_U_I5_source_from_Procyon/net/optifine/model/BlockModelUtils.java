// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.model;

import net.optifine.util.RandomUtils;
import java.util.Iterator;
import org.joml.Vector3f;
import java.util.Collection;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import net.optifine.Config;

public class BlockModelUtils
{
    private static final float VERTEX_COORD_ACCURACY = 1.0E-6f;
    private static final apf RANDOM;
    
    public static fwr makeModelCube(final String spriteName, final int tintIndex) {
        final fuv sprite = Config.getTextureMap().getUploadedSprite(spriteName);
        return makeModelCube(sprite, tintIndex);
    }
    
    public static fwr makeModelCube(final fuv sprite, final int tintIndex) {
        final List generalQuads = new ArrayList();
        final ha[] facings = ha.p;
        final Map<ha, List<fkr>> faceQuads = new HashMap<ha, List<fkr>>();
        for (int i = 0; i < facings.length; ++i) {
            final ha facing = facings[i];
            final List quads = new ArrayList();
            quads.add(makeBakedQuad(facing, sprite, tintIndex));
            faceQuads.put(facing, quads);
        }
        final flb itemOverrideList = flb.a;
        final fwr bakedModel = (fwr)new fxb(generalQuads, (Map)faceQuads, true, true, true, sprite, fld.a, itemOverrideList);
        return bakedModel;
    }
    
    public static fwr joinModelsCube(final fwr modelBase, final fwr modelAdd) {
        final List<fkr> generalQuads = new ArrayList<fkr>();
        generalQuads.addAll(modelBase.a((dcb)null, (ha)null, BlockModelUtils.RANDOM));
        generalQuads.addAll(modelAdd.a((dcb)null, (ha)null, BlockModelUtils.RANDOM));
        final ha[] facings = ha.p;
        final Map<ha, List<fkr>> faceQuads = new HashMap<ha, List<fkr>>();
        for (int i = 0; i < facings.length; ++i) {
            final ha facing = facings[i];
            final List quads = new ArrayList();
            quads.addAll(modelBase.a((dcb)null, facing, BlockModelUtils.RANDOM));
            quads.addAll(modelAdd.a((dcb)null, facing, BlockModelUtils.RANDOM));
            faceQuads.put(facing, quads);
        }
        final boolean ao = modelBase.a();
        final boolean builtIn = modelBase.d();
        final fuv sprite = modelBase.e();
        final fld transforms = modelBase.f();
        final flb itemOverrideList = modelBase.g();
        final fwr bakedModel = (fwr)new fxb((List)generalQuads, (Map)faceQuads, ao, builtIn, true, sprite, transforms, itemOverrideList);
        return bakedModel;
    }
    
    public static fkr makeBakedQuad(final ha facing, final fuv sprite, final int tintIndex) {
        final Vector3f posFrom = new Vector3f(0.0f, 0.0f, 0.0f);
        final Vector3f posTo = new Vector3f(16.0f, 16.0f, 16.0f);
        final fkv uv = new fkv(new float[] { 0.0f, 0.0f, 16.0f, 16.0f }, 0);
        final fkt face = new fkt(facing, tintIndex, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, facing.c()), uv);
        final fws modelRotation = fws.a;
        final fku partRotation = null;
        final boolean shade = true;
        final acq modelLoc = sprite.getName();
        final fky faceBakery = new fky();
        final fkr quad = faceBakery.a(posFrom, posTo, face, sprite, facing, (fwz)modelRotation, partRotation, shade, modelLoc);
        return quad;
    }
    
    public static fwr makeModel(final String modelName, final String spriteOldName, final String spriteNewName) {
        final fuu textureMap = Config.getTextureMap();
        final fuv spriteOld = textureMap.getUploadedSprite(spriteOldName);
        final fuv spriteNew = textureMap.getUploadedSprite(spriteNewName);
        return makeModel(modelName, spriteOld, spriteNew);
    }
    
    public static fwr makeModel(final String modelName, final fuv spriteOld, final fuv spriteNew) {
        if (spriteOld == null || spriteNew == null) {
            return null;
        }
        final fwx modelManager = Config.getModelManager();
        if (modelManager == null) {
            return null;
        }
        final fwy mrl = fwy.c(modelName, "");
        final fwr model = modelManager.a(mrl);
        if (model == null || model == modelManager.a()) {
            return null;
        }
        final fwr modelNew = ModelUtils.duplicateModel(model);
        final ha[] faces = ha.p;
        for (int i = 0; i < faces.length; ++i) {
            final ha face = faces[i];
            final List<fkr> quads = (List<fkr>)modelNew.a((dcb)null, face, BlockModelUtils.RANDOM);
            replaceTexture(quads, spriteOld, spriteNew);
        }
        final List<fkr> quadsGeneral = (List<fkr>)modelNew.a((dcb)null, (ha)null, BlockModelUtils.RANDOM);
        replaceTexture(quadsGeneral, spriteOld, spriteNew);
        return modelNew;
    }
    
    private static void replaceTexture(final List<fkr> quads, final fuv spriteOld, final fuv spriteNew) {
        final List<fkr> quadsNew = new ArrayList<fkr>();
        for (fkr quad : quads) {
            if (quad.a() == spriteOld) {
                quad = new BakedQuadRetextured(quad, spriteNew);
            }
            quadsNew.add(quad);
        }
        quads.clear();
        quads.addAll(quadsNew);
    }
    
    public static void snapVertexPosition(final Vector3f pos) {
        pos.set(snapVertexCoord(pos.x()), snapVertexCoord(pos.y()), snapVertexCoord(pos.z()));
    }
    
    private static float snapVertexCoord(final float x) {
        if (x > -1.0E-6f && x < 1.0E-6f) {
            return 0.0f;
        }
        if (x > 0.999999f && x < 1.000001f) {
            return 1.0f;
        }
        return x;
    }
    
    public static eed getOffsetBoundingBox(final eed aabb, final dca.c offsetType, final gu pos) {
        final int x = pos.u();
        final int z = pos.w();
        long k = (long)(x * 3129871) ^ z * 116129781L;
        k = k * k * 42317861L + k * 11L;
        final double dx = ((k >> 16 & 0xFL) / 15.0f - 0.5) * 0.5;
        final double dz = ((k >> 24 & 0xFL) / 15.0f - 0.5) * 0.5;
        double dy = 0.0;
        if (offsetType == dca.c.c) {
            dy = ((k >> 20 & 0xFL) / 15.0f - 1.0) * 0.2;
        }
        return aabb.d(dx, dy, dz);
    }
    
    static {
        RANDOM = RandomUtils.makeThreadSafeRandomSource(0);
    }
}
