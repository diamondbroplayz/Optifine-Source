// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.model;

import java.util.Arrays;

public class BakedQuadRetextured extends fkr
{
    public BakedQuadRetextured(final fkr quad, final fuv spriteIn) {
        super(remapVertexData(quad.b(), quad.a(), spriteIn), quad.d(), fky.a(quad.b()), spriteIn, quad.f());
    }
    
    private static int[] remapVertexData(final int[] vertexData, final fuv sprite, final fuv spriteNew) {
        final int[] vertexDataNew = Arrays.copyOf(vertexData, vertexData.length);
        for (int i = 0; i < 4; ++i) {
            final eio format = eih.j;
            final int j = format.a() * i;
            final int uvIndex = format.getOffset(2) / 4;
            vertexDataNew[j + uvIndex] = Float.floatToRawIntBits(spriteNew.a((double)sprite.getUnInterpolatedU(Float.intBitsToFloat(vertexData[j + uvIndex]))));
            vertexDataNew[j + uvIndex + 1] = Float.floatToRawIntBits(spriteNew.b((double)sprite.getUnInterpolatedV(Float.intBitsToFloat(vertexData[j + uvIndex + 1]))));
        }
        return vertexDataNew;
    }
}
