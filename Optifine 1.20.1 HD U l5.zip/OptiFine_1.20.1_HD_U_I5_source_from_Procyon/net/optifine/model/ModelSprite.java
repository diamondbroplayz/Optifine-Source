// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.model;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import net.optifine.util.MathUtils;

public class ModelSprite
{
    private fee modelRenderer;
    private int textureOffsetX;
    private int textureOffsetY;
    private float posX;
    private float posY;
    private float posZ;
    private int sizeX;
    private int sizeY;
    private int sizeZ;
    private float sizeAdd;
    private float minU;
    private float minV;
    private float maxU;
    private float maxV;
    
    public ModelSprite(final fee modelRenderer, final int textureOffsetX, final int textureOffsetY, final float posX, final float posY, final float posZ, final int sizeX, final int sizeY, final int sizeZ, final float sizeAdd) {
        this.modelRenderer = null;
        this.textureOffsetX = 0;
        this.textureOffsetY = 0;
        this.posX = 0.0f;
        this.posY = 0.0f;
        this.posZ = 0.0f;
        this.sizeX = 0;
        this.sizeY = 0;
        this.sizeZ = 0;
        this.sizeAdd = 0.0f;
        this.minU = 0.0f;
        this.minV = 0.0f;
        this.maxU = 0.0f;
        this.maxV = 0.0f;
        this.modelRenderer = modelRenderer;
        this.textureOffsetX = textureOffsetX;
        this.textureOffsetY = textureOffsetY;
        this.posX = posX;
        this.posY = posY;
        this.posZ = posZ;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.sizeZ = sizeZ;
        this.sizeAdd = sizeAdd;
        this.minU = textureOffsetX / modelRenderer.textureWidth;
        this.minV = textureOffsetY / modelRenderer.textureHeight;
        this.maxU = (textureOffsetX + sizeX) / modelRenderer.textureWidth;
        this.maxV = (textureOffsetY + sizeY) / modelRenderer.textureHeight;
    }
    
    public void render(final eij matrixStackIn, final ein bufferIn, final int packedLightIn, final int packedOverlayIn, final float red, final float green, final float blue, final float alpha) {
        final float scale = 0.0625f;
        matrixStackIn.a(this.posX * scale, this.posY * scale, this.posZ * scale);
        float rMinU = this.minU;
        float rMaxU = this.maxU;
        float rMinV = this.minV;
        float rMaxV = this.maxV;
        if (this.modelRenderer.mirror) {
            rMinU = this.maxU;
            rMaxU = this.minU;
        }
        if (this.modelRenderer.mirrorV) {
            rMinV = this.maxV;
            rMaxV = this.minV;
        }
        renderItemIn2D(matrixStackIn, bufferIn, rMinU, rMinV, rMaxU, rMaxV, this.sizeX, this.sizeY, scale * this.sizeZ, this.modelRenderer.textureWidth, this.modelRenderer.textureHeight, packedLightIn, packedOverlayIn, red, green, blue, alpha);
        matrixStackIn.a(-this.posX * scale, -this.posY * scale, -this.posZ * scale);
    }
    
    public static void renderItemIn2D(final eij matrixStackIn, final ein bufferIn, final float minU, final float minV, final float maxU, final float maxV, final int sizeX, final int sizeY, float width, final float texWidth, final float texHeight, final int packedLightIn, final int packedOverlayIn, final float red, final float green, final float blue, final float alpha) {
        if (width < 6.25E-4f) {
            width = 6.25E-4f;
        }
        final float dU = maxU - minU;
        final float dV = maxV - minV;
        final float dimX = apa.e(dU) * (texWidth / 16.0f);
        final float dimY = apa.e(dV) * (texHeight / 16.0f);
        float normX = 0.0f;
        float normY = 0.0f;
        float normZ = -1.0f;
        addVertex(matrixStackIn, bufferIn, 0.0f, dimY, 0.0f, red, green, blue, alpha, minU, maxV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        addVertex(matrixStackIn, bufferIn, dimX, dimY, 0.0f, red, green, blue, alpha, maxU, maxV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        addVertex(matrixStackIn, bufferIn, dimX, 0.0f, 0.0f, red, green, blue, alpha, maxU, minV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        addVertex(matrixStackIn, bufferIn, 0.0f, 0.0f, 0.0f, red, green, blue, alpha, minU, minV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        normX = 0.0f;
        normY = 0.0f;
        normZ = 1.0f;
        addVertex(matrixStackIn, bufferIn, 0.0f, 0.0f, width, red, green, blue, alpha, minU, minV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        addVertex(matrixStackIn, bufferIn, dimX, 0.0f, width, red, green, blue, alpha, maxU, minV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        addVertex(matrixStackIn, bufferIn, dimX, dimY, width, red, green, blue, alpha, maxU, maxV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        addVertex(matrixStackIn, bufferIn, 0.0f, dimY, width, red, green, blue, alpha, minU, maxV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        final float var8 = 0.5f * dU / sizeX;
        final float var9 = 0.5f * dV / sizeY;
        normX = -1.0f;
        normY = 0.0f;
        normZ = 0.0f;
        for (int var10 = 0; var10 < sizeX; ++var10) {
            final float var11 = var10 / (float)sizeX;
            final float var12 = minU + dU * var11 + var8;
            addVertex(matrixStackIn, bufferIn, var11 * dimX, dimY, width, red, green, blue, alpha, var12, maxV, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, var11 * dimX, dimY, 0.0f, red, green, blue, alpha, var12, maxV, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, var11 * dimX, 0.0f, 0.0f, red, green, blue, alpha, var12, minV, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, var11 * dimX, 0.0f, width, red, green, blue, alpha, var12, minV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        }
        normX = 1.0f;
        normY = 0.0f;
        normZ = 0.0f;
        for (int var10 = 0; var10 < sizeX; ++var10) {
            final float var11 = var10 / (float)sizeX;
            final float var12 = minU + dU * var11 + var8;
            final float var13 = var11 + 1.0f / sizeX;
            addVertex(matrixStackIn, bufferIn, var13 * dimX, 0.0f, width, red, green, blue, alpha, var12, minV, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, var13 * dimX, 0.0f, 0.0f, red, green, blue, alpha, var12, minV, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, var13 * dimX, dimY, 0.0f, red, green, blue, alpha, var12, maxV, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, var13 * dimX, dimY, width, red, green, blue, alpha, var12, maxV, packedOverlayIn, packedLightIn, normX, normY, normZ);
        }
        normX = 0.0f;
        normY = 1.0f;
        normZ = 0.0f;
        for (int var10 = 0; var10 < sizeY; ++var10) {
            final float var11 = var10 / (float)sizeY;
            final float var12 = minV + dV * var11 + var9;
            final float var13 = var11 + 1.0f / sizeY;
            addVertex(matrixStackIn, bufferIn, 0.0f, var13 * dimY, width, red, green, blue, alpha, minU, var12, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, dimX, var13 * dimY, width, red, green, blue, alpha, maxU, var12, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, dimX, var13 * dimY, 0.0f, red, green, blue, alpha, maxU, var12, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, 0.0f, var13 * dimY, 0.0f, red, green, blue, alpha, minU, var12, packedOverlayIn, packedLightIn, normX, normY, normZ);
        }
        normX = 0.0f;
        normY = -1.0f;
        normZ = 0.0f;
        for (int var10 = 0; var10 < sizeY; ++var10) {
            final float var11 = var10 / (float)sizeY;
            final float var12 = minV + dV * var11 + var9;
            addVertex(matrixStackIn, bufferIn, dimX, var11 * dimY, width, red, green, blue, alpha, maxU, var12, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, 0.0f, var11 * dimY, width, red, green, blue, alpha, minU, var12, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, 0.0f, var11 * dimY, 0.0f, red, green, blue, alpha, minU, var12, packedOverlayIn, packedLightIn, normX, normY, normZ);
            addVertex(matrixStackIn, bufferIn, dimX, var11 * dimY, 0.0f, red, green, blue, alpha, maxU, var12, packedOverlayIn, packedLightIn, normX, normY, normZ);
        }
    }
    
    static void addVertex(final eij matrixStackIn, final ein bufferIn, final float x, final float y, final float z, final float red, final float green, final float blue, final float alpha, final float texU, final float texV, final int overlayUV, final int lightmapUV, final float normalX, final float normalY, final float normalZ) {
        final eij.a matrixEntry = matrixStackIn.c();
        final Matrix4f matrix4f = matrixEntry.a();
        final Matrix3f matrixNormal = matrixEntry.b();
        final float xn = MathUtils.getTransformX(matrixNormal, normalX, normalY, normalZ);
        final float yn = MathUtils.getTransformY(matrixNormal, normalX, normalY, normalZ);
        final float zn = MathUtils.getTransformZ(matrixNormal, normalX, normalY, normalZ);
        final float xt = MathUtils.getTransformX(matrix4f, x, y, z, 1.0f);
        final float yt = MathUtils.getTransformY(matrix4f, x, y, z, 1.0f);
        final float zt = MathUtils.getTransformZ(matrix4f, x, y, z, 1.0f);
        bufferIn.a(xt, yt, zt, red, green, blue, alpha, texU, texV, overlayUV, lightmapUV, xn, yn, zn);
    }
}
