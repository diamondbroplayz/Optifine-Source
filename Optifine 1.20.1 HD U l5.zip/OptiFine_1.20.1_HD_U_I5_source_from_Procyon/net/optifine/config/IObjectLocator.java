// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.config;

public interface IObjectLocator<T>
{
    T getObject(final acq p0);
}
