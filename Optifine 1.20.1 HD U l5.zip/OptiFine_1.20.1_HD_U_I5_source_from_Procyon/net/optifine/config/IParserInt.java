// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.config;

public interface IParserInt
{
    int parse(final String p0, final int p1);
}
