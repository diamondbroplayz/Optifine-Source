// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.config;

public interface SliderableValueSetInt<T> extends enq.k<T>
{
    enq.g getIntRange();
}
