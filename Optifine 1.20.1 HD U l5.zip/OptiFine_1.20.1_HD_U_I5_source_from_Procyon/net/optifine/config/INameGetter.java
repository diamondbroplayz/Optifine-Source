// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.config;

public interface INameGetter<T>
{
    String getName(final T p0);
}
