// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.util;

public abstract class TickableTexture extends fug implements fux
{
}
