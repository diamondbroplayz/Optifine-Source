// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.util;

public class EntityTypeUtils
{
    public static bfn getEntityType(final acq loc) {
        if (!jb.h.c(loc)) {
            return null;
        }
        return (bfn)jb.h.a(loc);
    }
}
