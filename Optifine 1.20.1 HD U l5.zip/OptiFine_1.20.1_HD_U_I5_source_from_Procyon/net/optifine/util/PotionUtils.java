// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.util;

public class PotionUtils
{
    public static bey getPotion(final acq loc) {
        if (!jb.e.c(loc)) {
            return null;
        }
        return (bey)jb.e.a(loc);
    }
}
