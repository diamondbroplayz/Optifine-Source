// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.util;

public class GuiUtils
{
    public static int getWidth(final epf widget) {
        return widget.k();
    }
    
    public static int getHeight(final epf widget) {
        return widget.h();
    }
}
