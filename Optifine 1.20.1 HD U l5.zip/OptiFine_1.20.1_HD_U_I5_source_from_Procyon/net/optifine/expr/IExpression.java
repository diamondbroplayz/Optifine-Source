// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.expr;

public interface IExpression
{
    ExpressionType getExpressionType();
}
