// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.expr;

import java.util.ArrayList;
import net.optifine.Config;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;
import java.util.Deque;
import java.io.IOException;
import java.util.Collection;
import java.util.ArrayDeque;
import java.util.Arrays;

public class ExpressionParser
{
    private IExpressionResolver expressionResolver;
    
    public ExpressionParser(final IExpressionResolver expressionResolver) {
        this.expressionResolver = expressionResolver;
    }
    
    public IExpressionFloat parseFloat(final String str) throws ParseException {
        final IExpression expr = this.parse(str);
        if (!(expr instanceof IExpressionFloat)) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/ExpressionType;)Ljava/lang/String;, expr.getExpressionType()));
        }
        return (IExpressionFloat)expr;
    }
    
    public IExpressionBool parseBool(final String str) throws ParseException {
        final IExpression expr = this.parse(str);
        if (!(expr instanceof IExpressionBool)) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/ExpressionType;)Ljava/lang/String;, expr.getExpressionType()));
        }
        return (IExpressionBool)expr;
    }
    
    public IExpression parse(final String str) throws ParseException {
        try {
            final Token[] tokens = TokenParser.parse(str);
            if (tokens == null) {
                return null;
            }
            final Deque<Token> deque = new ArrayDeque<Token>(Arrays.asList(tokens));
            return this.parseInfix(deque);
        }
        catch (IOException e) {
            throw new ParseException(e.getMessage(), e);
        }
    }
    
    private IExpression parseInfix(final Deque<Token> deque) throws ParseException {
        if (deque.isEmpty()) {
            return null;
        }
        final List<IExpression> listExpr = new LinkedList<IExpression>();
        final List<Token> listOperTokens = new LinkedList<Token>();
        final IExpression expr = this.parseExpression(deque);
        checkNull(expr, "Missing expression");
        listExpr.add(expr);
        while (true) {
            final Token tokenOper = deque.poll();
            if (tokenOper == null) {
                return this.makeInfix(listExpr, listOperTokens);
            }
            if (tokenOper.getType() != TokenType.OPERATOR) {
                throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/Token;)Ljava/lang/String;, tokenOper));
            }
            final IExpression expr2 = this.parseExpression(deque);
            checkNull(expr2, "Missing expression");
            listOperTokens.add(tokenOper);
            listExpr.add(expr2);
        }
    }
    
    private IExpression makeInfix(final List<IExpression> listExpr, final List<Token> listOper) throws ParseException {
        final List<FunctionType> listFunc = new LinkedList<FunctionType>();
        for (final Token token : listOper) {
            final FunctionType type = FunctionType.parse(token.getText());
            checkNull((Object)type, invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/Token;)Ljava/lang/String;, token));
            listFunc.add(type);
        }
        return this.makeInfixFunc(listExpr, listFunc);
    }
    
    private IExpression makeInfixFunc(final List<IExpression> listExpr, final List<FunctionType> listFunc) throws ParseException {
        if (listExpr.size() != listFunc.size() + 1) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, listExpr.size(), listFunc.size()));
        }
        if (listExpr.size() == 1) {
            return listExpr.get(0);
        }
        int minPrecedence = Integer.MAX_VALUE;
        int maxPrecedence = Integer.MIN_VALUE;
        for (final FunctionType type : listFunc) {
            minPrecedence = Math.min(type.getPrecedence(), minPrecedence);
            maxPrecedence = Math.max(type.getPrecedence(), maxPrecedence);
        }
        if (maxPrecedence < minPrecedence || maxPrecedence - minPrecedence > 10) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, minPrecedence, maxPrecedence));
        }
        for (int i = maxPrecedence; i >= minPrecedence; --i) {
            this.mergeOperators(listExpr, listFunc, i);
        }
        if (listExpr.size() != 1 || listFunc.size() != 0) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, listExpr.size(), listFunc.size()));
        }
        return listExpr.get(0);
    }
    
    private void mergeOperators(final List<IExpression> listExpr, final List<FunctionType> listFuncs, final int precedence) throws ParseException {
        for (int i = 0; i < listFuncs.size(); ++i) {
            final FunctionType type = listFuncs.get(i);
            if (type.getPrecedence() == precedence) {
                listFuncs.remove(i);
                final IExpression expr1 = listExpr.remove(i);
                final IExpression expr2 = listExpr.remove(i);
                final IExpression exprOper = makeFunction(type, new IExpression[] { expr1, expr2 });
                listExpr.add(i, exprOper);
                --i;
            }
        }
    }
    
    private IExpression parseExpression(final Deque<Token> deque) throws ParseException {
        final Token token = deque.poll();
        checkNull(token, "Missing expression");
        switch (ExpressionParser.ExpressionParser$1.$SwitchMap$net$optifine$expr$TokenType[token.getType().ordinal()]) {
            case 1: {
                return makeConstantFloat(token);
            }
            case 2: {
                final FunctionType type = this.getFunctionType(token, deque);
                if (type != null) {
                    return this.makeFunction(type, deque);
                }
                return this.makeVariable(token);
            }
            case 3: {
                return this.makeBracketed(token, deque);
            }
            case 4: {
                final FunctionType operType = FunctionType.parse(token.getText());
                checkNull((Object)operType, invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/Token;)Ljava/lang/String;, token));
                if (operType == FunctionType.PLUS) {
                    return this.parseExpression(deque);
                }
                if (operType == FunctionType.MINUS) {
                    final IExpression exprNeg = this.parseExpression(deque);
                    return makeFunction(FunctionType.NEG, new IExpression[] { exprNeg });
                }
                if (operType == FunctionType.NOT) {
                    final IExpression exprNot = this.parseExpression(deque);
                    return makeFunction(FunctionType.NOT, new IExpression[] { exprNot });
                }
                break;
            }
        }
        throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/Token;)Ljava/lang/String;, token));
    }
    
    private static IExpression makeConstantFloat(final Token token) throws ParseException {
        final float val = Config.parseFloat(token.getText(), Float.NaN);
        if (val == Float.NaN) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/Token;)Ljava/lang/String;, token));
        }
        return new ConstantFloat(val);
    }
    
    private FunctionType getFunctionType(final Token token, final Deque<Token> deque) throws ParseException {
        final Token tokenNext = deque.peek();
        if (tokenNext != null && tokenNext.getType() == TokenType.BRACKET_OPEN) {
            final FunctionType type = FunctionType.parse(token.getText());
            checkNull((Object)type, invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/Token;)Ljava/lang/String;, token));
            return type;
        }
        final FunctionType type = FunctionType.parse(token.getText());
        if (type == null) {
            return null;
        }
        if (type.getParameterCount(new IExpression[0]) > 0) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/FunctionType;)Ljava/lang/String;, type));
        }
        return type;
    }
    
    private IExpression makeFunction(final FunctionType type, final Deque<Token> deque) throws ParseException {
        if (type.getParameterCount(new IExpression[0]) == 0) {
            final Token tokenNext = deque.peek();
            if (tokenNext == null || tokenNext.getType() != TokenType.BRACKET_OPEN) {
                return makeFunction(type, new IExpression[0]);
            }
        }
        final Token tokenOpen = deque.poll();
        final Deque<Token> dequeBracketed = getGroup(deque, TokenType.BRACKET_CLOSE, true);
        final IExpression[] exprs = this.parseExpressions(dequeBracketed);
        return makeFunction(type, exprs);
    }
    
    private IExpression[] parseExpressions(final Deque<Token> deque) throws ParseException {
        final List<IExpression> list = new ArrayList<IExpression>();
        while (true) {
            final Deque<Token> dequeArg = getGroup(deque, TokenType.COMMA, false);
            final IExpression expr = this.parseInfix(dequeArg);
            if (expr == null) {
                break;
            }
            list.add(expr);
        }
        final IExpression[] exprs = list.toArray(new IExpression[list.size()]);
        return exprs;
    }
    
    private static IExpression makeFunction(final FunctionType type, final IExpression[] args) throws ParseException {
        final ExpressionType[] funcParamTypes = type.getParameterTypes(args);
        if (args.length != funcParamTypes.length) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;II)Ljava/lang/String;, type.getName(), args.length, funcParamTypes.length));
        }
        for (int i = 0; i < args.length; ++i) {
            final IExpression arg = args[i];
            final ExpressionType argType = arg.getExpressionType();
            final ExpressionType funcParamType = funcParamTypes[i];
            if (argType != funcParamType) {
                throw new ParseException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;ILnet/optifine/expr/ExpressionType;Lnet/optifine/expr/ExpressionType;)Ljava/lang/String;, type.getName(), i, argType, funcParamType));
            }
        }
        if (type.getExpressionType() == ExpressionType.FLOAT) {
            return new FunctionFloat(type, args);
        }
        if (type.getExpressionType() == ExpressionType.BOOL) {
            return new FunctionBool(type, args);
        }
        if (type.getExpressionType() == ExpressionType.FLOAT_ARRAY) {
            return new FunctionFloatArray(type, args);
        }
        throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/ExpressionType;Ljava/lang/String;)Ljava/lang/String;, type.getExpressionType(), type.getName()));
    }
    
    private IExpression makeVariable(final Token token) throws ParseException {
        if (this.expressionResolver == null) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/Token;)Ljava/lang/String;, token));
        }
        final IExpression expr = this.expressionResolver.getExpression(token.getText());
        if (expr == null) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/Token;)Ljava/lang/String;, token));
        }
        return expr;
    }
    
    private IExpression makeBracketed(final Token token, final Deque<Token> deque) throws ParseException {
        final Deque<Token> dequeBracketed = getGroup(deque, TokenType.BRACKET_CLOSE, true);
        return this.parseInfix(dequeBracketed);
    }
    
    private static Deque<Token> getGroup(final Deque<Token> deque, final TokenType tokenTypeEnd, final boolean tokenEndRequired) throws ParseException {
        final Deque<Token> dequeGroup = new ArrayDeque<Token>();
        int level = 0;
        final Iterator it = deque.iterator();
        while (it.hasNext()) {
            final Token token = it.next();
            it.remove();
            if (level == 0 && token.getType() == tokenTypeEnd) {
                return dequeGroup;
            }
            dequeGroup.add(token);
            if (token.getType() == TokenType.BRACKET_OPEN) {
                ++level;
            }
            if (token.getType() != TokenType.BRACKET_CLOSE) {
                continue;
            }
            --level;
        }
        if (tokenEndRequired) {
            throw new ParseException(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/TokenType;)Ljava/lang/String;, tokenTypeEnd));
        }
        return dequeGroup;
    }
    
    private static void checkNull(final Object obj, final String message) throws ParseException {
        if (obj == null) {
            throw new ParseException(message);
        }
    }
}
