// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.expr;

public enum TokenType
{
    IDENTIFIER("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_:."), 
    NUMBER("0123456789", "0123456789."), 
    OPERATOR("+-*/%!&|<>=", "&|="), 
    COMMA(","), 
    BRACKET_OPEN("("), 
    BRACKET_CLOSE(")");
    
    private String charsFirst;
    private String charsNext;
    public static final TokenType[] VALUES;
    
    private TokenType(final String charsFirst) {
        this(charsFirst, "");
    }
    
    private TokenType(final String charsFirst, final String charsNext) {
        this.charsFirst = charsFirst;
        this.charsNext = charsNext;
    }
    
    public String getCharsFirst() {
        return this.charsFirst;
    }
    
    public String getCharsNext() {
        return this.charsNext;
    }
    
    public static TokenType getTypeByFirstChar(final char ch) {
        for (int i = 0; i < TokenType.VALUES.length; ++i) {
            final TokenType type = TokenType.VALUES[i];
            if (type.getCharsFirst().indexOf(ch) >= 0) {
                return type;
            }
        }
        return null;
    }
    
    public boolean hasCharNext(final char ch) {
        return this.charsNext.indexOf(ch) >= 0;
    }
    
    private static /* synthetic */ TokenType[] $values() {
        return new TokenType[] { TokenType.IDENTIFIER, TokenType.NUMBER, TokenType.OPERATOR, TokenType.COMMA, TokenType.BRACKET_OPEN, TokenType.BRACKET_CLOSE };
    }
    
    static {
        $VALUES = $values();
        VALUES = values();
    }
    
    private static class Const
    {
        static final String ALPHAS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        static final String DIGITS = "0123456789";
        
        private Const() {
            // 
            // This method could not be decompiled.
            // 
            // Could not show original bytecode, likely due to the same error.
            // 
            // The error that occurred was:
            // 
            // com.strobel.assembler.metadata.MethodBodyParseException: An error occurred while parsing the bytecode of method 'net/optifine/expr/TokenType$Const.<init>:()V'.
            //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:66)
            //     at com.strobel.assembler.metadata.MethodDefinition.tryLoadBody(MethodDefinition.java:729)
            //     at com.strobel.assembler.metadata.MethodDefinition.getBody(MethodDefinition.java:83)
            //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:202)
            //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:576)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
            //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
            //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
            //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
            //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
            //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
            // Caused by: java.lang.IllegalArgumentException: Argument 'index' must be in the range [0, 30], but value was: 45312.
            //     at com.strobel.core.VerifyArgument.inRange(VerifyArgument.java:347)
            //     at com.strobel.assembler.ir.ConstantPool.get(ConstantPool.java:78)
            //     at com.strobel.assembler.metadata.ClassFileReader$Scope.lookupConstant(ClassFileReader.java:1313)
            //     at com.strobel.assembler.metadata.MethodReader.readBodyCore(MethodReader.java:293)
            //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:62)
            //     ... 19 more
            // 
            throw new IllegalStateException("An error occurred while decompiling this method.");
        }
    }
}
