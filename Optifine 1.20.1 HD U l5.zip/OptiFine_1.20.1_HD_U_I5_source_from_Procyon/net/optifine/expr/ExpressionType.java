// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.expr;

public enum ExpressionType
{
    FLOAT, 
    FLOAT_ARRAY, 
    BOOL;
    
    private static /* synthetic */ ExpressionType[] $values() {
        return new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT_ARRAY, ExpressionType.BOOL };
    }
    
    static {
        $VALUES = $values();
    }
}
