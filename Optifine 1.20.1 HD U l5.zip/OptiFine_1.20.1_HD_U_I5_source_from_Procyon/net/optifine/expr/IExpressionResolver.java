// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.expr;

public interface IExpressionResolver
{
    IExpression getExpression(final String p0);
}
