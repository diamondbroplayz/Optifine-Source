// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.expr;

import java.util.HashMap;
import net.optifine.shaders.uniform.Smoother;
import net.optifine.util.FrameEvent;
import net.optifine.Config;
import net.optifine.util.MathUtils;
import java.util.Map;

public enum FunctionType
{
    PLUS(10, ExpressionType.FLOAT, "+", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    MINUS(10, ExpressionType.FLOAT, "-", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    MUL(11, ExpressionType.FLOAT, "*", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    DIV(11, ExpressionType.FLOAT, "/", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    MOD(11, ExpressionType.FLOAT, "%", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    NEG(12, ExpressionType.FLOAT, "neg", new ExpressionType[] { ExpressionType.FLOAT }), 
    PI(ExpressionType.FLOAT, "pi", new ExpressionType[0]), 
    SIN(ExpressionType.FLOAT, "sin", new ExpressionType[] { ExpressionType.FLOAT }), 
    COS(ExpressionType.FLOAT, "cos", new ExpressionType[] { ExpressionType.FLOAT }), 
    ASIN(ExpressionType.FLOAT, "asin", new ExpressionType[] { ExpressionType.FLOAT }), 
    ACOS(ExpressionType.FLOAT, "acos", new ExpressionType[] { ExpressionType.FLOAT }), 
    TAN(ExpressionType.FLOAT, "tan", new ExpressionType[] { ExpressionType.FLOAT }), 
    ATAN(ExpressionType.FLOAT, "atan", new ExpressionType[] { ExpressionType.FLOAT }), 
    ATAN2(ExpressionType.FLOAT, "atan2", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    TORAD(ExpressionType.FLOAT, "torad", new ExpressionType[] { ExpressionType.FLOAT }), 
    TODEG(ExpressionType.FLOAT, "todeg", new ExpressionType[] { ExpressionType.FLOAT }), 
    MIN(ExpressionType.FLOAT, "min", (IParameters)new ParametersVariable().first(ExpressionType.FLOAT).repeat(ExpressionType.FLOAT)), 
    MAX(ExpressionType.FLOAT, "max", (IParameters)new ParametersVariable().first(ExpressionType.FLOAT).repeat(ExpressionType.FLOAT)), 
    CLAMP(ExpressionType.FLOAT, "clamp", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    ABS(ExpressionType.FLOAT, "abs", new ExpressionType[] { ExpressionType.FLOAT }), 
    FLOOR(ExpressionType.FLOAT, "floor", new ExpressionType[] { ExpressionType.FLOAT }), 
    CEIL(ExpressionType.FLOAT, "ceil", new ExpressionType[] { ExpressionType.FLOAT }), 
    EXP(ExpressionType.FLOAT, "exp", new ExpressionType[] { ExpressionType.FLOAT }), 
    FRAC(ExpressionType.FLOAT, "frac", new ExpressionType[] { ExpressionType.FLOAT }), 
    LOG(ExpressionType.FLOAT, "log", new ExpressionType[] { ExpressionType.FLOAT }), 
    POW(ExpressionType.FLOAT, "pow", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    RANDOM(ExpressionType.FLOAT, "random", (IParameters)new ParametersVariable().repeat(ExpressionType.FLOAT).maxCount(1)), 
    ROUND(ExpressionType.FLOAT, "round", new ExpressionType[] { ExpressionType.FLOAT }), 
    SIGNUM(ExpressionType.FLOAT, "signum", new ExpressionType[] { ExpressionType.FLOAT }), 
    SQRT(ExpressionType.FLOAT, "sqrt", new ExpressionType[] { ExpressionType.FLOAT }), 
    FMOD(ExpressionType.FLOAT, "fmod", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    LERP(ExpressionType.FLOAT, "lerp", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    TIME(ExpressionType.FLOAT, "time", new ExpressionType[0]), 
    DAY_TIME(ExpressionType.FLOAT, "day_time", new ExpressionType[0]), 
    DAY_COUNT(ExpressionType.FLOAT, "day_count", new ExpressionType[0]), 
    PRINT(ExpressionType.FLOAT, "print", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    PRINTB(ExpressionType.BOOL, "printb", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT, ExpressionType.BOOL }), 
    IF(ExpressionType.FLOAT, "if", (IParameters)new ParametersVariable().first(ExpressionType.BOOL, ExpressionType.FLOAT).repeat(ExpressionType.BOOL, ExpressionType.FLOAT).last(ExpressionType.FLOAT)), 
    NOT(12, ExpressionType.BOOL, "!", new ExpressionType[] { ExpressionType.BOOL }), 
    AND(3, ExpressionType.BOOL, "&&", new ExpressionType[] { ExpressionType.BOOL, ExpressionType.BOOL }), 
    OR(2, ExpressionType.BOOL, "||", new ExpressionType[] { ExpressionType.BOOL, ExpressionType.BOOL }), 
    GREATER(8, ExpressionType.BOOL, ">", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    GREATER_OR_EQUAL(8, ExpressionType.BOOL, ">=", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    SMALLER(8, ExpressionType.BOOL, "<", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    SMALLER_OR_EQUAL(8, ExpressionType.BOOL, "<=", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    EQUAL(7, ExpressionType.BOOL, "==", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    NOT_EQUAL(7, ExpressionType.BOOL, "!=", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    BETWEEN(7, ExpressionType.BOOL, "between", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    EQUALS(7, ExpressionType.BOOL, "equals", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    IN(ExpressionType.BOOL, "in", (IParameters)new ParametersVariable().first(ExpressionType.FLOAT).repeat(ExpressionType.FLOAT).last(ExpressionType.FLOAT)), 
    SMOOTH(ExpressionType.FLOAT, "smooth", (IParameters)new ParametersVariable().first(ExpressionType.FLOAT).repeat(ExpressionType.FLOAT).maxCount(4)), 
    TRUE(ExpressionType.BOOL, "true", new ExpressionType[0]), 
    FALSE(ExpressionType.BOOL, "false", new ExpressionType[0]), 
    VEC2(ExpressionType.FLOAT_ARRAY, "vec2", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    VEC3(ExpressionType.FLOAT_ARRAY, "vec3", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT, ExpressionType.FLOAT }), 
    VEC4(ExpressionType.FLOAT_ARRAY, "vec4", new ExpressionType[] { ExpressionType.FLOAT, ExpressionType.FLOAT, ExpressionType.FLOAT, ExpressionType.FLOAT });
    
    private int precedence;
    private ExpressionType expressionType;
    private String name;
    private IParameters parameters;
    public static FunctionType[] VALUES;
    private static final Map<Integer, Float> mapSmooth;
    
    private FunctionType(final ExpressionType expressionType, final String name, final ExpressionType[] parameterTypes) {
        this(0, expressionType, name, parameterTypes);
    }
    
    private FunctionType(final int precedence, final ExpressionType expressionType, final String name, final ExpressionType[] parameterTypes) {
        this(precedence, expressionType, name, new Parameters(parameterTypes));
    }
    
    private FunctionType(final ExpressionType expressionType, final String name, final IParameters parameters) {
        this(0, expressionType, name, parameters);
    }
    
    private FunctionType(final int precedence, final ExpressionType expressionType, final String name, final IParameters parameters) {
        this.precedence = precedence;
        this.expressionType = expressionType;
        this.name = name;
        this.parameters = parameters;
    }
    
    public String getName() {
        return this.name;
    }
    
    public int getPrecedence() {
        return this.precedence;
    }
    
    public ExpressionType getExpressionType() {
        return this.expressionType;
    }
    
    public IParameters getParameters() {
        return this.parameters;
    }
    
    public int getParameterCount(final IExpression[] arguments) {
        return this.parameters.getParameterTypes(arguments).length;
    }
    
    public ExpressionType[] getParameterTypes(final IExpression[] arguments) {
        return this.parameters.getParameterTypes(arguments);
    }
    
    public float evalFloat(final IExpression[] args) {
        final enn mc = enn.N();
        final cmm world = (cmm)mc.s;
        switch (FunctionType.FunctionType$1.$SwitchMap$net$optifine$expr$FunctionType[this.ordinal()]) {
            case 1: {
                return evalFloat(args, 0) + evalFloat(args, 1);
            }
            case 2: {
                return evalFloat(args, 0) - evalFloat(args, 1);
            }
            case 3: {
                return evalFloat(args, 0) * evalFloat(args, 1);
            }
            case 4: {
                return evalFloat(args, 0) / evalFloat(args, 1);
            }
            case 5: {
                final float modX = evalFloat(args, 0);
                final float modY = evalFloat(args, 1);
                return modX - modY * (int)(modX / modY);
            }
            case 6: {
                return -evalFloat(args, 0);
            }
            case 7: {
                return 3.1415927f;
            }
            case 8: {
                return apa.a(evalFloat(args, 0));
            }
            case 9: {
                return apa.b(evalFloat(args, 0));
            }
            case 10: {
                return MathUtils.asin(evalFloat(args, 0));
            }
            case 11: {
                return MathUtils.acos(evalFloat(args, 0));
            }
            case 12: {
                return (float)Math.tan(evalFloat(args, 0));
            }
            case 13: {
                return (float)Math.atan(evalFloat(args, 0));
            }
            case 14: {
                return (float)apa.d((double)evalFloat(args, 0), (double)evalFloat(args, 1));
            }
            case 15: {
                return MathUtils.toRad(evalFloat(args, 0));
            }
            case 16: {
                return MathUtils.toDeg(evalFloat(args, 0));
            }
            case 17: {
                return this.getMin(args);
            }
            case 18: {
                return this.getMax(args);
            }
            case 19: {
                return apa.a(evalFloat(args, 0), evalFloat(args, 1), evalFloat(args, 2));
            }
            case 20: {
                return apa.e(evalFloat(args, 0));
            }
            case 21: {
                return (float)Math.exp(evalFloat(args, 0));
            }
            case 22: {
                return (float)apa.d(evalFloat(args, 0));
            }
            case 23: {
                return (float)apa.f(evalFloat(args, 0));
            }
            case 24: {
                return apa.h(evalFloat(args, 0));
            }
            case 25: {
                return (float)Math.log(evalFloat(args, 0));
            }
            case 26: {
                return (float)Math.pow(evalFloat(args, 0), evalFloat(args, 1));
            }
            case 27: {
                if (args.length > 0) {
                    final float seed = evalFloat(args, 0);
                    final int seedInt = Float.floatToIntBits(seed);
                    final int randInt = Config.intHash(seedInt);
                    return Math.abs(randInt) / 2.14748365E9f;
                }
                return (float)Math.random();
            }
            case 28: {
                return (float)Math.round(evalFloat(args, 0));
            }
            case 29: {
                return Math.signum(evalFloat(args, 0));
            }
            case 30: {
                return apa.c(evalFloat(args, 0));
            }
            case 31: {
                final float fmodX = evalFloat(args, 0);
                final float fmodY = evalFloat(args, 1);
                return fmodX - fmodY * apa.d(fmodX / fmodY);
            }
            case 32: {
                final float k = evalFloat(args, 0);
                final float x = evalFloat(args, 1);
                final float y = evalFloat(args, 2);
                return apa.i(k, x, y);
            }
            case 33: {
                if (world == null) {
                    return 0.0f;
                }
                return world.V() % 720720L + fjq.getRenderPartialTicks();
            }
            case 34: {
                if (world == null) {
                    return 0.0f;
                }
                return world.W() % 24000L + fjq.getRenderPartialTicks();
            }
            case 35: {
                if (world == null) {
                    return 0.0f;
                }
                return (float)(world.W() / 24000L);
            }
            case 36: {
                final int printId = (int)evalFloat(args, 0);
                final int printFrames = (int)evalFloat(args, 1);
                final float printVal = evalFloat(args, 2);
                if (FrameEvent.isActive(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, printId), printFrames)) {
                    Config.dbg(invokedynamic(makeConcatWithConstants:(IF)Ljava/lang/String;, printId, printVal));
                }
                return printVal;
            }
            case 37: {
                final int countChecks = (args.length - 1) / 2;
                for (int i = 0; i < countChecks; ++i) {
                    final int index = i * 2;
                    if (evalBool(args, index)) {
                        return evalFloat(args, index + 1);
                    }
                }
                return evalFloat(args, countChecks * 2);
            }
            case 38: {
                final int id = (int)evalFloat(args, 0);
                final float valRaw = evalFloat(args, 1);
                final float valFadeUp = (args.length > 2) ? evalFloat(args, 2) : 1.0f;
                final float valFadeDown = (args.length > 3) ? evalFloat(args, 3) : valFadeUp;
                final float valSmooth = Smoother.getSmoothValue(id, valRaw, valFadeUp, valFadeDown);
                return valSmooth;
            }
            default: {
                Config.warn(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/FunctionType;)Ljava/lang/String;, this));
                return 0.0f;
            }
        }
    }
    
    private float getMin(final IExpression[] exprs) {
        if (exprs.length == 2) {
            return Math.min(evalFloat(exprs, 0), evalFloat(exprs, 1));
        }
        float valMin = evalFloat(exprs, 0);
        for (int i = 1; i < exprs.length; ++i) {
            final float valExpr = evalFloat(exprs, i);
            if (valExpr < valMin) {
                valMin = valExpr;
            }
        }
        return valMin;
    }
    
    private float getMax(final IExpression[] exprs) {
        if (exprs.length == 2) {
            return Math.max(evalFloat(exprs, 0), evalFloat(exprs, 1));
        }
        float valMax = evalFloat(exprs, 0);
        for (int i = 1; i < exprs.length; ++i) {
            final float valExpr = evalFloat(exprs, i);
            if (valExpr > valMax) {
                valMax = valExpr;
            }
        }
        return valMax;
    }
    
    private static float evalFloat(final IExpression[] exprs, final int index) {
        final IExpressionFloat ef = (IExpressionFloat)exprs[index];
        final float val = ef.eval();
        return val;
    }
    
    public boolean evalBool(final IExpression[] args) {
        switch (FunctionType.FunctionType$1.$SwitchMap$net$optifine$expr$FunctionType[this.ordinal()]) {
            case 39: {
                return true;
            }
            case 40: {
                return false;
            }
            case 41: {
                return !evalBool(args, 0);
            }
            case 42: {
                return evalBool(args, 0) && evalBool(args, 1);
            }
            case 43: {
                return evalBool(args, 0) || evalBool(args, 1);
            }
            case 44: {
                return evalFloat(args, 0) > evalFloat(args, 1);
            }
            case 45: {
                return evalFloat(args, 0) >= evalFloat(args, 1);
            }
            case 46: {
                return evalFloat(args, 0) < evalFloat(args, 1);
            }
            case 47: {
                return evalFloat(args, 0) <= evalFloat(args, 1);
            }
            case 48: {
                return evalFloat(args, 0) == evalFloat(args, 1);
            }
            case 49: {
                return evalFloat(args, 0) != evalFloat(args, 1);
            }
            case 50: {
                final float val = evalFloat(args, 0);
                return val >= evalFloat(args, 1) && val <= evalFloat(args, 2);
            }
            case 51: {
                final float diff = evalFloat(args, 0) - evalFloat(args, 1);
                final float delta = evalFloat(args, 2);
                return Math.abs(diff) <= delta;
            }
            case 52: {
                final float valIn = evalFloat(args, 0);
                for (int i = 1; i < args.length; ++i) {
                    final float valCheck = evalFloat(args, i);
                    if (valIn == valCheck) {
                        return true;
                    }
                }
                return false;
            }
            case 53: {
                final int printId = (int)evalFloat(args, 0);
                final int printFrames = (int)evalFloat(args, 1);
                final boolean printVal = evalBool(args, 2);
                if (FrameEvent.isActive(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, printId), printFrames)) {
                    Config.dbg(invokedynamic(makeConcatWithConstants:(IZ)Ljava/lang/String;, printId, printVal));
                }
                return printVal;
            }
            default: {
                Config.warn(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/FunctionType;)Ljava/lang/String;, this));
                return false;
            }
        }
    }
    
    private static boolean evalBool(final IExpression[] exprs, final int index) {
        final IExpressionBool eb = (IExpressionBool)exprs[index];
        final boolean val = eb.eval();
        return val;
    }
    
    public float[] evalFloatArray(final IExpression[] args) {
        switch (FunctionType.FunctionType$1.$SwitchMap$net$optifine$expr$FunctionType[this.ordinal()]) {
            case 54: {
                return new float[] { evalFloat(args, 0), evalFloat(args, 1) };
            }
            case 55: {
                return new float[] { evalFloat(args, 0), evalFloat(args, 1), evalFloat(args, 2) };
            }
            case 56: {
                return new float[] { evalFloat(args, 0), evalFloat(args, 1), evalFloat(args, 2), evalFloat(args, 3) };
            }
            default: {
                Config.warn(invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/FunctionType;)Ljava/lang/String;, this));
                return null;
            }
        }
    }
    
    public static FunctionType parse(final String str) {
        for (int i = 0; i < FunctionType.VALUES.length; ++i) {
            final FunctionType ef = FunctionType.VALUES[i];
            if (ef.getName().equals(str)) {
                return ef;
            }
        }
        return null;
    }
    
    private static /* synthetic */ FunctionType[] $values() {
        return new FunctionType[] { FunctionType.PLUS, FunctionType.MINUS, FunctionType.MUL, FunctionType.DIV, FunctionType.MOD, FunctionType.NEG, FunctionType.PI, FunctionType.SIN, FunctionType.COS, FunctionType.ASIN, FunctionType.ACOS, FunctionType.TAN, FunctionType.ATAN, FunctionType.ATAN2, FunctionType.TORAD, FunctionType.TODEG, FunctionType.MIN, FunctionType.MAX, FunctionType.CLAMP, FunctionType.ABS, FunctionType.FLOOR, FunctionType.CEIL, FunctionType.EXP, FunctionType.FRAC, FunctionType.LOG, FunctionType.POW, FunctionType.RANDOM, FunctionType.ROUND, FunctionType.SIGNUM, FunctionType.SQRT, FunctionType.FMOD, FunctionType.LERP, FunctionType.TIME, FunctionType.DAY_TIME, FunctionType.DAY_COUNT, FunctionType.PRINT, FunctionType.PRINTB, FunctionType.IF, FunctionType.NOT, FunctionType.AND, FunctionType.OR, FunctionType.GREATER, FunctionType.GREATER_OR_EQUAL, FunctionType.SMALLER, FunctionType.SMALLER_OR_EQUAL, FunctionType.EQUAL, FunctionType.NOT_EQUAL, FunctionType.BETWEEN, FunctionType.EQUALS, FunctionType.IN, FunctionType.SMOOTH, FunctionType.TRUE, FunctionType.FALSE, FunctionType.VEC2, FunctionType.VEC3, FunctionType.VEC4 };
    }
    
    static {
        $VALUES = $values();
        FunctionType.VALUES = values();
        mapSmooth = new HashMap<Integer, Float>();
    }
}
