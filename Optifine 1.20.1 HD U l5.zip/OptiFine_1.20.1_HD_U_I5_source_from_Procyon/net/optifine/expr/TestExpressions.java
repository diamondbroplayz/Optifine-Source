// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.expr;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TestExpressions
{
    public static void main(final String[] args) throws Exception {
        final ExpressionParser ep = new ExpressionParser(null);
    Label_0009_Outer:
        while (true) {
            while (true) {
                try {
                    while (true) {
                        final InputStreamReader ir = new InputStreamReader(System.in);
                        final BufferedReader br = new BufferedReader(ir);
                        final String line = br.readLine();
                        if (line.length() <= 0) {
                            break;
                        }
                        final IExpression expr = ep.parse(line);
                        if (expr instanceof IExpressionFloat) {
                            final IExpressionFloat ef = (IExpressionFloat)expr;
                            final float val = ef.eval();
                            System.out.println(invokedynamic(makeConcatWithConstants:(F)Ljava/lang/String;, val));
                        }
                        if (!(expr instanceof IExpressionBool)) {
                            continue Label_0009_Outer;
                        }
                        final IExpressionBool eb = (IExpressionBool)expr;
                        final boolean val2 = eb.eval();
                        System.out.println(invokedynamic(makeConcatWithConstants:(Z)Ljava/lang/String;, val2));
                    }
                    break;
                }
                catch (Exception e) {
                    e.printStackTrace();
                    continue Label_0009_Outer;
                }
                continue;
            }
        }
    }
}
