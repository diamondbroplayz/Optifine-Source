// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.expr;

import java.io.IOException;
import java.util.List;
import java.io.Reader;
import java.util.ArrayList;
import java.io.PushbackReader;
import java.io.StringReader;

public class TokenParser
{
    public static Token[] parse(final String str) throws IOException, ParseException {
        final Reader r = new StringReader(str);
        final PushbackReader pr = new PushbackReader(r);
        final List<Token> list = new ArrayList<Token>();
        while (true) {
            final int i = pr.read();
            if (i < 0) {
                final Token[] tokens = list.toArray(new Token[list.size()]);
                return tokens;
            }
            final char ch = (char)i;
            if (Character.isWhitespace(ch)) {
                continue;
            }
            final TokenType type = TokenType.getTypeByFirstChar(ch);
            if (type == null) {
                throw new ParseException(invokedynamic(makeConcatWithConstants:(CLjava/lang/String;)Ljava/lang/String;, ch, str));
            }
            final Token token = readToken(ch, type, pr);
            list.add(token);
        }
    }
    
    private static Token readToken(final char chFirst, final TokenType type, final PushbackReader pr) throws IOException {
        final StringBuffer sb = new StringBuffer();
        sb.append(chFirst);
        while (true) {
            final int i = pr.read();
            if (i < 0) {
                break;
            }
            final char ch = (char)i;
            if (!type.hasCharNext(ch)) {
                pr.unread(ch);
                break;
            }
            sb.append(ch);
        }
        return new Token(type, sb.toString());
    }
}
