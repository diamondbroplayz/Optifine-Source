// 
// Decompiled by Procyon v0.5.36
// 

package net.optifine.expr;

import net.optifine.shaders.uniform.Smoother;

public class FunctionFloat implements IExpressionFloat
{
    private FunctionType type;
    private IExpression[] arguments;
    private int smoothId;
    
    public FunctionFloat(final FunctionType type, final IExpression[] arguments) {
        this.smoothId = -1;
        this.type = type;
        this.arguments = arguments;
    }
    
    @Override
    public float eval() {
        final IExpression[] args = this.arguments;
        switch (FunctionFloat.FunctionFloat$1.$SwitchMap$net$optifine$expr$FunctionType[this.type.ordinal()]) {
            case 1: {
                final IExpression expr0 = args[0];
                if (!(expr0 instanceof ConstantFloat)) {
                    final float valRaw = evalFloat(args, 0);
                    final float valFadeUp = (args.length > 1) ? evalFloat(args, 1) : 1.0f;
                    final float valFadeDown = (args.length > 2) ? evalFloat(args, 2) : valFadeUp;
                    if (this.smoothId < 0) {
                        this.smoothId = Smoother.getNextId();
                    }
                    final float valSmooth = Smoother.getSmoothValue(this.smoothId, valRaw, valFadeUp, valFadeDown);
                    return valSmooth;
                }
                break;
            }
        }
        return this.type.evalFloat(this.arguments);
    }
    
    private static float evalFloat(final IExpression[] exprs, final int index) {
        final IExpressionFloat ef = (IExpressionFloat)exprs[index];
        final float val = ef.eval();
        return val;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Lnet/optifine/expr/FunctionType;)Ljava/lang/String;, this.type);
    }
}
